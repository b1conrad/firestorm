
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdarg.h>
#include <time.h>

#include "fs.h"
#ifdef WIN32
#include "e:\engine\pba.h"
#include "e:\engine\dpif.h"
#else
#include "pba.h"
#include "dpif.h"
#endif

#define MAX_FLIST_SIZE 32767
#define MAX_IFLIST_SIZE 1000

#define ERR_PGM_PANIC 100
#define ERR_MEMORY    101
#define ERR_PARAMETER 102

#define ERR_DP(err)   err

#define ASSERT(truth)                                                   \
if (!(truth)) {                                                         \
  fprintf(stderr, "%s: Assertion '%s' failed at line #%d, file '%s'\n", \
    ProgramName, #truth, __LINE__, __FILE__);                           \
  exit(ERR_PGM_PANIC);                                                  \
}

#define MEMERR(fctname,sz)                                          \
  fprintf(stderr, "%s: %s() -- malloc(%d) failed\n", ProgramName, fctname, sz); 

typedef enum { FALSE=0, TRUE=1 } bool;

unsigned char dosToLatin[256] = {
  0,   1,   2,   3,   4,   5,   6,   7,   8,   9,  10,  11,  12,  13,  14,  15,
 16,  17,  18,  19, 182, 167,  20,  21,  22,  23,  24,  25,  26,  27,  28,  29,
 32,  33,  34,  35,  36,  37,  38,  39,  40,  41,  42,  43,  44,  45,  46,  47,
 48,  49,  50,  51,  52,  53,  54,  55,  56,  57,  58,  59,  60,  61,  62,  63,
 64,  65,  66,  67,  68,  69,  70,  71,  72,  73,  74,  75,  76,  77,  78,  79,
 80,  81,  82,  83,  84,  85,  86,  87,  88,  89,  90,  91,  92,  93,  94,  95,
 96,  97,  98,  99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111,
112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126,  30,
199, 252, 233, 226, 228, 224, 229, 231, 234, 235, 232, 239, 238, 236, 196, 197,
201, 230, 198, 244, 246, 242, 251, 249, 255, 214, 220, 162, 163, 165,  31, 127,
225, 237, 243, 250, 241, 209, 170, 186, 191, 128, 172, 189, 188, 161, 171, 187,
129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144,
145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 164,
166, 168, 169, 173, 174, 175, 179, 180, 184, 185, 190, 192, 193, 194, 195, 200,
202, 203, 204, 205, 206, 207, 181, 208, 210, 211, 212, 213, 215, 216, 217, 218,
219, 177, 221, 222, 223, 227, 247, 240, 176, 183, 245, 248, 253, 178, 254, 160
};

unsigned char latinToDos[256] = {
  0,   1,   2,   3,   4,   5,   6,   7,   8,   9,  10,  11,  12,  13,  14,  15,
 16,  17,  18,  19,  22,  23,  24,  25,  26,  27,  28,  29,  30,  31, 127, 158,
 32,  33,  34,  35,  36,  37,  38,  39,  40,  41,  42,  43,  44,  45,  46,  47,
 48,  49,  50,  51,  52,  53,  54,  55,  56,  57,  58,  59,  60,  61,  62,  63,
 64,  65,  66,  67,  68,  69,  70,  71,  72,  73,  74,  75,  76,  77,  78,  79,
 80,  81,  82,  83,  84,  85,  86,  87,  88,  89,  90,  91,  92,  93,  94,  95,
 96,  97,  98,  99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111,
112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 159,
169, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190,
191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206,
255, 173, 155, 156, 207, 157, 208,  21, 209, 210, 166, 174, 170, 211, 212, 213,
248, 241, 253, 214, 215, 230,  20, 249, 216, 217, 167, 175, 172, 171, 218, 168,
219, 220, 221, 222, 142, 143, 146, 128, 223, 144, 224, 225, 226, 227, 228, 229,
231, 165, 232, 233, 234, 235, 153, 236, 237, 238, 239, 240, 154, 242, 243, 244,
133, 160, 131, 245, 132, 134, 145, 135, 138, 130, 136, 137, 141, 161, 140, 139,
247, 164, 149, 162, 147, 250, 148, 246, 251, 151, 163, 150, 129, 252, 254, 152
};

void trcpy(char *t, char *s, int len, unsigned char *trTable)
{
  for (; len; len--) {
    *t++ = trTable[*s++ & 0xFF];
  }
}

/* return a heap-allocated Pascal string copy of the input C string */
unsigned char *NewPstr(char *Cstr) 
{
  register int len;
  register char *s, *t;
  unsigned char *Pstr;
  
  len = strlen(Cstr);
  ASSERT(len <= 255);
  Pstr = (unsigned char *) malloc(len+1);
  if (Pstr == NULL) {
    MEMERR("NewPstr", len+1);
    exit(ERR_MEMORY);
  }
  
  Pstr[0] = len;
  for (s=Cstr, t=(char *)Pstr+1; len>0; len--) {
    *t++ = *s++;
  }
  return Pstr;
}

void FSopen(void)
{
  int err;
  unsigned char *index_filename;
  unsigned char *text_filename;

  index_filename = NewPstr(ind_name); 
  text_filename = NewPstr(txx_name);  
  err = dpe_Init(index_filename, text_filename, sort_map);
  if (err != 0) {
    fprintf(stderr,"%s: dpe_Init(\"%s\", \"%s\", sortmap) failed (#%d)\n", 
	  ProgramName, ind_name, txx_name, err);
    exit(ERR_DP(err));
  }
  free(index_filename);
  free(text_filename);
}

void FSclose(void)
{
  int err;

  err = dpe_CloseFiles();
  if (err != 0) {
    fprintf(stderr,"%s: dpe_CloseFiles() failed (#%d)\n", 
	  ProgramName, err);
    exit(ERR_DP(err));
  }
}

FS_panel FSsetPanel(int panelNumberToFind)
{
  register int i;
  
  for (i=0; i<panel_count; i++) {
    if (panel[i].panel_number == panelNumberToFind) return &panel[i];
  }
  return NULL;
}

int InitRecord(char *fctname, Record *rec, int field_count)
{
  int i;

  rec->field_count = field_count;
  rec->field = (Field_Value **) malloc(sizeof(rec->field[0])*field_count);
  if (rec->field == NULL) {
    MEMERR(fctname, sizeof(rec->field[0])*field_count);
    rec->field_count = 0;
    return -1;
  } 
  for (i=0; i < field_count; i++) {
    rec->field[i] = NULL;
  }
  return 0;
}

void DisposeRecord(Record *rec)
{
  int i;

  ASSERT(rec != NULL);
  for (i=0; i < rec->field_count; i++) {
    free(rec->field[i]);
    rec->field[i] = NULL;
  }
  if (rec->field) {
    free(rec->field);
  }
  rec->field_count = 0;
  rec->field = NULL;
}

void GetRecord(Panel_Info *panel, Cursor *rec)
{
  int i, j, len, width;
  WSWORD err;
  WUWORD type;
  unsigned char fldnfo[16];
  unsigned char *buff;
  Field_Value *field;

  DisposeRecord(&rec->pos);
  rec->where = VALID; /* now load the position field */
  if (InitRecord("GetRecord", &rec->pos, panel->field_count) != 0) {
    exit(ERR_MEMORY);
  }
  strncpy(fldnfo, " \5A1;;T", sizeof(fldnfo));
  buff = (unsigned char *)malloc(32000);
  if (buff == NULL) {
    MEMERR("GetRecord", 32000);
    exit(ERR_MEMORY);
  }
  for (i=0; i < panel->field_count; i++) { 
    fldnfo[0] = panel->field_number[i]; 
    if (panel->field_type[i] == '0') {
      err = dpe_GetBlob(panel->pba, fldnfo, &type, 32000, buff);
    } else {
      err = dpe_GetField(panel->pba, fldnfo, &type, 32000, buff);
    }
    if (err == 0) {
      if (panel->field_type[i]<='1') { /* TEXT field type */
        len = buff[0] + 256*buff[1];  /* two-byte length field */
        width = 2;
      } else {
        len = buff[0];                /* one-byte length field */
        width = 1;
      }
      if (panel->field_type[i] != '0') { /* remove trailing spaces */
        for (j=len+width-1; j > width; j--) {
          if (buff[j] != ' ') break;
        }
        if (j<len+width-1) {
          buff[j+1] = 0;
          len = j + 1 - width;
        }
      }
      field = (Field_Value *) malloc(sizeof(Field_Value) + len);
      if (field == NULL) {
        DisposeRecord(&rec->pos);
        MEMERR("GetRecord", sizeof(Field_Value) + len);
        exit(ERR_MEMORY);
      }
      field->field_type = panel->field_type[i];
      field->field_number = panel->field_number[i];
      field->field_length = len;
      if (field->field_type == '0') {
	memcpy(field->field_data, buff+width, len);
      } else {
	trcpy(field->field_data, buff+width, len, dosToLatin);
      }
      field->field_data[len] = 0;
      rec->pos.field[i] = field;
    } else {
      DisposeRecord(&rec->pos);
      fprintf(stderr,"Couldn't get P%dF%d (%d)\n",
        panel->panel_number,panel->field_number[i],err);
      exit(ERR_DP(err));
    }
  }
  free(buff);
}

Field_Value *GetField(int field_number, Record rec)
{
  int i;

  for (i=0; i<rec.field_count; i++) {
    if (rec.field[i]->field_number == field_number) {
      return (rec.field[i]);
    }
  }
  return NULL;
}

int strnecmp(char *s, char *p, int l)
{
  char c, d;

  while (l--) {
    c = *s++; d = *p++;
    if (islower(c)) { c = toupper(c); }
    if (islower(d)) { d = toupper(d); }
    if (c != d) return c-d;
    if (c==0) break;
  }
  return 0;
}

int FindFieldIndex(Panel_Info *panel, int field_num)
{
  int i;

  for (i=0; i < panel->field_count; i++) {
    if (panel->field_number[i] == field_num) return i;
  }
  return -1;
}

unsigned char *BuildKey(Panel_Info *panel, Record rec)
{
  int field_num, field_idx, field_len;
  int i;
  Index_Info *index;
  Field_Value *fv;
  unsigned char buff[256], *last, *key, *p, *lastFullField;

  ASSERT(rec.field!=NULL);

  index = panel->current_index;
  p = buff;
  last = &buff[255];
  
  *p++ = (unsigned char) index->index_number;
  lastFullField = p;

  for (i=0; i < index->index_size; i++) {

    field_num = index->field_number[i];
    if (p>last) break;
    *p++ = field_num;

    field_idx = FindFieldIndex(panel, field_num);
    ASSERT(field_idx >= 0);
    fv = rec.field[field_idx];
    field_len = fv->field_length;
    ASSERT(field_num == fv->field_number);
    ASSERT(panel->field_type[field_idx] != '0');
    if (panel->field_type[field_idx] == '1') {
      /* two-byte length field */
      if (p+1>last) break;
      *p++ = field_len % 256;
      *p++ = field_len / 256;
    } else {
      /* one-byte length field */
      if (p>last) break;
      *p++ = field_len;
    }

    if (last-p+1 < field_len) field_len = last-p+1;
    trcpy(p, fv->field_data, field_len, latinToDos);
    p += field_len;

    lastFullField = p;
  }
  
  *lastFullField++ = 0;

  key = (unsigned char *) malloc(lastFullField-buff);
  if (key == NULL) {
    MEMERR("BuildKey", lastFullField-buff);
  } else {
    memcpy(key, buff, lastFullField-buff);
  }
  return key;
}

int MeetsConstraint(FS_panel p)
{
  unsigned char *cons, *key, *keyToFree;
  WUWORD len, lenInKey;
  int field_number, field_index;
  char field_type;

  if (p->constraint == NULL) { return 1; }

  cons = p->constraint;
  key = keyToFree = BuildKey(p, p->cursor.pos);

  if (*cons++ != *key++) { 
    free(keyToFree);
    return 0; /* wrong index */ 
  }

  for ( ; *cons; cons+=len, key+=lenInKey) {
    field_number = *key++;
    ASSERT(*cons++ == field_number);
    field_index = FindFieldIndex(p, field_number);
    ASSERT(field_index >= 0);
    field_type = p->field_type[field_index];
    ASSERT(field_type != '0');
    len = *cons++;
    lenInKey = *key++;
    if (field_type == '1') {
      len += *cons++ * 256;
      lenInKey += *key++ * 256;
    }
    if  (field_type >= '2' && field_type <= '8') {
      /* numeric, time or date value; check for equality */
      if (len != lenInKey || strncmp(cons, key, len) != 0) {
	free(keyToFree);
        return 0;
      }
    } else {
      /* text or alpha field value; check for prefix */
      if (len > lenInKey || strnecmp(cons, key, len) != 0) {
	free(keyToFree);
        return 0;
      }
    }
  }
  free(keyToFree);
  return 1;
}

Index_Info *FindIndex(FS_panel panel, int indexNumberToFind)
{
  register int i;
  
  for (i=0; i<panel->index_count; i++) {
    if (panel->index[i]->index_number == indexNumberToFind) {
      return panel->index[i];
    }
  }
  return NULL;
}

void FSnewSubset(FS_panel p, FS_ifList ifList)
{
  if (p->constraint == NULL) {
    p->constraint = ifList;
  } else {
    if (p->constraint != ifList) {
      free(p->constraint);
      p->constraint = ifList;
    }
  }
}

int FSsubLastRec(FS_panel p, FS_ifList ifList)
{
  WUDWORD recCount;
  WSWORD err;

  FSnewSubset(p, ifList);
  p->current_index = FindIndex(p,*ifList);
  err = dpe_SubLastRec(p->pba, p->constraint, &recCount);
  if (err != 0) {
  } else if (recCount == 0) {
    DisposeRecord(&p->cursor.pos);
    p->cursor.where = AFTER;
    err = 772;
  } else {
    p->cursor.where = VALID;
    GetRecord(p, &p->cursor);
    if (!MeetsConstraint(p)) {
      DisposeRecord(&p->cursor.pos);
      p->cursor.where = BEFORE;
      err = 772;
    }
  }
  return err;
}

int FSsubFirstRec(FS_panel p, FS_ifList ifList)
{
  WUDWORD recCount;
  WSWORD err;

  FSnewSubset(p, ifList);
  p->current_index = FindIndex(p,*ifList);
  err = dpe_SubFirstRec(p->pba, p->constraint, &recCount);
  if (err != 0) {
  } else if (recCount == 0) {
    DisposeRecord(&p->cursor.pos);
    p->cursor.where = AFTER;
    err = 772;
  } else {
    p->cursor.where = VALID;
    GetRecord(p, &p->cursor);
    if (!MeetsConstraint(p)) {
      DisposeRecord(&p->cursor.pos);
      p->cursor.where = AFTER;
      err = 772;
    }
  }
  return err;
}

int FSsubPrevRec(FS_panel p)
{
  unsigned char *key;
  WUDWORD recCount;
  WSWORD err;

  if (p->constraint==NULL || p->cursor.where!=VALID) {
    return ERR_PGM_PANIC;
  }
  key = BuildKey(p, p->cursor.pos);
  err = dpe_SubPrevRec(p->pba, key, p->constraint+1, &recCount);
  free(key);
  if (err != 0) {
  } else if (recCount == 0) {
    DisposeRecord(&p->cursor.pos);
    p->cursor.where = AFTER;
    err = 772;
  } else {
    p->cursor.where = VALID;
    GetRecord(p, &p->cursor);
    if (!MeetsConstraint(p)) {
      DisposeRecord(&p->cursor.pos);
      p->cursor.where = BEFORE;
      err = 772;
    }
  }
  return err;
}

int FSsubNextRec(FS_panel p)
{
  unsigned char *key;
  WUDWORD recCount;
  WSWORD err;

  if (p->constraint==NULL || p->cursor.where!=VALID) {
    return ERR_PGM_PANIC;
  }
  key = BuildKey(p, p->cursor.pos);
  err = dpe_SubNextRec(p->pba, key, p->constraint+1, &recCount);
  free(key);
  if (err != 0) {
  } else if (recCount == 0) {
    DisposeRecord(&p->cursor.pos);
    p->cursor.where = AFTER;
    err = 772;
  } else {
    p->cursor.where = VALID;
    GetRecord(p, &p->cursor);
    if (!MeetsConstraint(p)) {
      DisposeRecord(&p->cursor.pos);
      p->cursor.where = AFTER;
      err = 772;
    }
  }
  return err;
}

int FSequalRec(FS_panel p, FS_ifList ifList)
{
  WUDWORD recCount;
  WSWORD err;

  p->current_index = FindIndex(p,*ifList);
  err = dpe_EqualRec(p->pba, ifList, &recCount);
  if (err == 0) {
    GetRecord(p, &p->cursor);
  }
  free(ifList);
  return err;
}

int FSprevRec(FS_panel p)
{
  unsigned char *key;
  WUDWORD recCount;
  WSWORD err;

  key = BuildKey(p, p->cursor.pos);
  err = dpe_PrevRec(p->pba, key, &recCount);
  free(key);
  if (err != 0 || recCount == 0) {
    DisposeRecord(&p->cursor.pos);
    p->cursor.where = AFTER;
  } else {
    p->cursor.where = VALID;
    GetRecord(p, &p->cursor);
  }
  return err;
}

int FSnextRec(FS_panel p)
{
  unsigned char *key;
  WUDWORD recCount;
  WSWORD err;

  key = BuildKey(p, p->cursor.pos);
  err = dpe_NextRec(p->pba, key, &recCount);
  free(key);
  if (err != 0 || recCount == 0) {
    DisposeRecord(&p->cursor.pos);
    p->cursor.where = BEFORE;
  } else {
    p->cursor.where = VALID;
    GetRecord(p, &p->cursor);
  }
  return err;
}

int FSfirstRec(FS_panel p, int index_number)
{
  WUDWORD recCount;
  WSWORD err;

  p->current_index = FindIndex(p,index_number);
  err = dpe_FirstRec(p->pba, 
	    (WUWORD)p->current_index->index_number, 
	    &recCount
		);
  if (err != 0 || recCount == 0) {
    DisposeRecord(&p->cursor.pos);
    p->cursor.where = BEFORE;
  } else {
    p->cursor.where = VALID;
    GetRecord(p, &p->cursor);
  }
  return err;
}
      
int FSlastRec(FS_panel p, int index_number)
{
  WUDWORD recCount;
  WSWORD err;

  p->current_index = FindIndex(p,index_number);
  err = dpe_LastRec(p->pba, 
	    (WUWORD)p->current_index->index_number, 
	    &recCount
		);
  if (err != 0 || recCount == 0) {
    DisposeRecord(&p->cursor.pos);
    p->cursor.where = AFTER;
    if (recCount==0) err = 773;
  } else {
    p->cursor.where = VALID;
    GetRecord(p, &p->cursor);
  }
  return err;
}
      
Field_Value *FSfield(FS_panel p, int field_number)
{
  return GetField(field_number, p->cursor.pos);
}

int FSfieldSize(FS_panel p, int field_number)
{
  return GetField(field_number, p->cursor.pos) -> field_length;
}

int FScreateRec(FS_panel p, FS_fList fList)
{
  WSWORD err;

  err = dpe_CreateRec(p->pba, 0, fList, 0, NULL);
  return err;
}


unsigned char *BuildFieldList(Record *rec, bool includeBLOBs)
{
  int i, field_num, field_len, field_wid;
  char field_typ, *field_dat;
  Field_Value *fv;
  unsigned char buff[8000], *after, *flist, *p;

  p = buff;
  after = buff + sizeof(buff);
  for (i=0; i < rec->field_count; i++) {
    fv = rec->field[i];
    if (fv==NULL) continue;
    field_typ = fv->field_type;
    field_num = fv->field_number;
    field_len = fv->field_length;
    field_dat = fv->field_data;
    field_wid = (field_typ <= '1') ? 2 : 1;

    if (field_typ=='0' && !includeBLOBs) continue;

    if (p+1+field_wid+field_len >= after) {
      fprintf(stderr,"BuildFieldList() -- please increase buff[] size\n");
      exit(ERR_PARAMETER);
    }

    *p++ = field_num;
    if (field_wid == 2) {
      if (field_typ == '0') {
	*p++ = (unsigned int)(-field_len) & 0xFF;
	*p++ = ((unsigned int)(-field_len) >> 8) & 0xFF;
      } else {
	*p++ = field_len % 256;
	*p++ = field_len / 256;
      }
    } else {
      *p++ = field_len;
    }
    if (field_typ == '0') {
      memcpy(p, field_dat, field_len);
    } else {
      trcpy(p, field_dat, field_len, latinToDos);
    }
    p += field_len;
  }
  *p++ = 0;

  flist = (unsigned char *) malloc(p-buff);
  if (flist == NULL) {
    MEMERR("BuildFieldList", p-buff);
    exit(ERR_MEMORY);
  } else {
    memcpy(flist, buff, p-buff);
  }
  return flist;
}

Field_Value *NewField(
  char field_type,
  int field_number,
  int field_length,
  char *field_data)
{
  Field_Value *fv;

  fv  = (Field_Value *) malloc(sizeof(*fv)+field_length+1);
  if (fv == NULL) {
    MEMERR("NewField",sizeof(*fv)+field_length+1);
    exit(ERR_MEMORY); 
  }
  fv->field_type = field_type;
  fv->field_number = field_number;
  fv->field_length = field_length;
  memcpy(fv->field_data, field_data, field_length);
  fv->field_data[field_length] = '\0';
  return fv;
}

int FSupdateField(FS_panel p, FS_ifList ifList,
                  int field_number, char op, Field_Value *delta)
{
  int retry;
#define MAX_RETRY 10
  WSWORD err;
  WUDWORD recCount;
  Record rec;
  Field_Value *oldFV;
  unsigned char *flist, *oflist;
  int fi;
  char ft;
  unsigned char buff[8000];
  WUDWORD udw;
  int buffLen;

  if (InitRecord("do_update",&rec,1) != 0) {
    exit(ERR_MEMORY);
  }
  p->current_index = FindIndex(p,*ifList);
  retry = 0;
  do {
    err = dpe_EqualRec(p->pba, ifList, &recCount);
    if (err != 0) {
      return err; 
    }
    GetRecord(p,&p->cursor);
    oldFV = GetField(field_number, p->cursor.pos);
    fi = FindFieldIndex(p,field_number);
    ft = p->field_type[fi];
    switch (op) {
	case ':':
	  memcpy(buff, delta->field_data, delta->field_length);
	  buffLen = delta->field_length;
	  break;
	case '-':
	  udw = atoi(oldFV->field_data);
	  udw -= atoi(delta->field_data);
	  sprintf(buff,"%lu",udw);
	  buffLen = strlen(buff);
	  break;
	case '+':
	  udw = atoi(oldFV->field_data);
	  udw += atoi(delta->field_data);
	  sprintf(buff,"%lu",udw);
	  buffLen = strlen(buff);
	  break;
      }
    rec.field[0] = NewField(ft,field_number,buffLen,buff);
    flist = BuildFieldList(&rec,TRUE);
    oflist = BuildFieldList(&p->cursor.pos,FALSE);
    err = dpe_UpdateRec(p->pba,flist,oflist);
    free(flist);
    free(oflist);
  } while (err == 802 && retry++ < MAX_RETRY);
  if (err) fprintf(stderr,"Update: retry=%d (%d)\n",retry,err);
return err;
}

FS_ifList FSifList(FS_panel panel, int index_number, ...)
{
  va_list pa;
  Field_Value *val;
  FS_ifList buff, p, last, lastFullField, key;
  int field_num, field_idx, field_len;
  int i;
  Index_Info *index;

  buff = (FS_ifList)malloc(MAX_IFLIST_SIZE);
  if (buff == NULL) {
    MEMERR("FSifList", MAX_IFLIST_SIZE);
    exit(ERR_MEMORY);
  }
  last = &buff[MAX_IFLIST_SIZE-1];
  index = FindIndex(panel,index_number);
  if (index == NULL) {
    fprintf(stderr,"Panel %d has no index number %d\n",
      panel->panel_number,index_number);
    exit(ERR_PARAMETER);
  }
  va_start(pa,index_number);
  p = buff;
  *p++ = index->index_number;
  lastFullField = p;
  for (i=0; i < index->index_size; i++) {
    field_num = index->field_number[i];
    if (p>last) break;
    *p++ = field_num;
    val = va_arg(pa,Field_Value *);
    if (val == NULL) break;
    field_len = val->field_length;
    field_idx = FindFieldIndex(panel, field_num);
    ASSERT(panel->field_type[field_idx] != '0');
    if (panel->field_type[field_idx] == '1') { /* two-byte length field */
      if (p+1>last) break;
      *p++ = field_len % 256;
      *p++ = field_len / 256;
    } else {                                   /* one-byte length field */
      if (p>last) break;
      *p++ = field_len;
    }
    if (last-p+1 < field_len) field_len = last-p+1;
    trcpy(p, val->field_data, field_len, latinToDos);
    p += field_len;
    lastFullField = p;
  }
  va_end(pa);
  *lastFullField++ = 0;
  key = (FS_ifList) malloc(lastFullField-buff);
  if (key == NULL) {
    MEMERR("FSifList", lastFullField-buff);
  } else {
    memcpy(key, buff, lastFullField-buff);
  }
  free(buff);
  return key;
}

FS_fList FSfList(FS_panel panel, ...)
{
  va_list pa;
  Field_Value *val;
  FS_ifList buff, p, last, lastFullField, key;
  int field_num, field_len;
  char field_typ;
  int i;

  buff = (FS_fList)malloc(MAX_FLIST_SIZE);
  if (buff == NULL) {
    MEMERR("FSfList", MAX_FLIST_SIZE);
    exit(ERR_MEMORY);
  }
  last = &buff[MAX_FLIST_SIZE-1];
  va_start(pa,panel);
  p = buff;
  lastFullField = p;
  for (i=0; i < panel->field_count; i++) {
    field_num = panel->field_number[i];
    if (p>last) break;
    *p++ = field_num;
    val = va_arg(pa,Field_Value *);
    if (val == NULL) continue;
    field_len = val->field_length;
    field_typ = panel->field_type[i];
    if (field_typ <= '1') {                    /* two-byte length field */
      if (p+1>last) break;
      if (field_typ == '0') {
    	*p++ = (unsigned int)(-field_len) & 0xFF;
	*p++ = ((unsigned int)(-field_len) >> 8) & 0xFF;
      } else {
	*p++ = field_len % 256;
	*p++ = field_len / 256;
      }
    } else {                                   /* one-byte length field */
      if (p>last) break;
      *p++ = field_len;
    }
    if (last-p+1 < field_len) field_len = last-p+1;
    if (field_typ == '0') {
      memcpy(p, val->field_data, field_len);
    } else {
      trcpy(p, val->field_data, field_len, latinToDos);
    }
    p += field_len;
    lastFullField = p;
  }
  va_end(pa);
  *lastFullField++ = 0;
  key = (FS_ifList) malloc(lastFullField-buff);
  if (key == NULL) {
    MEMERR("FSfList", lastFullField-buff);
  } else {
    memcpy(key, buff, lastFullField-buff);
  }
  free(buff);
  return key;
}

Field_Value *FSnow()
{
  struct tm *today;
  char *answer;
  Field_Value *fv;
  time_t long_time;

  time( &long_time );
  today = localtime( &long_time );
  answer = (char *)malloc(6);
  if (answer == NULL) {
    MEMERR("FSnow", 6);
    exit(ERR_MEMORY);
  }
  sprintf(answer,"%d",
    (today->tm_hour * 60 + today->tm_min) * 60 + today->tm_sec);
  fv = NewField('8',0,strlen(answer),answer);
  free(answer);
  return fv;
}

Field_Value *FStoday()
{
  struct tm *today;
  char *answer;
  Field_Value *fv;
  time_t long_time;

  time( &long_time );
  today = localtime( &long_time );
  answer = (char *)malloc(11);
  if (answer == NULL) {
    MEMERR("FStoday", 11);
    exit(ERR_MEMORY);
  }
  sprintf(answer,"%04d/%d/%d",
    today->tm_year+1900,today->tm_mon+1,today->tm_mday);
  fv = NewField('4',0,strlen(answer),answer);
  free(answer);
  return fv;
}

char *FSformatG(char *format, char *num)
{
  struct {
    char decimalChar;
    char thousandsChar;
    char signChar;
    char currencyChar;
    int digs1Len;
    int digs2Len;
    int digs2Min;
    char *picture;
  } parsedFormat;
  int i, j, exp;
  int neg;
  int digsLen, digs1Len, digs1Pad, digs2Len, digs2Pad, totLen;
  char *interim, *answer, *p, *q, *f;
  int leadingZero, trailingDigs, seenDecimal;

/* parse the format */
  p = format;
  *p++ == 'G';
  if (*p=='-' || *p=='(' || *p=='$' || *p=='Z' || *p=='*' || *p=='9') {
    parsedFormat.decimalChar = '.';
    parsedFormat.thousandsChar = ',';
  } else {
    parsedFormat.decimalChar = *p++;
    parsedFormat.thousandsChar = *p++;
  }
  if (*p=='-' || *p=='(') {
    parsedFormat.signChar = *p++;
  } else {
    parsedFormat.signChar = '\0';
  }
  if (*p=='$') {
    parsedFormat.currencyChar = *p++;
  } else {
    parsedFormat.currencyChar = '\0';
  }
  parsedFormat.digs1Len = 0;
  parsedFormat.digs2Len = 0;
  parsedFormat.digs2Min = 0;
  parsedFormat.picture = p;
  while (*p && *p!=parsedFormat.decimalChar) {
    if (*p=='Z' || *p=='*' || *p=='9') parsedFormat.digs1Len++;
    p++;
  }
  if (*p) {
    p++;
    while (*p) {
      if (*p=='Z' || *p=='*' || *p=='9') parsedFormat.digs2Len++;
      if (*p=='9') parsedFormat.digs2Min++;
      p++;
    }
  }

/* analyze num */

  neg = *num == '-' ? 1 : 0;
  for (i=neg; num[i]; i++) {
    if (num[i]=='E' || num[i]=='e') break;
  }
  digsLen = i - neg;
  if (num[neg+digsLen]) {
    exp = atoi(&num[neg+digsLen+1]);
  } else {
    exp = 0;
  }
  if (exp >= 0) {
    digs1Len = digsLen;
    digs1Pad = exp;
    digs2Len = 0;
    digs2Pad = 0;
  } else {
    exp = 0 - exp;
    if (exp < digsLen) {
      digs1Len = digsLen - exp;
      digs1Pad = 0;
      digs2Len = exp;
      digs2Pad = 0;
    } else {
      digs1Len = 0;
      digs1Pad = 1;
      digs2Len = digsLen;
      digs2Pad = (exp > digs2Len) ? exp - digs2Len : 0;
    }
  }

/* prepare intermediate result */

  totLen = (parsedFormat.signChar!='\0')
    + ((parsedFormat.currencyChar!='\0') * (digs1Len < parsedFormat.digs1Len))
    + strlen(parsedFormat.picture);
  interim = (char *)malloc(totLen+1);
  if (interim == NULL) {
    MEMERR("FSformatG", totLen+1);
    exit(ERR_MEMORY);
  }
  p = interim;
  for (i=digs1Len+digs1Pad; i<parsedFormat.digs1Len; i++) *p++ = '0';
  for (i=neg; i<neg+digs1Len; i++) *p++ = num[i];
  for (i=0; i<digs1Pad; i++) *p++ = '0';
  if (parsedFormat.digs2Len) {
    *p++ = '.';
    for (i=0; i<digs2Pad; i++) *p++ = '0';
    for (i=neg+digs1Len, j=0; j<digs2Len; i++,j++) {
      *p++ = num[i];
    }
    for (i=digs2Len+digs2Pad; i<parsedFormat.digs2Len; i++) *p++ = '0';
  }
  *p = '\0';

/* produce final result */

  answer = (char *)malloc(totLen+1);
  if (answer == NULL) {
    MEMERR("FSformatG", totLen+1);
    exit(ERR_MEMORY);
  }
  p = answer;
  leadingZero = 1;
  q = interim;
  f = parsedFormat.picture;
  trailingDigs = digs2Pad+digs2Len;
  if (parsedFormat.digs2Min > trailingDigs)
    trailingDigs = parsedFormat.digs2Min;
  seenDecimal = 0;
  while (*f && *f!=';' && *f!=':') {
    if (leadingZero && (*f==parsedFormat.decimalChar || *f=='9' || 
	((*f=='*' || *f=='Z') && '1'<=*q && *q<='9'))) {
      leadingZero = 0;
      if (parsedFormat.signChar) *p++ = (neg ? parsedFormat.signChar : ' ');
      if (parsedFormat.currencyChar) *p++ = parsedFormat.currencyChar;
    }
    switch(*f) {
    case 'Z':
      if (*q=='0' && (leadingZero || (seenDecimal && trailingDigs<=0))) {
	*p++ = ' ';
      } else {
	*p++ = *q;
      }
      if (seenDecimal && trailingDigs) trailingDigs--;
      q++;
      break;
    case '*':
      if (*q=='0' && (leadingZero || (seenDecimal && trailingDigs<=0))) {
	*p++ = '*';
      } else {
	*p++ = *q;
      }
      if (seenDecimal && trailingDigs) trailingDigs--;
      q++;
      break;
    case '9':
      *p++ = *q++;
      if (seenDecimal && trailingDigs) trailingDigs--;
      break;
    case ')':
      if (neg && parsedFormat.signChar=='(') *p++ = *f;
      break;
    default:
      if (*f == parsedFormat.decimalChar) {
	seenDecimal = 1;
	leadingZero = 0;
	q++;
      }
      if (leadingZero || trailingDigs<0) {
	*p++ = ' ';
      } else {
	*p++ = *f;
      }
    }
    f++;
    *p = '\0';
  }
  free(interim);
  return answer;
}

char *FSformatN(char *format, char *num)
{
  char *answer, *p;

  *format++ == 'N';
  p = answer = (char *)malloc(strlen(format));
  if (answer == NULL) {
    MEMERR("FSformatN", strlen(format));
    exit(ERR_MEMORY);
  }
  while (*format &&
      !((*format==';' && *(format+1)==';') 
	|| (*format==':' && *(format+1)==':'))) {
    if (*format == '9') {
      *p++ = (*num) ? *num++ : '0';
    } else {
      *p++ = *format;
    }
    format++;
  }
  return answer;
}

char *FSformatD(char *format, char *date)
{
  char *answer, *p;
  int year, month, day;
  char dateAsNum[9], *dan;

  *format++ == 'D';
  p = date;
  year = atoi(p);
  while (*p && *p++!= '/') ;
  month = atoi(p);
  while (*p && *p++!= '/') ;
  day = atoi(p);
  sprintf(dateAsNum,"%02d%02d%04d",month,day,year);
  dan = dateAsNum;
  p = answer = (char *)malloc(strlen(format));
  if (answer == NULL) {
    MEMERR("FSformatD", strlen(format));
    exit(ERR_MEMORY);
  }
  while (*format &&
      !((*format==';' && *(format+1)==';') 
	|| (*format==':' && *(format+1)==':'))) {
    if (*format == '9') {
      *p++ = (*dan) ? *dan++ : '0';
    } else {
      *p++ = *format;
    }
    format++;
  }
  *p = '\0';
  return answer;
}

char *FSformatU(char *format, char *s)
{
  char *answer, *p;
  int totLen, trimBlanks, i;

  *format++ == 'U';
  totLen = atoi(format) + 1;
  p = answer = (char *)malloc(totLen);
  if (answer == NULL) {
    MEMERR("FSformatU", totLen);
    exit(ERR_MEMORY);
  }
  while (*format && !(*format==';' && *(format+1)==';')) format++;
  trimBlanks = (*format==';' && *(format+2)=='B');
  if (trimBlanks) while (*s==' ') s++;
  for (i=0; i<totLen-1; i++, p++) {
    if (trimBlanks && !*s) break;
    *p = (*s) ? toupper(*s++) : ' ';
  }
  *p = '\0';
  if (trimBlanks) {
    for (i=strlen(answer)-1; i>=0 && answer[i]==' '; i--) ;
    answer[i+1] = '\0';
  }
  return answer;
}

char *FSformatA(char *format, char *s)
{
  char *answer, *p;
  int totLen, trimBlanks, i;

  *format++ == 'A';
  totLen = atoi(format) + 1;
  p = answer = (char *)malloc(totLen);
  if (answer == NULL) {
    MEMERR("FSformatA", totLen);
    exit(ERR_MEMORY);
  }
  while (*format && !(*format==';' && *(format+1)==';')) format++;
  trimBlanks = (*format==';' && *(format+2)=='B');
  if (trimBlanks) while (*s==' ') s++;
  for (i=0; i<totLen-1; i++, p++) {
    if (trimBlanks && !*s) break;
    *p = (*s) ? *s++ : ' ';
  }
  *p = '\0';
  if (trimBlanks) {
    for (i=strlen(answer)-1; i>=0 && answer[i]==' '; i--) ;
    answer[i+1] = '\0';
  }
  return answer;
}

int FSrecCount(FS_panel p)
{
  WUDWORD recCount = 0;
  WSWORD err;

  if (p->constraint) {
    err = dpe_SubLastRec(
	    p->pba, 
	    p->constraint, 
	    &recCount);
  } else {
    err = dpe_FirstRec(
	    p->pba, 
	    p->current_index->index_number, 
	    &recCount);
  }
  if (err) {
    recCount = 0;
  }
  return recCount;
}

char bufT[25];

char *FSformatT(char *format, char *num)
{
  int hour, minute, second, t, amFlag;

  t = atoi(num);
  hour = t / 3600;
  amFlag = hour < 12;
  minute = t / 60 - hour * 60;
  second = t % 60;
  if (hour > 12) hour = hour - 12;
  if (hour == 0) hour = 12;
  *format++ == 'T';
  if (strlen(format) == 8) {
    sprintf(bufT,"%d:%02d:%02d&nbsp;%s",hour,minute,second,
      amFlag ? "a.m." : "p.m.");
  } else {
    sprintf(bufT,"%d:%02d&nbsp;%s",hour,minute,
      amFlag ? "a.m." : "p.m.");
  }
  return bufT;
}
