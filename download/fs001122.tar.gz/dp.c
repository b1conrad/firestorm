#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#ifdef WIN32
#include "e:\engine\machine.h"
#include "e:\engine\dpif.h"
#include "e:\engine\pba.h"
#include "e:\engine\map.h"
#else
#include "machine.h"
#include "dpif.h"
#include "pba.h"
#include "map.h"
#endif

int do_command(char *input);

#define PRIMARY_PROMPT "> "
#define SECONDARY_PROMPT "? "

#define OK              0
typedef enum { FALSE=0, TRUE=1 } bool;

#define ERR_PGM_PANIC 100
#define ERR_MEMORY    101
#define ERR_PARAMETER 102
#define ERR_DP_PANIC  103
#define ERR_CMD_PANIC 104

#define ERR_DP(err)   err
#define ERR_DP_EOF    511
#define ERR_DP_NOEQ   772
#define ERR_DP_NOKEY  773

#define ASSERT(truth)                                                   \
if (!(truth)) {                                                         \
  if (Interactive)                                                      \
  fprintf(stderr, "%s: Assertion '%s' failed at line #%d, file '%s'\n", \
    ProgramName, #truth, __LINE__, __FILE__);                           \
  exit(ERR_PGM_PANIC);                                                  \
}

#define MEMERR(fctname,sz)                                          \
  if (Interactive)                                                  \
  fprintf(stderr, "%s: %s() -- malloc(%d) failed\n", ProgramName, fctname, sz); 

char *ProgramName;
Panel_Info *CurrentPanel;
int Interactive;
int ArgumentCount;
char **ArgumentVector;
bool tlogFlag = FALSE;

FILE *OpenLogFile(void)
{
  WUDWORD gennum = 0;
  char tlogName[12];
  WSWORD err;
  FILE *tlogOut;

  err = dpe_GenNum(CurrentPanel->pba, &gennum);
  if (err != 0) exit(ERR_DP(err));
  sprintf(tlogName, "G%10.10lu", gennum);
  tlogOut = fopen(tlogName, "w");
  if (tlogOut == NULL) exit(ERR_PGM_PANIC);
  return tlogOut;
}

void LogString(FILE *file, int length, char *string)
{
  register FILE *fp = file;
  register int len = length;
  register char *s = string;
  register char c;

  putc('"', fp);
  while (len--) {
    c = *s++;
    putc(c, fp);
    if (c=='"') {
      putc('"', fp);
    }
  }
  putc('"', fp);
}

void LogCreation(Record rec)
{
  FILE *tlogOut;
  int i;

  if (tlogFlag) {
    tlogOut = OpenLogFile();
    fprintf(tlogOut, "#C: \n=%d=", CurrentPanel->panel_number);
    for (i=0; i<rec.field_count; i++) {
      fprintf(tlogOut, "*%d", rec.field[i]->field_number);
      LogString(tlogOut, 
        rec.field[i]->field_length, rec.field[i]->field_data);
    }
    fprintf(tlogOut, "**\n");
    fflush(tlogOut);
    fclose(tlogOut);
  }
}


void LogDeletion(WUBYTE *key)
{
  FILE *tlogOut;
  int i, fieldNumber, fieldLength, fieldIndex;

  if (tlogFlag) {
    tlogOut = OpenLogFile();
    fprintf(tlogOut, "#D: \n=%d=%d", 
      CurrentPanel->panel_number, *key++);
    while (*key) {
      fieldNumber = *key++;
      fieldLength = *key++;
      fieldIndex = FindFieldIndex(CurrentPanel, fieldNumber);
      if (CurrentPanel->field_type[fieldIndex] == '1') {
        fieldLength += 256 * (*key++);
      }
      fprintf(tlogOut, "+%d", fieldNumber);
      LogString(tlogOut, fieldLength, key);
      key += fieldLength;
    }
    fprintf(tlogOut, "++\n");
    fflush(tlogOut);
    fclose(tlogOut);
  }
}

#ifdef TRACE_DP
FILE *traceOut;

void dumpChar(FILE *fp, unsigned char c)
{
  if (c < ' ' || c > '~' || c == '#') {
    fprintf(fp, "#%03d", 0xFF & (unsigned int) c);
  } else {
    fprintf(fp, "%c", c);
  }
}

void dumpString(FILE *fp, char *s, int len)
{
  while (len>0) {
    len--;
    dumpChar(fp, *s++);
  }
}
#endif

int BLOBfromFile(WUBYTE *buff, int buffSize)
{
  int len;

  FILE *fp = fopen(buff, "rb");
  if (fp==NULL) return -1;
  len = fread(buff, sizeof(buff[0]), buffSize, fp);
  if (!feof(fp)) {
    return -1;
  } else if (ferror(fp)) {
    return -1;
  }
  fclose(fp);
  return len;
}

char *get_input(char *input, int size)
{
  unsigned char *p;
  int len;

  if (ArgumentCount > 0) {
    strncpy(input, *ArgumentVector++, size);
    input[size-1] = 0;
    ArgumentCount--;
  } else {
    if (!Interactive) {
      printf("Not enough parameters given\n");
      exit(ERR_PARAMETER);
    }
    if (fgets(input, size, stdin) == NULL) {
      printf("Premature end-of-file\n");
      exit(ERR_CMD_PANIC);
    }
    len = strlen(input); /* fgets guarantees null terminator */
    if (input[len-1] == '\n') {
      input[len-1] = 0; /* overwrite the newline */
    }
  }

#ifdef TRACE_DP
fprintf(traceOut, " get_input external value: ");
dumpString(traceOut, input, strlen(input));
fprintf(traceOut, "\n get_input internal value: ");
#endif
  for (p=input; *p != 0; p++) {
    *p = latinToDos[0xFF & *p];
#ifdef TRACE_DP
dumpChar(traceOut, *p);
#endif
  }
#ifdef TRACE_DP
fprintf(traceOut, "\n");
fflush(traceOut);
#endif
  return input;
}

/* return a heap-allocated Pascal string copy of the input C string */
unsigned char *NewPstr(char *Cstr) 
{
  register int len;
  register char *s, *t;
  unsigned char *Pstr;
  
  len = strlen(Cstr);
  ASSERT(len <= 255);
  Pstr = (unsigned char *) malloc(len+1);
  if (Pstr == NULL) {
    MEMERR("NewPstr", len+1);
    exit(ERR_MEMORY);
  }
  
  Pstr[0] = len;
  for (s=Cstr, t=(char *)Pstr+1; len>0; len--) {
    *t++ = *s++;
  }
  return Pstr;
}

Panel_Info *FindPanel(int panelNumberToFind)
{
  register int i;
  
  for (i=0; i<panel_count; i++) {
    if (panel[i].panel_number == panelNumberToFind) return &panel[i];
  }
  return NULL;
}

Index_Info *FindIndex(int indexNumberToFind)
{
  register int i;
  
  for (i=0; i<CurrentPanel->index_count; i++) {
    if (CurrentPanel->index[i]->index_number == indexNumberToFind) {
      return CurrentPanel->index[i];
    }
  }
  return NULL;
}

int FindFieldIndex(Panel_Info *panel, int field_num)
{
  int i;

  for (i=0; i < panel->field_count; i++) {
    if (panel->field_number[i] == field_num) return i;
  }
  return -1;
}

int InitRecord(char *fctname, Record *rec, int field_count)
{
  int i;

  rec->field_count = field_count;
  rec->field = (Field_Value **) malloc(sizeof(rec->field[0])*field_count);
  if (rec->field == NULL) {
    MEMERR(fctname, sizeof(rec->field[0])*field_count);
    rec->field_count = 0;
    return -1;
  } 
  for (i=0; i < field_count; i++) {
    rec->field[i] = NULL;
  }
  return 0;
}

Field_Value *NewField(
  char field_type,
  short int field_number,
  unsigned short int field_length,
  char *field_data)
{
  Field_Value *fv;

  fv  = (Field_Value *) malloc(sizeof(*fv)+field_length);
  if (fv == NULL) { exit(ERR_MEMORY); }
  fv->field_type = field_type;
  fv->field_number = field_number;
  fv->field_length = field_length;
  memcpy(fv->field_data, field_data, field_length);
  fv->field_data[field_length] = '\0';
  return fv;
}

Record DuplicateRecord(Record in)
{
  Record out;
  int i, error;
  Field_Value *fv;

  error = InitRecord("DuplicateRecord", &out, in.field_count);
  if (error) exit(ERR_MEMORY); 
  for (i=0; i<in.field_count; i++) {
    fv = (Field_Value *) malloc(sizeof(*fv)+in.field[i]->field_length);
    if (fv == NULL) {
      MEMERR("DuplicateRecord", sizeof(*fv)+in.field[i]->field_length);
      exit(ERR_MEMORY);
    }
    fv->field_type = in.field[i]->field_type;
    fv->field_number = in.field[i]->field_number;
    fv->field_length = in.field[i]->field_length;
    memcpy(fv->field_data, in.field[i]->field_data, fv->field_length+1);
    out.field[i] = fv;
  }
  return out;
}

Record InitRecordFromKey(WUBYTE *key)
{
  Record out;
  int error;
  Field_Value *fv;
  int fn, fl, fi;
  char ft;

  error = InitRecord("InitRecordFromKey", &out, CurrentPanel->field_count);
  if (error) exit(ERR_MEMORY); 
  key++;
  while (*key) {
    fn = *key++;
    fi = FindFieldIndex(CurrentPanel, fn);
    ft = CurrentPanel->field_type[fi];
    ASSERT(ft != '0');
    fl = *key++;
    if (ft == '1') fl = fl + (256 * *key++);
    fv = (Field_Value *) malloc(sizeof(*fv)+fl);
    if (fv == NULL) {
      MEMERR("InitRecordFromKey", sizeof(*fv)+fl);
      exit(ERR_MEMORY);
    }
    fv->field_type = ft;
    fv->field_number = fn;
    fv->field_length = fl;
    memcpy(fv->field_data, key, fl);
    key += fl;
    fv->field_data[fl] = 0;
    out.field[fi] = fv;
  }
  return out;
}

WUBYTE *BuildFieldList(Record *rec, bool includeBLOBs)
{
  int i, field_num, field_len, field_wid;
  char field_typ, *field_dat;
  Field_Value *fv;
  WUBYTE buff[8000], *after, *flist, *p;

  p = buff;
  after = buff + sizeof(buff);
  for (i=0; i < rec->field_count; i++) {
    fv = rec->field[i];
    if (fv==NULL) continue;
    field_typ = fv->field_type;
    field_num = fv->field_number;
    field_len = fv->field_length;
    field_dat = fv->field_data;
    field_wid = (field_typ <= '1') ? 2 : 1;

    if (field_typ=='0' && !includeBLOBs) continue;

    if (p+1+field_wid+field_len >= after) {
      printf("BuildFieldList() -- please increase buff[] size\n");
      exit(ERR_PARAMETER);
    }
    *p++ = field_num;
    if (field_wid == 2) {
      if (field_typ == '0') {
	*p++ = (unsigned int)(-field_len) & 0xFF;
	*p++ = ((unsigned int)(-field_len) >> 8) & 0xFF;
      } else {
	*p++ = field_len % 256;
	*p++ = field_len / 256;
      }
    } else {
      *p++ = field_len;
    }
    memcpy(p, field_dat, field_len);
    p += field_len;
  }
  *p++ = 0;

  flist = (WUBYTE *) malloc(p-buff);
  if (flist == NULL) {
    MEMERR("BuildFieldList", p-buff);
    exit(ERR_MEMORY);
  } else {
    memcpy(flist, buff, p-buff);
  }
  return flist;
}

#ifdef TRACE_DP
void dumpFieldList(FILE *fp, WUBYTE *flist)
{
  WUBYTE *p;
  unsigned int i;

  p = flist;
  while(*p) {
    fprintf(fp, "%d={", *p++);
    i = *p++;
    if (*p == 0) { /* assume this is a text field */
      p++;
    }
    while(i-- > 0) dumpChar(fp, *p++);
    fprintf(fp, "} ");
  }
  dumpChar(fp, 0);
}
#endif

void PrintKey(WUBYTE *key)
{
  WUBYTE *p;
  unsigned int i;

  p = key;
  printf("key %d: ", *p++);
  while(*p) {
    printf("%d={", *p++);
    for(i=*p++; i; i--) printf("%c", *p++);
    printf("} ");
  }
  printf("0\n");
}


WUBYTE *BuildKey(Panel_Info *panel, Record rec)
{
  int i, field_num, field_idx, field_len;
  Index_Info *index;
  Field_Value *fv;
  WUBYTE buff[256], *last, *key, *p, *lastFullField;

  ASSERT(rec.field!=NULL);

  index = panel->current_index;
  p = buff;
  last = &buff[255];
  
  *p++ = (WUBYTE) index->index_number;
  lastFullField = p;

  for (i=0; i < index->index_size; i++) {

    field_num = index->field_number[i];
    if (p>last) break;
    *p++ = field_num;

    field_idx = FindFieldIndex(panel, field_num);
    ASSERT(field_idx >= 0);
    fv = rec.field[field_idx];
    field_len = fv->field_length;
    ASSERT(field_num == fv->field_number);
    ASSERT(panel->field_type[field_idx] != '0');
    if (panel->field_type[field_idx] == '1') {
      /* two-byte length field */
      if (p+1>last) break;
      *p++ = field_len % 256;
      *p++ = field_len / 256;
    } else {
      /* one-byte length field */
      if (p>last) break;
      *p++ = field_len;
    }

    if (last-p+1 < field_len) field_len = last-p+1;
/*
9501292224
    if (field_len <= 1) break;
*/
    memcpy(p, fv->field_data, field_len);
    p += field_len;

    lastFullField = p;
  }
  
  *lastFullField++ = 0;

  key = (WUBYTE *) malloc(lastFullField-buff);
  if (key == NULL) {
    MEMERR("BuildKey", lastFullField-buff);
  } else {
    memcpy(key, buff, lastFullField-buff);
  }
  return key;
}

void DisposeRecord(Record *rec)
{
  int i;

  ASSERT(rec != NULL);
  for (i=0; i < rec->field_count; i++) {
    free(rec->field[i]);
    rec->field[i] = NULL;
  }
  if (rec->field) {
    free(rec->field);
  }
  rec->field_count = 0;
  rec->field = NULL;
}

void GetRecord(Panel_Info *panel, Cursor *rec)
{
  int i, j, len, width;
  WSWORD err;
  WUWORD type;
  WUBYTE fldnfo[16];
  WUBYTE *buff;
  Field_Value *field;

  DisposeRecord(&rec->pos);
  rec->where = VALID; /* now load the position field */
  if (InitRecord("GetRecord", &rec->pos, panel->field_count) != 0) {
    exit(ERR_MEMORY);
  }
  strncpy(fldnfo, " \5A1;;T", sizeof(fldnfo));
  buff = (WUBYTE *)malloc(32000);
  if (buff == NULL) {
    MEMERR("GetRecord", 32000);
    exit(ERR_MEMORY);
  }
for (i=0; i<32000; i++) buff[i] = 'X';
  for (i=0; i < panel->field_count; i++) { 
    fldnfo[0] = panel->field_number[i]; 
    if (panel->field_type[i] == '0') {
      err = dpe_GetBlob(panel->pba, fldnfo, &type, 32000, buff);
    } else {
      err = dpe_GetField(panel->pba, fldnfo, &type, 32000, buff);
    }
    if (err == 0) {
      if (panel->field_type[i]<='1') { /* TEXT field type */
        len = buff[0] + 256*buff[1];  /* two-byte length field */
        width = 2;
      } else {
        len = buff[0];                /* one-byte length field */
        width = 1;
      }
#ifdef TRACE_DP
 fprintf(traceOut, "dpe_GetField returned: ");
 dumpString(traceOut, buff, len+1+(panel->field_type[i]<='1'));
 fprintf(traceOut, "\n");
#endif
      for (j=len+width-1; j > width; j--) {
        if (buff[j] != ' ') break;
      }
      if (j<len+width-1) {
        buff[j+1] = 0;
        len = j + 1 - width;
      }
      field = (Field_Value *) malloc(sizeof(Field_Value) + len);
      if (field == NULL) {
        DisposeRecord(&rec->pos);
        MEMERR("GetRecord", sizeof(Field_Value) + len);
        exit(ERR_MEMORY);
      }
      field->field_type = panel->field_type[i];
      field->field_number = panel->field_number[i];
      field->field_length = len;
      memcpy(field->field_data, buff+width, len);
      field->field_data[len] = 0;
      rec->pos.field[i] = field;
    } else {
      DisposeRecord(&rec->pos);
      if (Interactive) {
	printf("  dpe_GetField() failed (#%d)\n", err); 
      }
      exit(ERR_DP(err));
    }
  }
  free(buff);
}

void PrintField(Record rec, unsigned char field_number)
{
  int i, last;
  unsigned char c, *p;
  Field_Value *fv;

  p = memchr(CurrentPanel->field_number,field_number,CurrentPanel->field_count);
  ASSERT(p!=NULL);
  i = p - CurrentPanel->field_number;
  fv = rec.field[i];
  if (fv != NULL) {
#ifdef TRACE_DP
fprintf(traceOut,   "PrintField internal value: ");
dumpString(traceOut, fv->field_data, fv->field_length);
fprintf(traceOut, "\n PrintField printed value: ");
#endif
    if (fv->field_type == '0') {
      printf("Blob(%d)", fv->field_length);
    } else {
      for (last=fv->field_length-1; 
	last>=0 && fv->field_data[last]==' '; last--) ;
    for (i=0; i <= last; i++) {
      c = fv->field_data[i];
      c = dosToLatin[0xFF & c];
      switch (c) {
      case '\t': putchar('\\'); putchar('t'); 
#ifdef TRACE_DP
dumpChar(traceOut, '\\'); dumpChar(traceOut, 't'); 
#endif
                 break;
      case '\n': putchar('\\'); putchar('n'); 
#ifdef TRACE_DP
dumpChar(traceOut, '\\'); dumpChar(traceOut, 'n'); 
#endif
                 break;
      case '\\': putchar('\\'); putchar('\\'); 
#ifdef TRACE_DP
dumpChar(traceOut, '\\'); dumpChar(traceOut, '\\'); 
#endif
                 break;
      case '"': putchar('\\'); putchar('"');
#ifdef TRACE_DP
dumpChar(traceOut, '\\'); dumpChar(traceOut, '"');
#endif
	     break;
      default:   putchar(c); 
#ifdef TRACE_DP
dumpChar(traceOut, c);
#endif
                 break;
	}
      }
    }
#ifdef TRACE_DP
fprintf(traceOut, "\n");
fflush(traceOut);
#endif
  }
}

void PrintRecord(Record rec)
{
  int i, len;
  unsigned char *field_num;
  char sepF, sepR;

  field_num = CurrentPanel->fields_to_print;
  if (field_num==NULL) {
    field_num = CurrentPanel->field_number; /* not NUL-terminated */
    len = CurrentPanel->field_count;
  } else {
    len = strlen(field_num);
  }
  ASSERT(field_num != NULL);
  if (Interactive) {
    sepF = '\n';
    sepR = '\n';
  } else {
    sepF = '\t';
    sepR = '\n';
  }
  for (i=0; i < len; i++) { 
    PrintField(rec, field_num[i]);
    printf("%c", i==len-1 ? sepR : sepF);
  }
}

#if 0
int RefreshCursor(Panel_Info *panel)
{
/* COMMENTED OUT 960126
  WUBYTE *key;
*/
  WSWORD err;
  WUDWORD recCount;

  if (panel->cursor.where == VALID) {
/* COMMENTED OUT 960126
    key = BuildKey(panel, panel->cursor.pos);
    if (Interactive) {
      printf("RefreshCursor ");
      PrintKey(key);
    }
    err = dpe_EqualRec(panel->pba, key, &recCount);
    if (recCount == 0) {
      panel->cursor.where = BEFORE;
      err = 0;
    } else if (err == ERR_DP_NOEQ) {
      if (Interactive) { printf("  dpe_EqualRec() failed (#%d)\n", err); }
      err = dpe_NextRec(panel->pba, key, &recCount);
      if (err == ERR_DP_NOKEY) {
	if (Interactive) printf("  dpe_NextRec() failed (#%d)\n", err); 
	panel->cursor.where = AFTER;
	err = 0;
      } else if (err == 0) {
	panel->cursor.where = VALID;
      }
    }

    if (err == 0) {
      GetRecord(panel, &panel->cursor);
    } else {
      if (Interactive) {
	printf(" dpe_EqualRec or dpe_NextRec failed (#%d)\n", err);
      } else {
	exit(ERR_DP(err));
      }
    }
*/
  } else if (Interactive) {
    err = dpe_RecCnt(panel->pba, &recCount);
    if (recCount == 0) {
      printf(" No records\n");
    } else {
      printf(" At %s\n", panel->cursor.where == BEFORE ? "Beginning" : "End");
    }
  }

  return panel->cursor.where == VALID;
}
#endif

typedef struct record_entry {
  Record rec;
  struct record_entry *next;
} *RecordList;

RecordList NewRecordEntry(Record rec)
{
  RecordList entry;

  entry = (RecordList) malloc(sizeof (*entry));
  if (entry == NULL) {
    MEMERR("NewRecordEntry", sizeof(*entry));
  }
  entry->rec = rec;
  entry->next = NULL;
  return entry;
}

Field_Value *GetField(short int field_number, Record rec)
{
  int i;

  for (i=0; i<rec.field_count; i++) {
    if (rec.field[i]->field_number == field_number) {
      return (rec.field[i]);
    }
  }
  return NULL;
}

int strnecmp(char *s, char *p, int l)
{
  char c, d;

  while (l--) {
    c = *s++; d = *p++;
    if (islower(c)) { c = toupper(c); }
    if (islower(d)) { d = toupper(d); }
    if (c != d) return c-d;
    if (c==0) break;
  }
  return 0;
}

int MeetsConstraint(WUBYTE *constraint, Cursor cursor)
{
  WUBYTE *p;
  WUWORD len;
  short int field_number;
  char field_type;
  Field_Value *f;

  if (cursor.where != VALID) { return 0; }
  if (constraint == NULL) { return 1; }

  for (p=constraint+1; *p; p+=len) {
    field_number = *p++;
    f = GetField(field_number, cursor.pos);
    if (f == NULL) { return 0; }
    field_type = f->field_type;
    ASSERT(field_type != '0');
    len = *p++;
    if (field_type == '1') {
      len += *p++ * 256;
    }
    if  (field_type >= '2' && field_type <= '8') {
      /* numeric, time or date value; check for equality */
      if (len != f->field_length || strncmp(p, f->field_data, len) != 0) {
        return 0;
      }
    } else {
      /* text or alpha field value; check for prefix */
      if (len > f->field_length || strnecmp(p, f->field_data, len) != 0) {
        return 0;
      }
    }
  }
  return 1;
}

int MeetsRestriction(Record restrict, Cursor cursor)
{
  int i;
  Field_Value *rfv, *cfv;

  if (cursor.where != VALID) { return 0; }
  if (restrict.field_count == 0) { return 1; }
return 1;

  for (i=0; i < restrict.field_count; i++) {
    rfv = restrict.field[i];
    if (rfv == NULL) { continue; }
    cfv = GetField(rfv->field_number, cursor.pos);
    if (cfv == NULL) { return 0; }
    if (rfv->field_length > cfv->field_length 
    || strnecmp(rfv->field_data, cfv->field_data, rfv->field_length) != 0) {
      return 0;
    }
  }
  return 1;
}

WSWORD GetFirst(void)
{
  WUDWORD recCount;
  WSWORD err;

  if (CurrentPanel->constraint) {
    err = dpe_SubLastRec(
            CurrentPanel->pba, 
            CurrentPanel->constraint, 
            &recCount);
    if (err == 0) {
      err = dpe_SubFirstRec(
	      CurrentPanel->pba, 
	      CurrentPanel->constraint, 
	      &recCount);
    }
  } else {
    err = dpe_FirstRec(
	    CurrentPanel->pba, 
	    (WUWORD)CurrentPanel->current_index->index_number, 
	    &recCount);
  }
  if (err != 0 || recCount == 0) {
    if (err && Interactive) {
      printf("  dpe_[Sub]FirstRec() failed (#%d)\n", err); 
    }
    DisposeRecord(&CurrentPanel->cursor.pos);
    CurrentPanel->cursor.where = BEFORE;
  } else {
    CurrentPanel->cursor.where = VALID;
    GetRecord(CurrentPanel, &CurrentPanel->cursor);
    if (!MeetsConstraint(CurrentPanel->constraint, CurrentPanel->cursor)) {
      DisposeRecord(&CurrentPanel->cursor.pos);
      CurrentPanel->cursor.where = BEFORE;
    }
  }
  return err;
}
      

void GetFirstOrDie(void)
{
  WSWORD err;

  err = GetFirst();
  if (CurrentPanel->cursor.where != VALID && !Interactive) {
    printf("No records found (#%d)\n", err); 
    exit(ERR_DP(err));
  }
}

void GetLast(void)
{
  WUDWORD recCount;
  WSWORD err;

  if (CurrentPanel->constraint) {
    err = dpe_SubLastRec(
            CurrentPanel->pba, 
            CurrentPanel->constraint, 
            &recCount);
  } else {
    err = dpe_LastRec(
            CurrentPanel->pba, 
            CurrentPanel->current_index->index_number, 
            &recCount);
  }
  if (err != 0) {
    if (Interactive) {
      printf("  dpe_[Sub]LastRec() failed (#%d)\n", err); 
    } else {
      printf("No records found (#%d)\n", err); 
      exit(ERR_DP(err));
    }
  } else if (recCount == 0) {
    DisposeRecord(&CurrentPanel->cursor.pos);
    CurrentPanel->cursor.where = AFTER;
  } else {
    CurrentPanel->cursor.where = VALID;
    GetRecord(CurrentPanel, &CurrentPanel->cursor);
    if (!MeetsConstraint(CurrentPanel->constraint, CurrentPanel->cursor)) {
      DisposeRecord(&CurrentPanel->cursor.pos);
      CurrentPanel->cursor.where = BEFORE;
    }
  }
}

bool PositionBefore(Record rec)
{
  WUBYTE *key;
  WUDWORD recCount;
  WSWORD err;

  key = BuildKey(CurrentPanel, rec);
  if (Interactive) PrintKey(key);
  if (CurrentPanel->constraint) {
    err = dpe_SubPrevRec(
	    CurrentPanel->pba, key, CurrentPanel->constraint+1, &recCount);
  } else {
    err = dpe_PrevRec(CurrentPanel->pba, key, &recCount);
  }
  free(key);
  key = NULL;
  if (err == ERR_DP_NOKEY || err == ERR_DP_NOEQ) {
    return FALSE;
  } else if (err != 0) {
    if (Interactive) {
      printf("  dpe_[Sub]PrevRec() failed (#%d)\n", err); 
    } else {
      printf("No records found (#%d)\n", err); 
      exit(ERR_DP(err));
    }
    return FALSE;
  }
  return TRUE;
}

bool PositionAfter(Record rec)
{
  WUBYTE *key;
  WUDWORD recCount;
  WSWORD err;

  key = BuildKey(CurrentPanel, rec);
  if (Interactive) PrintKey(key);
  if (CurrentPanel->constraint) {
    err = dpe_SubNextRec(
	    CurrentPanel->pba, key, CurrentPanel->constraint+1, &recCount);
  } else {
    err = dpe_NextRec(CurrentPanel->pba, key, &recCount);
  }
  free(key);
  key = NULL;
  if (err == ERR_DP_NOKEY || err == ERR_DP_NOEQ) {
    return FALSE;
  } else if (err != 0) {
    if (Interactive) {
      printf("  dpe_[Sub]NextRec() failed (#%d)\n", err); 
    } else {
      printf("No records found (#%d)\n", err); 
      exit(ERR_DP(err));
    }
    return FALSE;
  }
  return TRUE;
}

RecordList GetPrev(int *count, Cursor start, bool setCursor, bool *anyBefore)
{
  RecordList entries = NULL;
  RecordList entry;
  Cursor curse;
  bool firstPositioning, positioned;

  curse.where = BEFORE;
  curse.pos.field = NULL;
  curse.pos.field_count = 0;

  *anyBefore = TRUE;
  if (start.where == BEFORE) {
    *anyBefore = FALSE;
    return NULL;
  } else if (start.where == AFTER) {
    GetLast();
    if (CurrentPanel->cursor.where == VALID) {
      entries = NewRecordEntry(DuplicateRecord(CurrentPanel->cursor.pos));
      (*count)--;
    } else {
      *anyBefore = FALSE;
      return NULL;
    }
  }

  firstPositioning = TRUE;
  while (*count > 0) {
    if (firstPositioning) {
      positioned = PositionBefore(CurrentPanel->cursor.pos);
      firstPositioning = FALSE;
    } else {
      positioned = curse.where==VALID && PositionBefore(curse.pos);
    }
    if (positioned) {
      curse.pos.field_count = 0;
      curse.pos.field = NULL;
      GetRecord(CurrentPanel, &curse);
      if (MeetsRestriction(CurrentPanel->restriction, curse)) {
	entry = NewRecordEntry(curse.pos);
	entry->next = entries;
	entries = entry;
	(*count)--;
      }
    } else {
      *anyBefore = FALSE;
      break;
    }
  }
  if (setCursor) {
    DisposeRecord(&CurrentPanel->cursor.pos);
    if (entries == NULL) {
      CurrentPanel->cursor.where = BEFORE;
    } else {
      CurrentPanel->cursor.pos = DuplicateRecord(entries->rec);
      CurrentPanel->cursor.where = VALID;
    }
  }
  if (*anyBefore) { 
    /* we haven't proven there aren't any records before, so check: */
    *anyBefore = (entries != NULL) && PositionBefore(entries->rec);
  }
  return entries;
}

RecordList GetNext(int *count, Cursor start, bool setCursor, bool *anyAfter)
{
  RecordList entries = NULL, tail = NULL;
  RecordList entry;
  Cursor curse;
  bool firstPositioning, positioned;

  curse.where = BEFORE;
  curse.pos.field = NULL;
  curse.pos.field_count = 0;

  *anyAfter = TRUE;
  if (start.where == AFTER) {
    *anyAfter = FALSE;
    return NULL;
  } else if (start.where == BEFORE) {
    GetFirst();
    if (CurrentPanel->cursor.where == VALID) {
      entry = NewRecordEntry(DuplicateRecord(CurrentPanel->cursor.pos));
      entries = tail = entry;
      (*count)--;
    } else {
      *anyAfter = FALSE;
      return NULL;
    }
  }
  firstPositioning = TRUE;
  while (*count > 0) {
    if (firstPositioning) {
      positioned = PositionAfter(CurrentPanel->cursor.pos);
      firstPositioning = FALSE;
    } else {
      positioned = curse.where==VALID && PositionAfter(curse.pos);
    }
    if (positioned) {
      curse.pos.field_count = 0;
      curse.pos.field = NULL;
      GetRecord(CurrentPanel, &curse);
      if (MeetsRestriction(CurrentPanel->restriction, curse)) {
	entry = NewRecordEntry(curse.pos);
	if (tail != NULL) {
	  tail->next = entry;
	} else {
	  entries = entry;
	}
	tail = entry;
	(*count)--;
      }
    } else {
      *anyAfter = FALSE;
      break;
    }
  }
  if (setCursor) {
    DisposeRecord(&CurrentPanel->cursor.pos);
    if (entries == NULL) {
      CurrentPanel->cursor.where = AFTER;
    } else {
      CurrentPanel->cursor.pos = DuplicateRecord(tail->rec);
      CurrentPanel->cursor.where = VALID;
    }
  }
  if (*anyAfter) { 
    /* we haven't proven there aren't any records after, so check: */
    *anyAfter = (tail != NULL) && PositionAfter(tail->rec);
  }
  return entries;
}

void PrintRecordList(RecordList list)
{
  while (list != NULL) {
    PrintRecord(list->rec);
    list = list->next;
  }
}

void DisposeRecordList(RecordList list)
{
  RecordList next;

  while (list != NULL) {
    next = list->next;
    DisposeRecord(&list->rec);
    free(list);
    list = next;
  }
}

void do_panel(char *input)
{
  int n;
  Panel_Info *p;
  WUDWORD reccnt;
  WSWORD err;

  n = atoi(input+1);
  p = FindPanel(n);
  if (p == NULL) {
    if (Interactive) {
      printf("there are %d panels:", panel_count);
      for (n=0; n<panel_count; n++) {
	printf(" %d", panel[n].panel_number);
      }
      printf("\n");
    } else {
      printf("There is no panel #%d\n", n);
      exit(ERR_CMD_PANIC);
    }
  } else {
    CurrentPanel = p;
    err = dpe_RecCnt(CurrentPanel->pba, &reccnt);
    if (err == 0) {
      if (Interactive) {
        printf("  %ld records in panel %d\n", reccnt, CurrentPanel->panel_number);
        do_command("1");
      }
    } else {
      if (Interactive) {
	printf("  error #%d counting records in panel %d\n", 
	  err, CurrentPanel->panel_number);
      } else {
        exit(ERR_DP(err));
      }
    }
  }
}

void do_reindex(char *input)
{
  WSWORD err;
  WUWORD n;
  WUDWORD base;
  Index_Info *p;

  n = atoi(input+1);
  p = FindIndex(n);
  if (p == NULL) {
    if (Interactive) {
      printf("panel #%d indices:", CurrentPanel->panel_number);
      for (n=0; n<CurrentPanel->index_count; n++) {
	printf(" %d", CurrentPanel->index[n]->index_number);
      }
      printf("\n");
    } else {
      printf("There is no index #%d in panel #%d\n",
             n, CurrentPanel->panel_number);
      exit(ERR_CMD_PANIC);
    }
  } else {
    err = dpe_GenIndex(CurrentPanel->pba, n, &base);
    if (err) {
      printf("GenIndex failed (error #%d)\n", err);
      if (!Interactive) exit(ERR_CMD_PANIC);
    } else {
      printf("New base block is %ld\n", base);
    }
  }
}

void do_index(char *input)
{
  int n;
  Index_Info *p;

  n = atoi(input+1);
  p = FindIndex(n);
  if (p == NULL) {
    if (Interactive) {
      printf("panel #%d indices:", CurrentPanel->panel_number);
      for (n=0; n<CurrentPanel->index_count; n++) {
	printf(" %d", CurrentPanel->index[n]->index_number);
      }
      printf("\n");
    } else {
      printf("There is no index #%d in panel #%d\n",
             n, CurrentPanel->panel_number);
      exit(ERR_CMD_PANIC);
    }
  } else {
    CurrentPanel->current_index = p;
  }
}

void do_first(char *input)
{
  GetFirstOrDie();
  if (Interactive && CurrentPanel->cursor.where == VALID) {
    PrintRecord(CurrentPanel->cursor.pos);
  }
}

void do_last(char *input)
{
  GetLast();
  if (Interactive && CurrentPanel->cursor.where == VALID) {
    PrintRecord(CurrentPanel->cursor.pos);
  }
}

void do_prev(char *input)
{
  int count, Count;
  int outputRequired = 0;
  bool anyBefore, anyAfter;
  RecordList list;
  Cursor curse;

  count = atoi(input+1);
  if (count==0) {
    count = 1;
  } else {
    outputRequired = 1;
    Count = count;
  }

  anyAfter = CurrentPanel->cursor.where != AFTER; /* best guess */
  list = GetPrev(&count, CurrentPanel->cursor, TRUE, &anyBefore);
  if (count > 0) {
    if (outputRequired) {
      DisposeRecordList(list);
      curse.where = BEFORE;
      curse.pos.field_count = 0;
      curse.pos.field = NULL;
      count = Count;
      list = GetNext(&count, curse, FALSE, &anyAfter);
    } else {
      DisposeRecord(&CurrentPanel->cursor.pos);
      CurrentPanel->cursor.where = BEFORE;
    }
  }

  if (Interactive || outputRequired) {
    if (anyBefore) {
      if (outputRequired) printf("--More--\n");
    } else {
      if (outputRequired || list==NULL) printf("--Beginning--\n");
    }
    PrintRecordList(list);
    if (anyAfter) {
      if (outputRequired) printf("--More--\n");
    } else {
      if (outputRequired || list==NULL) printf("--End--\n");
    }
  }
  DisposeRecordList(list);
}

void do_all(char *input)
{
  GetFirst();
  if (CurrentPanel->cursor.where != VALID) {
    return;
  }
  for (;;) {
    if (MeetsRestriction(CurrentPanel->restriction, CurrentPanel->cursor)) {
      PrintRecord(CurrentPanel->cursor.pos);
    }
    if (!PositionAfter(CurrentPanel->cursor.pos)) {
      return;
    }
    GetRecord(CurrentPanel, &CurrentPanel->cursor);
  }
}


void do_next(char *input)
{
  int count, Count;
  int outputRequired = 0;
  bool anyBefore, anyAfter;
  RecordList list;
  Cursor curse;

  count = atoi(input+1);
  if (count==0) {
    count = 1;
  } else {
    outputRequired = 1;
    Count = count;
  }

  anyBefore = CurrentPanel->cursor.where != BEFORE; /* best guess */
  list = GetNext(&count, CurrentPanel->cursor, TRUE, &anyAfter);
  if (count > 0) {
    if (outputRequired) {
      DisposeRecordList(list);
      curse.where = AFTER;
      curse.pos.field_count = 0;
      curse.pos.field = NULL;
      count = Count;
      list = GetPrev(&count, curse, FALSE, &anyBefore);
    } else {
      DisposeRecord(&CurrentPanel->cursor.pos);
      CurrentPanel->cursor.where = AFTER;
    }
  }

  if (Interactive || outputRequired) {
    if (anyBefore) {
      if (outputRequired) printf("--More--\n");
    } else {
      if (outputRequired || list==NULL) printf("--Beginning--\n");
    }
    PrintRecordList(list);
    if (anyAfter) {
      if (outputRequired) printf("--More--\n");
    } else {
      if (outputRequired || list==NULL) printf("--End--\n");
    }
  }
  DisposeRecordList(list);
}

void do_open(char *input)
{
  int err;
  unsigned char *index_filename;
  unsigned char *text_filename;

  index_filename = NewPstr(ind_name); 
  text_filename = NewPstr(txx_name);  
  err = dpe_Init(index_filename, text_filename, sort_map);
  if (err != 0) {
    if (Interactive) {
      printf("%s: dpe_Init(\"%s\", \"%s\", sortmap) failed (#%d)\n", 
	ProgramName, ind_name, txx_name, err);
    }
    exit(1);
  }
  free(index_filename);
  free(text_filename);
}

void do_close(char *input)
{
  int err;

  err = dpe_CloseFiles();
  if (err != 0) {
    if (Interactive) {
      printf("%s: dpe_CloseFiles() failed (#%d)\n", ProgramName, err);
    }
    exit(1);
  }
}

Record GetRecordFromUser(Record defaultRec)
{
  int i, j, len;
  int fieldNumber;
  char fieldType;
  WUBYTE buff[8000];
  Record rec;
  Field_Value *field;


  if (InitRecord("GetRecordFromUser", &rec, CurrentPanel->field_count) != 0) {
    exit(ERR_MEMORY);
  }

  for (i=0; i < rec.field_count; i++) { 

    /* prompt for next field */
    fieldNumber = CurrentPanel->field_number[i];
    fieldType = CurrentPanel->field_type[i];
    if (Interactive) {
      if (defaultRec.field && defaultRec.field[i]) {
	printf(" %2d (%c): %s\n", fieldNumber, fieldType, 
             defaultRec.field[i]->field_data);
      }
      printf(" %2d (%c): ", fieldNumber, fieldType);
    }

    /* get the next field */
    if (get_input(buff, sizeof buff) == NULL) { /* EOF or error */
      printf("Unexpected end of input in GetRecordFromUser\n");
      exit(ERR_PARAMETER);
    }
    len = strlen(buff);
    while (len && buff[len-1]=='\\') {
      buff[len-1] = '\n';
      get_input(buff+len, (sizeof buff) - len);
      len = strlen(buff);
    }

    if (buff[0] == 0 && defaultRec.field && defaultRec.field[i]) {
      strncpy(buff, defaultRec.field[i]->field_data, sizeof buff);
      buff[sizeof buff -  1] = 0;
    }

    /* trim trailing blanks */
    len = strlen(buff);
    for (j=len-1; j > 0; j--) {
      if (buff[j] != ' ') break;
    }
    buff[j+1] = 0;
    len = j + 1;

    if (fieldType == '0') {
      len = BLOBfromFile(buff, sizeof buff);
      if (len < 0) {
	printf("Failed to load BLOB from file\n");
	exit(ERR_PARAMETER);
      }
    }
    field = (Field_Value *) malloc(sizeof(Field_Value) + len);
    if (field == NULL) {
      MEMERR("GetRecordFromUser", sizeof(Field_Value) + len);
      exit(ERR_MEMORY);
    }

    field->field_type = fieldType;
    field->field_number = fieldNumber;
    field->field_length = len;
    memcpy(field->field_data, buff, len);
    field->field_data[len] = 0;
    rec.field[i] = field;
  }
  return rec;
}

void do_add(char *input)
{
  WSWORD err;
  WUBYTE *flist;
  Record rec;

  rec = GetRecordFromUser(CurrentPanel->cursor.pos);

  flist = BuildFieldList(&rec,TRUE);

  err = dpe_CreateRec(CurrentPanel->pba, 0, flist, 0, NULL);
  free(flist);
  flist = NULL;
  if (err != 0) {
    printf("Record creation failed (#%d)\n", err); 
    if (!Interactive) exit(ERR_DP(err));
    DisposeRecord(&rec);
    return;
  }
  DisposeRecord(&CurrentPanel->cursor.pos);
  CurrentPanel->cursor.where = VALID;
  CurrentPanel->cursor.pos = rec;
  if (Interactive) PrintRecord(rec);
  LogCreation(rec);
}

void do_delete(char *input)
{
  WSWORD err;
  WUBYTE *key;

  key = BuildKey(CurrentPanel, CurrentPanel->cursor.pos);
  if (key == NULL) return;
  if (Interactive) PrintKey(key);
  err = dpe_DeleteRec(CurrentPanel->pba, key);
  if (err != 0) {
    printf("Record deletion failed (#%d)\n", err); 
    if (!Interactive) exit(ERR_DP(err)); 
  }
  LogDeletion(key);
  free(key);
}

WUBYTE *GetKeyFromUser(int countOfFieldsRequired)
{
  int i, j;
  int len, fieldNumber, fieldIndex;
  char fieldType;
  Index_Info *curr_idx;
  WUBYTE key[1024], *p, *keyPtr;
  char buff[256];

  /* get the key from the user */
  curr_idx = CurrentPanel->current_index;
  p = key;
  *p++ = (WUBYTE) curr_idx->index_number;
  if (countOfFieldsRequired > (WSWORD) curr_idx->index_size
      || countOfFieldsRequired <= 0) {
    countOfFieldsRequired = curr_idx->index_size;
  }
  for (i=0; i < countOfFieldsRequired; i++) { 

    /* prompt for next field */
    fieldNumber = curr_idx->field_number[i];
    fieldIndex = FindFieldIndex(CurrentPanel, fieldNumber);
    fieldType = CurrentPanel->field_type[fieldIndex];
    ASSERT(fieldType != '0');
    if (Interactive) {
      if (CurrentPanel->cursor.pos.field && 
          CurrentPanel->cursor.pos.field[fieldIndex]) {
	printf(" %2d (%c): %s\n", fieldNumber, fieldType, 
          CurrentPanel->cursor.pos.field[fieldIndex]->field_data);
      }
      printf(" %2d (%c): ", fieldNumber, fieldType);
    }

    /* get the next field */
    if (get_input(buff, sizeof buff) == NULL  /* EOF or error */
        ||  buff[0] == '\0') {
      if (!countOfFieldsRequired) break;
    }

    if (buff[0] == 0 && Interactive &&
        CurrentPanel->cursor.pos.field && 
        CurrentPanel->cursor.pos.field[fieldIndex]) {
      strncpy(buff,
        CurrentPanel->cursor.pos.field[fieldIndex]->field_data,
	sizeof buff);
      buff[sizeof buff -  1] = 0;
    }

    len = strlen(buff);
    if (len > 0 && buff[len-1] == '\n') {
      buff[--len] = 0; /* overwrite the newline */
    }

    /* trim trailing blanks */
    for (j=len-1; j > 0; j--) {
      if (buff[j] != ' ') break;
    }
    if (j<sizeof(buff)-1) {
      buff[j+1] = 0;
      len = j + 1;
    }

    if (countOfFieldsRequired) {
      *p++ = fieldNumber;
      if (fieldType == '1') {
	*p++ = len % 256;
	*p++ = len / 256;
      } else {
	*p++ = len;
      }
      memcpy(p, buff, len);
      p += len;
    }
  }
  *p++ = 0;

  keyPtr = (WUBYTE *) malloc(p-key);
  if (keyPtr == NULL) {
    MEMERR("GetKeyFromUser", p-key);
  } else {
    memcpy(keyPtr, key, p-key);
  }
  return keyPtr;
}

Field_Value *GetFieldFromUser(void)
{
  short int field_num, field_index;
  unsigned short int field_len;
  char input[1024];

  if (Interactive) { printf("Field number: "); }
  get_input(input, sizeof(input));
  field_num = atoi(input);
  field_index = FindFieldIndex(CurrentPanel, field_num);
  if (field_index == -1) {
    printf("Invalid field number: %d\n", field_num);
    if (!Interactive) { exit(ERR_PARAMETER); }
    return NULL;
  }
  ASSERT(CurrentPanel->field_type[field_index] != '0');
  if (Interactive) { printf(" Field value: "); }
  get_input(input, sizeof(input));
  field_len = strlen(input);
  return NewField(CurrentPanel->field_type[field_index],
                  field_num, field_len, input);

}

void GetFieldsFromUser(Record rec)
{
  int i;

  for (i=0; i < rec.field_count; i++) {
    rec.field[i] = GetFieldFromUser();
  }
}

void do_find(char *input)
{
  WUDWORD recCount;
  WSWORD err;
  WUBYTE *key;

  key = GetKeyFromUser(-1);
  if (Interactive) PrintKey(key);

  /* lookup the desired record */
  err = dpe_EqualRec(CurrentPanel->pba, key, &recCount);
  if (err == 772) {
    if (Interactive) printf("  dpe_EqualRec() failed (#%d)\n", err); 
    err = dpe_NextRec(CurrentPanel->pba, key, &recCount);
    if (err == 773) {
      if (Interactive) printf("  dpe_NextRec() failed (#%d)\n", err); 
      err = dpe_LastRec(
		      CurrentPanel->pba, 
		      CurrentPanel->current_index->index_number, 
			  &recCount);
      if (err != 0) {
	if (Interactive) printf("  dpe_LastRec() failed (#%d)\n", err); 
      }
    } else if (err != 0) {
      if (Interactive) printf("  dpe_NextRec() failed (#%d)\n", err); 
    }
  } else if (err != 0) {
    if (Interactive) printf("  dpe_EqualRec() failed (#%d)\n", err); 
  } 

  if (err == 0) {
    GetRecord(CurrentPanel, &CurrentPanel->cursor);
    if (Interactive) PrintRecord(CurrentPanel->cursor.pos);
  }

  free(key);
}

void do_lookup(char *input)
{
  WUDWORD recCount;
  WSWORD err;
  WUBYTE *key;

  /* find a record and print it; if not found, print a blank line */
  key = GetKeyFromUser(-1);
  if (Interactive) PrintKey(key);

  /* lookup the desired record */
  err = dpe_EqualRec(CurrentPanel->pba, key, &recCount);
  if (err == 0) {
    GetRecord(CurrentPanel, &CurrentPanel->cursor);
    PrintRecord(CurrentPanel->cursor.pos);
  } else if (err == 772) {
    printf("\n");
  } else{
    if (Interactive) printf("  dpe_EqualRec() failed (#%d)\n", err); 
    else printf("%s: Lookup error\n", ProgramName);
  } 

  free(key);
}

void do_restrict(char *input)
{
  int count;
  Field_Value *fv;
  
  if (isdigit(*++input)) {
    DisposeRecord(&CurrentPanel->restriction);
    count = atoi(input);
    if (count > 0) {
      if (Interactive) printf("Enter %d (field #, prefix) pairs.\n", count);
      InitRecord("do_restrict", &CurrentPanel->restriction, count);
      GetFieldsFromUser(CurrentPanel->restriction);
    }
  }
  if (Interactive) {
    if (CurrentPanel->restriction.field_count) {
      for (count=0; count < CurrentPanel->restriction.field_count; count++) {
        fv = CurrentPanel->restriction.field[count];
        printf("%4d: %*s\n",fv->field_number,fv->field_length,fv->field_data);
      }    
    } else {
      printf("No 'where' restriction.\n");
    }
  }
}

void do_subset(char *input)
{
  int count;
  
  if (isdigit(*++input)) {
    if (CurrentPanel->constraint) {
      free(CurrentPanel->constraint);
      CurrentPanel->constraint = NULL;
    }
    count = atoi(input);
    if (count > 0) {
      if (Interactive) printf("Enter %d fields.\n", count);
      CurrentPanel->constraint = GetKeyFromUser(count);
    }
  }
  if (Interactive) {
    if (CurrentPanel->constraint) PrintKey(CurrentPanel->constraint);
    else printf("No subset constraint.\n");
  }
}

void do_edit(char *input)
{
  WSWORD err;
  Record rec;
  WUBYTE *flist, *oflist;


  if (InitRecord("do_edit", &rec, CurrentPanel->field_count) != 0) {
    exit(ERR_MEMORY);
  }

  rec = GetRecordFromUser(CurrentPanel->cursor.pos);

  flist = BuildFieldList(&rec,TRUE);
  oflist = BuildFieldList(&CurrentPanel->cursor.pos,FALSE);
  err = dpe_UpdateRec(CurrentPanel->pba, flist, oflist);
  if (err != 0) {
    DisposeRecord(&rec);
    GetRecord(CurrentPanel, &CurrentPanel->cursor);
    if (!Interactive) {
      PrintRecord(CurrentPanel->cursor.pos);
    }
    printf("Record update failed (#%d)\n", err); 
    if (!Interactive) {
      exit(ERR_DP(err));
    }
  } else {
    DisposeRecord(&CurrentPanel->cursor.pos);
    CurrentPanel->cursor.pos = rec;
    CurrentPanel->cursor.where = VALID;
  }
  free(flist);
  free(oflist);
  if (Interactive) PrintRecord(CurrentPanel->cursor.pos);
}

void do_update(char *input)
{
  int n, count, retry;
#define MAX_RETRY 10
  unsigned char fields[100], actions[100];
  WSWORD err;
  WUDWORD recCount;
  Record rec, delta;
  WUBYTE *flist, *oflist;
  int i, j;
  int fn, fi, fl;
  char ft;
  WUBYTE buff[8000];
  WUDWORD udw;
  WUBYTE *key;

  key = BuildKey(CurrentPanel, CurrentPanel->cursor.pos);
  if (key == NULL) return;
  if (Interactive) PrintKey(key);

  ++input;
  count = 0;
  for (;;) {
    while (*input != 0 && !isdigit(*input)) input++;
    if (*input == 0) break;
    n = atoi(input);
    if (n == 0) break;
    if (memchr(CurrentPanel->field_number,n,CurrentPanel->field_count)==NULL){
      printf("Bad field number: %d\n", n);
      if (!Interactive) { exit(ERR_PARAMETER); }
      break;
    } else {
      ASSERT(count<100);
      fields[count] = n;
    }
    while (isdigit(*input)) input++;
    actions[count] = *input;
    count++;
  }
  
  if (InitRecord("do_update",&delta,count) != 0) {
    exit(ERR_MEMORY);
  }
  for (i=0; i<count; i++) {
    fn = fields[i];
    fi = FindFieldIndex(CurrentPanel,fn);
    ft = CurrentPanel->field_type[fi];
    if (Interactive) {
      printf(" %2d (%c): ", fn, actions[i] ? actions[i] : ':');
    }
    if (get_input(buff, sizeof buff) == NULL) {
      printf("Unexpected end of input in do_update\n");
      exit(ERR_PARAMETER);
    }
    fl = strlen(buff);
    for (j=fl-1; j>0; j--) if (buff[j] != ' ') break;
    fl = j + 1;
    buff[fl] = '\0';
    if (ft == '0') {
      fl = BLOBfromFile(buff, sizeof buff);
      if (fl < 0) {
	printf("Failed to load BLOB from file\n");
	exit(ERR_PARAMETER);
      }
    }
    delta.field[i] = NewField(ft,fn,fl,buff);
  }

  retry = 0;
  do {
    if (retry) {
      err = dpe_EqualRec(CurrentPanel->pba, key, &recCount);
      if (err != 0) {
	printf("Record positioning failed (#%d) for key ", err); 
	PrintKey(key);
	if (!Interactive) exit(ERR_DP(err)); 
	break;
      } else {
	GetRecord(CurrentPanel,&CurrentPanel->cursor);
      }
    }

    if (InitRecord("do_update",&rec,count) != 0) {
      exit(ERR_MEMORY);
    }
    for (i=0; i<count; i++) {
      fn = fields[i];
      fi = FindFieldIndex(CurrentPanel,fn);
      ft = CurrentPanel->field_type[fi];
      switch (actions[i]) {
	case '\0':
	case ':':
	  fl = delta.field[i]->field_length;
	  memcpy(buff, delta.field[i]->field_data, fl);
	  break;
	case '-':
	  udw = atoi(CurrentPanel->cursor.pos.field[fi]->field_data);
	  udw -= atoi(delta.field[i]->field_data);
	  sprintf(buff,"%lu",udw);
	  fl = strlen(buff);
	  break;
	case '+':
	  udw = atoi(CurrentPanel->cursor.pos.field[fi]->field_data);
	  udw += atoi(delta.field[i]->field_data);
	  sprintf(buff,"%lu",udw);
	  fl = strlen(buff);
	  break;
      }
      rec.field[i] = NewField(ft,fn,fl,buff);
    }

    flist = BuildFieldList(&rec,TRUE);
    oflist = BuildFieldList(&CurrentPanel->cursor.pos,FALSE);
    err = dpe_UpdateRec(CurrentPanel->pba,flist,oflist);
  } while (err == 802 && retry++ < MAX_RETRY);
  if (err) {
    printf("UpdateRec failed (#%d)\n",err);
    if (!Interactive) {
      exit(ERR_DP(err));
    }
  }
  DisposeRecord(&rec);
  DisposeRecord(&delta);
  free(flist);
  free(oflist);
  free(key);
  if (Interactive) PrintRecord(CurrentPanel->cursor.pos);

}

void do_tlog(char *input)
{
  switch (input[1]) {
    case '1':
    case '0':
      tlogFlag = input[1] == '1';
      break;
    default:
      exit(ERR_CMD_PANIC);
      break;
  }
}
      

void do_print(char *input)
{

  if (CurrentPanel->cursor.where == BEFORE) {
    GetFirstOrDie();
  } else if (CurrentPanel->cursor.where == AFTER) {
    GetLast();
  }
  if (CurrentPanel->cursor.where == VALID) {
    PrintRecord(CurrentPanel->cursor.pos);
  } else {
  /* do something -- there are no records in subset (or entire panel) */
  }
}

void do_help(char *input)
{
  printf("q             -quit\n");
  printf("?             -print this help message\n");
  printf("o             -open (initialize) the database\n");
  printf("c             -close the database\n");
  printf("p             -print available panel numbers\n");
  printf("p n           -change current panel to #n\n");
  printf("i             -print index numbers available in current panel\n");
  printf("i n           -change current index to #n\n");
  printf("g k1 k2 ...   -go to 1st record matching [partial] key\n");
  printf("1             -go to 1st record in panel\n");
  printf("+             -go to next record in panel\n");
  printf("-             -go to previous record in panel\n");
  printf("$             -go to last record in panel\n");
  printf(".             -print current record\n");
}

void do_setfields(char *input)
{
  int n, count;
  unsigned char fields[100], *mem;

  if (CurrentPanel->fields_to_print != NULL) {
    free(CurrentPanel->fields_to_print);
  }

  ++input;
  count = 0;
  for (;;) {
    while (*input != 0 && !isdigit(*input)) input++;
    if (*input == 0) break;
    n = atoi(input);
    if (n == 0) break;
    if (memchr(CurrentPanel->field_number,n,CurrentPanel->field_count)==NULL){
      printf("Bad field number: %d\n", n);
      if (!Interactive) {
	exit(ERR_PARAMETER);
      }
    } else {
      ASSERT(count<100);
      fields[count++] = n;
    }
    while (isdigit(*input)) input++;
  }


  mem = (unsigned char *) malloc((count+1)*sizeof(unsigned char));
  if (mem == NULL) {
    MEMERR("do_getfields", count+1);
    exit(ERR_MEMORY);
  }
  memcpy(mem, fields, count);
  mem[count] = 0;
  CurrentPanel->fields_to_print = mem;
}

void do_createvalues(char *input)
{
  int i, len;
  Record rec;

  if (CurrentPanel->constraint != NULL && 
      CurrentPanel->current_index->index_number == *CurrentPanel->constraint) {
    rec = InitRecordFromKey(CurrentPanel->constraint);
    PrintRecord(rec);
    DisposeRecord(&rec);
  } else {
    len = CurrentPanel->field_count;
    for (i=0; i < len; i++) { 
      printf("%c", i==len-1 ? '\n' : '\t');
    }
  }
}

void do_setkey(char *input)
{
  WUBYTE *key;
  Record rec;

  key = GetKeyFromUser(-1);
  rec = InitRecordFromKey(key);
  free(key);
  DisposeRecord(&CurrentPanel->cursor.pos);
  CurrentPanel->cursor.pos = rec;
  CurrentPanel->cursor.where = VALID;
}

void do_setrecord(char *input)
{
  Record rec;

  rec = GetRecordFromUser(CurrentPanel->cursor.pos);
  DisposeRecord(&CurrentPanel->cursor.pos);
  CurrentPanel->cursor.pos = rec;
  CurrentPanel->cursor.where = VALID;
}

void do_count(char *input)
{
  WUDWORD recCount = 0, gennum = 0;
  WSWORD err;
  Cursor curse;

  if (input[1] == 'g') {
    err = dpe_GenNum(CurrentPanel->pba, &gennum);
    if (err != 0) {
      if (Interactive) {
        printf("GenNum failed (#%d)\n", err);
      } else {
        exit(ERR_DP(err));
      }
    }
    printf("%lu\n", gennum);
    return;
  }
  if (CurrentPanel->constraint) {
    err = dpe_SubLastRec(
	    CurrentPanel->pba, 
	    CurrentPanel->constraint, 
	    &recCount);
    if (err == 0 && recCount == 1) {
      curse.where = BEFORE;
      curse.pos.field = NULL;
      curse.pos.field_count = 0;
      GetRecord(CurrentPanel, &curse);
      if (!MeetsConstraint(CurrentPanel->constraint, curse)) {
        recCount = 0;
      }
      DisposeRecord(&curse.pos);
    }
  } else {
    err = dpe_FirstRec(
	    CurrentPanel->pba, 
	    CurrentPanel->current_index->index_number, 
	    &recCount);
  }
  if (err) {
    if (Interactive) {
      printf("  dpe_[Sub]LastRec() failed (#%d)\n", err); 
    }
    recCount = 0;
  }
  printf("%lu\n", recCount);
}

void do_authenticate(char *input)
{
  int n, limit, fi;
  WUDWORD recCount;
  WSWORD err;
  WUBYTE *key;
  time_t authTime, now;
  char AuthTime[15];
  WUBYTE *flist, *oflist;
  Record rec;

  key = GetKeyFromUser(-1);
  if (Interactive) PrintKey(key);
  err = dpe_EqualRec(CurrentPanel->pba, key, &recCount);
  free(key);
  if (err != 0) {
    if (Interactive) printf("  dpe_EqualRec() failed (#%d)\n", err); 
    return;
  } 
  GetRecord(CurrentPanel, &CurrentPanel->cursor);
  if (Interactive) PrintRecord(CurrentPanel->cursor.pos);

  *input++ == 'z';
  while (*input != 0 && !isdigit(*input)) input++;
  if (*input == 0) return;
  n = atoi(input);
  if (n == 0) return;
  fi = FindFieldIndex(CurrentPanel,n);
  if (fi < 0){
    printf("Bad field number: %d\n", n);
    if (!Interactive) { exit(ERR_PARAMETER); }
    return;
  }
  while (isdigit(*input)) input++;
  if (*input++ == 0) return;
  limit = atoi(input);

  authTime = atol(CurrentPanel->cursor.pos.field[fi]->field_data);
  time(&now);
  if ((now-authTime)<=limit) {
    sprintf(AuthTime,"%ld",now);
    if (InitRecord("do_update",&rec,1) != 0) {
      exit(ERR_MEMORY);
    }
    rec.field[0] = NewField('8',n,strlen(AuthTime),AuthTime);
    flist = BuildFieldList(&rec,TRUE);
    oflist = BuildFieldList(&CurrentPanel->cursor.pos,FALSE);
    err = dpe_UpdateRec(CurrentPanel->pba,flist,oflist);
    printf("OK%d\n",err);
  } else {
    if (Interactive) printf("%ld\n",now);
  }
}
      
int do_command(char *input)
{
  switch (input[0]) {
    case 'q':  return 1;
    case 'i':  do_index(input); break;
    case 'p':  do_panel(input); break;
    case 'o':  do_open(input); break;
    case 'c':  do_close(input); break;
    case '?':  do_help(input); break;
    case '1':  do_first(input); break;
    case '\0': 
    case '\n': 
    case '+':  do_next(input); break;
    case '-':  do_prev(input); break;
    case '$':  do_last(input); break;
    case '#':  do_count(input); break;
    case 'a':  do_add(input); break;
    case 'd':  do_delete(input); break;
    case 'e':  do_edit(input); break;
    case 'u':  do_update(input); break;
    case '.':  do_print(input); break;
    case 'f':  do_find(input); break;
    case 'l':  do_lookup(input); break;
    case 's':  do_subset(input); break;
    case ':':  do_setfields(input); break;
    case 'v':  do_createvalues(input); break;
    case 'k':  do_setkey(input); break;
    case 'r':  do_setrecord(input); break;
    case 'A':  do_all(input); break;
    case 'w':  do_restrict(input); break;
    case 'R':  do_reindex(input); break;
    case 'L':  do_tlog(input); break;
    case 'z':  do_authenticate(input); break;
    default:   printf("unknown command: %s\n", input); break;
  }
  return 0;
}

void command_loop(void)
{
  char input[256];
  char cmd[16];


  for (;;) {
    if (Interactive) fputs(PRIMARY_PROMPT, stdout); /* fflush(stdout);*/
    if (get_input(input, sizeof input) == NULL) {
      return;
    }

    /* before each command (other than panel selection), 
     * check that we have a current panel */
    if (CurrentPanel == NULL && input[0] != 'p') {
      sprintf(cmd, "p %d", panel[0].panel_number);
      do_command(cmd);  /* position to the first panel */
    }

    if (do_command(input)) return;
  }
}

int main(int argc, char **argv, char **envp)
{
  int i;
  char *p;
  
  ProgramName = *argv++;
  argc--;

  Interactive = 0;
  if (argc>0 && argv[0][0]=='-' && argv[0][1]=='i') {
    Interactive = 1;
    argv++;
    argc--;
  }
#ifdef TRACE_DP
  traceOut = fopen("trace.dp", "a");
  fprintf(traceOut, "\n\nNew run of dp.\n");
#endif  
  do_command("o");  /* open the data base */

  ArgumentCount = argc;
  ArgumentVector = argv;

#if 0
  for (i=1; i<argc; i++) {
    if (do_command(argv[i])) {
      do_command("c");  /* close the database */
      return 0;
    }
  }
#endif

  command_loop();

  do_command("c");  /* close the database */
  return 0;
}
