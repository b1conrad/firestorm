
#ifndef _dot_h_
#define _dot_h_ 1

#ifndef _machine_h_
#include "machine.h"
#endif

extern WUBYTE forth[0xFFFD];

#define FORTH (forth[0])
#define SERVER (forth[0x4259])
#define DSEG (*(WSWORD*)&forth[0x4373])
#define AX_DOT_R (*(WSWORD*)&forth[0x464D])
#define BX_DOT_R (*(WSWORD*)&forth[0x4651])
#define CX_DOT_R (*(WSWORD*)&forth[0x4655])
#define DX_DOT_R (*(WSWORD*)&forth[0x4659])
#define SI_DOT_R (*(WSWORD*)&forth[0x465D])
#define DI_DOT_R (*(WSWORD*)&forth[0x4661])
#define ES_DOT_R (*(WSWORD*)&forth[0x4665])
#define Y_DOT_OFF (*(WUWORD*)&forth[0x46BF])
#define Y_DOT_OFF0 (*(WUWORD*)&forth[0x46C3])
#define KSL (*(WUWORD*)&forth[0x46CE])
#define II_DOT_SRA (*(WUWORD*)&forth[0x46D3])
#define II_DOT_SRB (*(WUWORD*)&forth[0x46DA])
#define II_DOT_SRK (forth[0x46DE])
#define II_DOT_SRN (forth[0x46E1])
#endif /* ifndef _dot_h_ */
