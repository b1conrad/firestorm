
#include <stdio.h>

#ifdef macintosh
#include <stdlib.h>
#endif

#ifndef _dot_h_
#include "dot.h"
#endif

#include "engine.h"

WSWORD FAR dpe_Init(WUBYTE FAR *ndxfil, WUBYTE FAR *txxfil, WUBYTE FAR *sortmap)
{
    basetable[2] = ndxfil;
    basetable[3] = txxfil;
    basetable[4] = sortmap;

    AX_DOT_R = 0x0100;  /* function call for dpe_Init */

    CX_DOT_R = 2;   /* CX = Base for Name of Index File */
    DI_DOT_R = 0;   /* DI = Offset for Name of Index File = 0 */

    DX_DOT_R = 3;   /* DX = Base for Name of Text File */
    SI_DOT_R = 0;   /* SI = Offset for Name of Text File = 0 */

    ES_DOT_R = 4;   /* ES = Base for Sort Map */
    BX_DOT_R = 0;   /* BX = Offset for Sort Map = 0 */

    return engine();
}

WSWORD FAR dpe_InitIndex(WUBYTE FAR *ndxfil)
{
    basetable[2] = ndxfil;

    AX_DOT_R = 0x0200;  /* function call for dpe_InitInd */

    ES_DOT_R = 2;   /* ES = Base for Name of Index File */
    DI_DOT_R = 0;   /* DI = Offset for Name of Index File = 0 */

    return engine();
}

WSWORD FAR dpe_CreateIndex(WUBYTE FAR *ndxfil)
{
    basetable[2] = ndxfil;

    AX_DOT_R = 0x0300;  /* function call for dpe_CreateInd */

    ES_DOT_R = 2;   /* ES = Base for Name of Index File */
    DI_DOT_R = 0;   /* DI = Offset for Name of Index File = 0 */

    CX_DOT_R = 0;   /* CX = Index File Format (0 = DP 2.2) */

    return engine();
}

WSWORD FAR dpe_GenIndex(WUBYTE FAR *pbarray, WUWORD index, WUDWORD FAR *ndxbase)
{
    WSWORD i;

    AX_DOT_R = 0x0400;  /* function call for dpe_GenIndex */

    if (pbarray == NULL) {
        ES_DOT_R = 0;   /* ES = DI = 0, Allocate new Base Block */
        DI_DOT_R = 0;

        i = engine();
        if (i == 0)
            *ndxbase = ((WUDWORD)(WUWORD)DX_DOT_R << 16) 
              + (WUDWORD)(WUWORD)BX_DOT_R;
        return i;
    } else {
        basetable[2] = pbarray;

        ES_DOT_R = 2;   /* ES = Base for Panel Byte Array */
        DI_DOT_R = 0;   /* DI = Offset for Panel Byte Array */

        CX_DOT_R = index;

        return engine();
    }
}

WSWORD FAR dpe_RecCnt(WUBYTE FAR *pbarray, WUDWORD FAR *reccnt)
{
    WSWORD i;

    basetable[2] = pbarray;

    AX_DOT_R = 0x0500;  /* function call for dpe_RecCnt */
    BX_DOT_R = 0;

    ES_DOT_R = 2;   /* ES = Base for Panel Byte Array */
    DI_DOT_R = 0;   /* DI = Offset for Panel Byte Array */

    i = engine();
    if (i == 0)
        *reccnt = ((WUDWORD)(WUWORD)DX_DOT_R << 16) 
          + (WUDWORD)(WUWORD)BX_DOT_R;
    return i;
}

WSWORD FAR dpe_GenNum(WUBYTE FAR *pbarray, WUDWORD FAR *gennum)
{
    WSWORD i;

    basetable[2] = pbarray;

    AX_DOT_R = 0x0500;  /* function call for dpe_RecCnt */
    BX_DOT_R = 1;

    ES_DOT_R = 2;   /* ES = Base for Panel Byte Array */
    DI_DOT_R = 0;   /* DI = Offset for Panel Byte Array */

    i = engine();
    if (i == 0)
        *gennum = ((WUDWORD)(WUWORD)DX_DOT_R << 16) 
          + (WUDWORD)(WUWORD)BX_DOT_R;
    return i;
}

WSWORD FAR dpe_FirstRec(WUBYTE FAR *pbarray, WUWORD index, WUDWORD FAR *reccnt)
{
    WSWORD i;

    basetable[2] = pbarray;

    AX_DOT_R = 0x0600;  /* function call for dpe_FirstRec */

    ES_DOT_R = 2;   /* ES = Base for Panel Byte Array */
    DI_DOT_R = 0;   /* DI = Offset for Panel Byte Array */

    CX_DOT_R = index;

    i = engine();
    if (i == 0)
        *reccnt = ((WUDWORD)(WUWORD)DX_DOT_R << 16) 
          + (WUDWORD)(WUWORD)BX_DOT_R;
    return i;
}

WSWORD FAR dpe_LastRec(WUBYTE FAR *pbarray, WUWORD index, WUDWORD FAR *reccnt)
{
    WSWORD i;

    basetable[2] = pbarray;

    AX_DOT_R = 0x0800;  /* function call for dpe_LastRec */

    ES_DOT_R = 2;   /* ES = Base for Panel Byte Array */
    DI_DOT_R = 0;   /* DI = Offset for Panel Byte Array */

    CX_DOT_R = index;

    i = engine();
    if (i == 0)
        *reccnt = ((WUDWORD)(WUWORD)DX_DOT_R << 16) 
          + (WUDWORD)(WUWORD)BX_DOT_R;
    return i;
}

WSWORD FAR dpe_EqualRec(WUBYTE FAR *pbarray, WUBYTE FAR *iflist, WUDWORD FAR *reccnt)
{
    WSWORD i;

    basetable[2] = pbarray;
    basetable[3] = iflist;

    AX_DOT_R = 0x0900;  /* function call for dpe_EqualRec */

    ES_DOT_R = 2;   /* ES = Base for Panel Byte Array */
    DI_DOT_R = 0;   /* DI = Offset for Panel Byte Array */

    DX_DOT_R = 3;   /* DX = Base for Index and Field List */
    SI_DOT_R = 0;   /* SI = Offset for Index and Field List = 0 */

    i = engine();
    if (i == 0)
        *reccnt = ((WUDWORD)(WUWORD)DX_DOT_R << 16) 
          + (WUDWORD)(WUWORD)BX_DOT_R;
    return i;
}

WSWORD FAR dpe_NextRec(WUBYTE FAR *pbarray, WUBYTE FAR *iflist, WUDWORD FAR *reccnt)
{
    WSWORD i;

    basetable[2] = pbarray;
    basetable[3] = iflist;

    AX_DOT_R = 0x0A00;  /* function call for dpe_NextRec */

    ES_DOT_R = 2;   /* ES = Base for Panel Byte Array */
    DI_DOT_R = 0;   /* DI = Offset for Panel Byte Array */

    if (iflist == NULL)
        DX_DOT_R = 0;   /* DX = SI = 0, Assume current record */
    else
        DX_DOT_R = 3;   /* DX = Base for Index and Field List */
    SI_DOT_R = 0;   /* SI = Offset for Index and Field List = 0 */

    i = engine();
    if (i == 0)
        *reccnt = ((WUDWORD)(WUWORD)DX_DOT_R << 16) 
          + (WUDWORD)(WUWORD)BX_DOT_R;
    return i;
}

WSWORD FAR dpe_PrevRec(WUBYTE FAR *pbarray, WUBYTE FAR *iflist, WUDWORD FAR *reccnt)
{
    WSWORD i;

    basetable[2] = pbarray;
    basetable[3] = iflist;

    AX_DOT_R = 0x0B00;  /* function call for dpe_PrevRec */

    ES_DOT_R = 2;   /* ES = Base for Panel Byte Array */
    DI_DOT_R = 0;   /* DI = Offset for Panel Byte Array */

    if (iflist == NULL)
        DX_DOT_R = 0;   /* DX = SI = 0, Assume current record */
    else
        DX_DOT_R = 3;   /* DX = Base for Index and Field List */
    SI_DOT_R = 0;   /* SI = Offset for Index and Field List = 0 */

    i = engine();
    if (i == 0)
        *reccnt = ((WUDWORD)(WUWORD)DX_DOT_R << 16) 
          + (WUDWORD)(WUWORD)BX_DOT_R;
    return i;
}

WSWORD FAR dpe_SubFirstRec(WUBYTE FAR *pbarray, WUBYTE FAR *iflist, WUDWORD FAR *reccnt)
{
    WSWORD i;

    basetable[2] = pbarray;
    basetable[3] = iflist;

    AX_DOT_R = 0x0C00;  /* function call for dpe_SubFirstRec */

    ES_DOT_R = 2;   /* ES = Base for Panel Byte Array */
    DI_DOT_R = 0;   /* DI = Offset for Panel Byte Array */

    DX_DOT_R = 3;   /* DX = Base for Index and Field List */
    SI_DOT_R = 0;   /* SI = Offset for Index and Field List = 0 */

    i = engine();
    if (i == 0)
        *reccnt = ((WUDWORD)(WUWORD)DX_DOT_R << 16) 
          + (WUDWORD)(WUWORD)BX_DOT_R;
    return i;
}

WSWORD FAR dpe_SubLastRec(WUBYTE FAR *pbarray, WUBYTE FAR *iflist, WUDWORD FAR *reccnt)
{
    WSWORD i;

    basetable[2] = pbarray;
    basetable[3] = iflist;

    AX_DOT_R = 0x0D00;  /* function call for dpe_SubLastRec */

    ES_DOT_R = 2;   /* ES = Base for Panel Byte Array */
    DI_DOT_R = 0;   /* DI = Offset for Panel Byte Array */

    DX_DOT_R = 3;   /* DX = Base for Index and Field List */
    SI_DOT_R = 0;   /* SI = Offset for Index and Field List = 0 */

    i = engine();
    if (i == 0)
        *reccnt = ((WUDWORD)(WUWORD)DX_DOT_R << 16) 
          + (WUDWORD)(WUWORD)BX_DOT_R;
    return i;
}

WSWORD FAR dpe_SubNextRec(WUBYTE FAR *pbarray, WUBYTE FAR *iflist, WUBYTE FAR *constr, WUDWORD FAR *reccnt)
{
    WSWORD i;

    basetable[2] = pbarray;
    basetable[3] = iflist;
    basetable[4] = constr;

    AX_DOT_R = 0x0E00;  /* function call for dpe_SubNextRec */

    ES_DOT_R = 2;   /* ES = Base for Panel Byte Array */
    DI_DOT_R = 0;   /* DI = Offset for Panel Byte Array */

    if (iflist == NULL)
        DX_DOT_R = 0;   /* DX = SI = 0, Assume current record */
    else
        DX_DOT_R = 3;   /* DX = Base for Index and Field List */
    SI_DOT_R = 0;   /* SI = Offset for Index and Field List = 0 */

    CX_DOT_R = 4;   /* CX = Base for Constraint List */
    BX_DOT_R = 0;   /* BX = Offset for Constraint List = 0 */

    i = engine();
    if (i == 0)
        *reccnt = ((WUDWORD)(WUWORD)DX_DOT_R << 16) 
          + (WUDWORD)(WUWORD)BX_DOT_R;
    return i;
}

WSWORD FAR dpe_SubPrevRec(WUBYTE FAR *pbarray, WUBYTE FAR *iflist, WUBYTE FAR *constr, WUDWORD FAR *reccnt)
{
    WSWORD i;

    basetable[2] = pbarray;
    basetable[3] = iflist;
    basetable[4] = constr;

    AX_DOT_R = 0x0F00;  /* function call for dpe_SubPrevRec */

    ES_DOT_R = 2;   /* ES = Base for Panel Byte Array */
    DI_DOT_R = 0;   /* DI = Offset for Panel Byte Array */

    if (iflist == NULL)
        DX_DOT_R = 0;   /* DX = SI = 0, Assume current record */
    else
        DX_DOT_R = 3;   /* DX = Base for Index and Field List */
    SI_DOT_R = 0;   /* SI = Offset for Index and Field List = 0 */

    CX_DOT_R = 4;   /* CX = Base for Constraint List */
    BX_DOT_R = 0;   /* BX = Offset for Constraint List = 0 */

    i = engine();
    if (i == 0)
        *reccnt = ((WUDWORD)(WUWORD)DX_DOT_R << 16) 
          + (WUDWORD)(WUWORD)BX_DOT_R;
    return i;
}

WSWORD FAR dpe_GetField(WUBYTE FAR *pbarray, WUBYTE FAR *fldnfo, WUWORD FAR *type, WUWORD size, WUBYTE FAR *data)
{
    WSWORD i;
    WUWORD esize;
    WUBYTE FAR *bp;

    basetable[2] = pbarray;
    basetable[3] = fldnfo;

    AX_DOT_R = 0x1000;  /* function call for dpe_GetField */
    BX_DOT_R = 0;

    ES_DOT_R = 2;   /* ES = Base for Panel Byte Array */
    DI_DOT_R = 0;   /* DI = Offset for Panel Byte Array */

    DX_DOT_R = 3;   /* DX = Base for Field Format */
    SI_DOT_R = 0;   /* SI = Offset for Field Format */

    i = engine();
    if (i == 0) {
        *type = CX_DOT_R;
        if ((WUWORD)DX_DOT_R < BASESIZE)
            bp = basetable[DX_DOT_R] + (WUWORD)BX_DOT_R;
        else {
            /* printf("\nBad Base Table Index!\n"); */
            return 2571;
        }
        if (CX_DOT_R == 1)
            esize = *(WUWORD FAR *)bp + 2;
        else
            esize = *bp + 1;
        if (esize > size) {
            esize = size;
            i = -1;
        }
        while(esize-- > 0)
            *data++ = *bp++;
    }
    return i;
}

WSWORD FAR dpe_GetBlob(WUBYTE FAR *pbarray, WUBYTE FAR *fldnfo, WUWORD FAR *type, WUWORD size, WUBYTE FAR *data)
{
    WSWORD i;
    WUBYTE FAR *bp;

    basetable[2] = pbarray;
    basetable[3] = fldnfo;
    basetable[4] = data;

    AX_DOT_R = 0x1000;  /* function call for dpe_GetField */
    BX_DOT_R = 4;

    ES_DOT_R = 2;   /* ES = Base for Panel Byte Array */
    DI_DOT_R = 0;   /* DI = Offset for Panel Byte Array */

    DX_DOT_R = 3;   /* DX = Base for Field Format */
    SI_DOT_R = 0;   /* SI = Offset for Field Format */

    if (size < 32000) {
        return -3;  /* blobs can be as large as 32000 bytes */
    }
    i = engine();
    if (i == 0) {
        if (CX_DOT_R == 1) {
        } else {
            i = -2; /* blobs must be in DP text fields */
        }
    }
    return i;
}

WSWORD FAR dpe_LockOff(void)
{
    AX_DOT_R = 0x1F00;  /* function call for dpe_LockFunctions */

    BX_DOT_R = 1;       /* BX = SubFunction LockOff */

    return engine();
}

WSWORD FAR dpe_LockOn(void)
{
    AX_DOT_R = 0x1F00;  /* function call for dpe_LockFunctions */

    BX_DOT_R = 2;       /* BX = SubFunction LockOn */

    return engine();
}

WSWORD FAR dpe_FlushBuff(void)
{
    AX_DOT_R = 0x1F00;  /* function call for dpe_LockFunctions */

    BX_DOT_R = 3;       /* BX = SubFunction FlushBuff */

    return engine();
}

WSWORD FAR dpe_LockIndex(void)
{
    AX_DOT_R = 0x1F00;  /* function call for dpe_LockFunctions */

    BX_DOT_R = 4;       /* BX = SubFunction Lock Index for Trans. */

    return engine();
}

WSWORD FAR dpe_CloseFiles(void)
{
    AX_DOT_R = 0x1F00;  /* function call for dpe_LockFunctions */

    BX_DOT_R = 5;       /* BX = SubFunction Close open Files */

    return engine();
}

WSWORD FAR dpe_CreateRec(WUBYTE FAR *pbarray, WUWORD handle, WUBYTE FAR *flist, WUWORD size, WUBYTE FAR *data)
{
    WSWORD i;
    WUWORD esize;
    WSWORD tsize;
    WUBYTE FAR *bp;

    basetable[2] = pbarray;
    basetable[3] = flist;

    AX_DOT_R = 0x2000;  /* function call for dpe_CreateRec */

    ES_DOT_R = 2;   /* ES = Base for Panel Byte Array */
    DI_DOT_R = 0;   /* DI = Offset for Panel Byte Array */

    BX_DOT_R = handle;  /* BX = ".STR" File Handle */

    DX_DOT_R = 3;   /* DX = Base for Field List */
    SI_DOT_R = 0;   /* SI = Offset for Field List = 0 */

    if (handle == 0)
        return engine();

    i = engine();
    if (i == 0) {
        if ((WUWORD)DX_DOT_R < BASESIZE)
            bp = basetable[DX_DOT_R] + (WUWORD)BX_DOT_R;
        else {
            /* printf("\nBad Base Table Index!\n"); */
            return 2572;
        }
        tsize = size;
        while ( (tsize-- > 0) && ((*data++ = *bp++) != 0) ) {
            esize = *bp + 1;
            if ( (tsize -= esize) <= 0)
                return -1;
            while(esize-- > 0)
                *data++ = *bp++;
        }
        if (tsize < 0 )
            return -1;
    }
    return i;
}

WSWORD FAR dpe_UpdateRec(WUBYTE FAR *pbarray, WUBYTE FAR *flist, WUBYTE FAR *oflist)
{
    basetable[2] = pbarray;
    basetable[3] = flist;
    basetable[4] = oflist;

    AX_DOT_R = 0x2100;  /* function call for dpe_UpdateRec */

    ES_DOT_R = 2;   /* ES = Base for Panel Byte Array */
    DI_DOT_R = 0;   /* DI = Offset for Panel Byte Array */

    DX_DOT_R = 3;   /* DX = Base for Field List */
    SI_DOT_R = 0;   /* SI = Offset for Field List = 0 */

    CX_DOT_R = 4;   /* CX = Base for Old Field List */
    BX_DOT_R = 0;   /* BX = Offset for Old Field List = 0 */

    return engine();
}

WSWORD FAR dpe_DeleteRec(WUBYTE FAR *pbarray, WUBYTE FAR *iflist)
{
    basetable[2] = pbarray;
    basetable[3] = iflist;

    AX_DOT_R = 0x2200;  /* function call for dpe_DeleteRec */

    ES_DOT_R = 2;   /* ES = Base for Panel Byte Array */
    DI_DOT_R = 0;   /* DI = Offset for Panel Byte Array */

    DX_DOT_R = 3;   /* DX = Base for Index and Field List */
    SI_DOT_R = 0;   /* SI = Offset for Index and Field List = 0 */

    return engine();
}

WSWORD FAR dpe_GetIncFld(WUBYTE FAR *pbarray, WUWORD handle, WUWORD size, WUBYTE FAR *data)
{
    WSWORD i;
    WUWORD esize;
    WSWORD tsize;
    WUBYTE FAR *bp;

    basetable[2] = pbarray;

    AX_DOT_R = 0x2300;  /* function call for dpe_GetIncFld */

    ES_DOT_R = 2;   /* ES = Base for Panel Byte Array */
    DI_DOT_R = 0;   /* DI = Offset for Panel Byte Array */

    BX_DOT_R = handle;  /* BX = ".STR" File Handle */

    i = engine();
    if (i == 0) {
        if ((WUWORD)DX_DOT_R < BASESIZE)
            bp = basetable[DX_DOT_R] + (WUWORD)BX_DOT_R;
        else {
            /* printf("\nBad Base Table Index!\n"); */
            return 2573;
        }
        tsize = size;
        while ( (tsize-- > 0) && ((*data++ = *bp++) != 0) ) {
            esize = *bp + 1;
            if ( (tsize -= esize) <= 0)
                return -1;
            while(esize-- > 0)
                *data++ = *bp++;
        }
        if (tsize < 0 )
            return -1;
    }
    return i;
}

WSWORD FAR dpe_SetIncFld(WUBYTE FAR *pbarray, WUWORD handle, WUBYTE FAR *flist)
{
    basetable[2] = pbarray;
    basetable[3] = flist;

    AX_DOT_R = 0x2301;  /* function call for dpe_SetIncFld */

    ES_DOT_R = 2;   /* ES = Base for Panel Byte Array */
    DI_DOT_R = 0;   /* DI = Offset for Panel Byte Array */

    BX_DOT_R = handle;  /* BX = ".STR" File Handle */

    DX_DOT_R = 3;   /* DX = Base for Index and Field List */
    SI_DOT_R = 0;   /* SI = Offset for Index and Field List = 0 */

    return engine();
}
