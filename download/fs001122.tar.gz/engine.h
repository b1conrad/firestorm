
#ifndef _ENGINE_H
#define _ENGINE_H
#include "machine.h"

#define BASESIZE 5

EXTERN_WRITE WUBYTE *basetable[BASESIZE];   /* Base Address Pointers    */
            /* DSEG = 0 => basetable[0] */
            /* XSEG = 1 => basetable[1] */

#ifndef _dot_h_
EXTERN_WRITE FAR WSWORD AX_DOT_R;   /* AX Argument Value for Engine */
EXTERN_WRITE FAR WSWORD BX_DOT_R;   /* BX Argument Value for Engine */
EXTERN_WRITE FAR WSWORD CX_DOT_R;   /* CX Argument Value for Engine */
EXTERN_WRITE FAR WSWORD DX_DOT_R;   /* DX Argument Value for Engine */
EXTERN_WRITE FAR WSWORD SI_DOT_R;   /* SI Argument Value for Engine */
EXTERN_WRITE FAR WSWORD DI_DOT_R;   /* DI Argument Value for Engine */
EXTERN_WRITE FAR WSWORD ES_DOT_R;   /* ES Argument Value for Engine */
#endif

extern WSWORD engine(void);

#endif
