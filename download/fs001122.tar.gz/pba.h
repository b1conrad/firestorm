#ifndef _pba_h_
#define _pba_h_

#ifndef _machine_h_
#include "machine.h"
#endif

typedef struct {
  char field_type;
  short int field_number;
  short int field_length;
  char  field_data[1];
} Field_Value;

typedef struct {
  int field_count;
  Field_Value **field;
} Record;

typedef struct {
  /* Cursors will by default be initialized to BEFORE */
  enum {BEFORE=0, VALID, AFTER} where; 
  Record pos;  /* if where==VALID, copy of the record most recently visited */
} Cursor;

typedef struct {
  int index_number;
  int index_size;
  unsigned char *field_number;
} Index_Info;

typedef struct {
  int panel_number;
  int field_count;
  char *field_type;
  unsigned char *field_number;
  int index_count;
  Index_Info **index;
  unsigned char *pba;   /* panel byte array */
  Index_Info *current_index;
  unsigned char *fields_to_print;
  Cursor cursor;
  WUBYTE *constraint;
  Record restriction;
} Panel_Info;

extern int panel_count;
extern Panel_Info panel[];
extern char *ind_name;
extern char *txx_name;
extern unsigned char sort_map[];

#endif
