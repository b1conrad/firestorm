
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#ifdef WIN32
#include <io.h>
#include <fcntl.h>
#endif

#include "fs.h"

#define ERR_PGM_PANIC 100

FS_CGI_arg FSexpect[];
char *WhatFilename;

#define DEBUG_WHAT 1 


#ifdef DEBUG_WHAT
void showCGIvars(FILE *what)
{
  FS_CGI_arg *p;
  Field_Value *fv;

  for (p = FSexpect; p->FS_CGI_key!=NULL; p++) {
    fv = *(p->FS_CGI_var);
    if (fv) {
      fprintf(what,"%s(%d)=%s\n",
	p->FS_CGI_key,fv->field_length,fv->field_data);
/*
    } else {
      fprintf(what,"%s is missing\n", p->FS_CGI_key);
*/
    }
  }
}

void showBuf(char *buf, FILE *what)
{
  fprintf(what,"buf=<%s>\n",buf);
  fflush(what);
}
#endif

void setCGIvar(char *key, char *val)
{
  FS_CGI_arg *p;

  for (p = FSexpect; p->FS_CGI_key!=NULL && strcmp(key,p->FS_CGI_key); p++) ;
  if (p->FS_CGI_key!=NULL) {
    *(p->FS_CGI_var) = NewField('1',0,
      (val==NULL ? 0 : strlen(val)),val);
  }
}

void setCGIvarlen(char *key, char *val, int len)
{
  FS_CGI_arg *p;

  for (p = FSexpect; p->FS_CGI_key!=NULL && strcmp(key,p->FS_CGI_key); p++) ;
  if (p->FS_CGI_key!=NULL) {
    *(p->FS_CGI_var) = NewField('0',0,len,val);
  }
}

void finalCGIvars(void)
{
  FS_CGI_arg *p;
  char *val;

  for (p = FSexpect; p->FS_CGI_key!=NULL; p++) {
    if (*(p->FS_CGI_var) == NULL) {
      val = getenv(p->FS_CGI_key);
      if (val == NULL) val = p->FS_CGI_val;
      if (val != NULL) {
	*(p->FS_CGI_var) = NewField('1',0,
	  (val==NULL ? 0 : strlen(val)),val);
      }
    }
  }
}

int hexDigit(int c)
{
  if ('0' <= c && c <= '9') return c - '0';
  if ('A' <= c && c <= 'F') return c - 'A' + 10;
  if ('a' <= c && c <= 'f') return c - 'a' + 10;
  return 0;
}

void cookieDecode(char *buf)
{
  int ip, op;
  int hexDigit1, hexDigit2;
  char *key, *val;

  key = buf;
  val = NULL;
  for (ip=0, op=0; buf[ip]; op++) {
    buf[op] = buf[ip++];
    if (buf[op]=='+') {
      buf[op] = ' ';
    } else if (buf[op]=='%') {
      hexDigit1 = hexDigit(buf[ip++]);
      hexDigit2 = hexDigit(buf[ip++]);
      buf[op] = hexDigit1*16+hexDigit2;
    } else if (buf[op]=='=') {
      buf[op] = '\0';
      val = &buf[op+1];
    } else if (buf[op]==';') {
      buf[op] = '\0';
      if (buf[ip]==' ') ip++;
      setCGIvar(key,val);
      key = &buf[op+1];
      val = NULL;
    }
  }
  buf[op++] = '\0';
  if (*key) setCGIvar(key,val);
}

void URLdecode(char *buf)
{
  int ip, op;
  int hexDigit1, hexDigit2;
  char *key, *val;

  key = buf;
  val = NULL;
  for (ip=0, op=0; buf[ip]; op++) {
    buf[op] = buf[ip++];
    if (buf[op]=='+') {
      buf[op] = ' ';
    } else if (buf[op]=='%') {
      hexDigit1 = hexDigit(buf[ip++]);
      hexDigit2 = hexDigit(buf[ip++]);
      buf[op] = hexDigit1*16+hexDigit2;
    } else if (buf[op]=='=') {
      buf[op] = '\0';
      val = &buf[op+1];
    } else if (buf[op]=='&') {
      buf[op] = '\0';
      setCGIvar(key,val);
      key = &buf[op+1];
      val = NULL;
    }
  }
  buf[op++] = '\0';
  if (*key) setCGIvar(key,val);
}

char *expect(char *s, char *t)
{
  while (*t && *s++ == *t++) ;
  if (*t) exit(ERR_PGM_PANIC);
  return s;
}

char *substring(char *s, char *t, int len)
{
  char *last;
  int tl;

  tl = strlen(t);
  last = s + len - tl;
  for (; s < last; s++) {
    if (strncmp(s,t,tl)==0) return s;
  }
  return NULL;
}

#ifdef DEBUG_WHAT
int dumpMultipartStuff(char *ct, char *buf, int cl)
{
  FILE *what;

  what = fopen("multipart.txt", "w");
  if (what == NULL) return 1;
  fprintf(what,"%s\n", ProgramName);
  fprintf(what,"CONTENT_TYPE=%s\n\n",ct);
  if (fwrite(buf,1,cl,what) != cl) return 5;
  fclose(what);
  return 0;
}
#endif

void MultipartDecode(char *ct, char *buf, int bufLen)
{
  char *boundary, *p, *q;
  char *key, *val, *fn;
  char *dquote = "\"";
  int bLen, len;

#ifdef DEBUG_WHAT
  dumpMultipartStuff(ct,buf,bufLen);
#endif
  boundary = expect(ct,"multipart/form-data; boundary=");
  bLen = strlen(boundary);
  for (p=substring(buf,boundary,bufLen);
       p!=NULL; 
       p=substring(p,boundary,bufLen-(p-buf))) {
    p += bLen;
    if (p[0]=='-' && p[1]=='-') break;
    while (isspace(*p)) p++;
    p = expect(p,"Content-Disposition: form-data; name=\"");
    key = p;
    while (*p != '"') p++;
    *p++ = '\0';
    while (*p++ != '\n') ;
    if (*p == '\r') p++;
    if (*p == '\n') p++;
    val = p;
    len = substring(p,boundary,bufLen-(p-buf)) - p - 4;
    val[len] = '\0';
    setCGIvarlen(key,val,len);
  }
}

int main(int argc, char **argv, char **envp)
{
  int cl;
  char *qs, *pi, *ct, *co;
  char *key, *val;
  char *buf = NULL;
  int err;

#ifdef DEBUG_WHAT
  FILE *what;
  Field_Value *fv;
  int seconds;
#endif

#ifdef WIN32
  /* Set "stdout" to have binary mode: */
  if( _setmode( _fileno( stdout ), _O_BINARY ) == -1 ) {
    return(ERR_PGM_PANIC);;
  }
#endif

  ProgramName = *argv++;
  argc--;

#ifdef DEBUG_WHAT
  what = fopen(WhatFilename, "a");
  fprintf(what,"=====%s=====\n", ProgramName);
  fprintf(what,"IP=%s ", getenv("REMOTE_ADDR"));
  fv = FStoday();
  fprintf(what,"%s ", FSformatD("D99/99/9999",fv->field_data));
  free(fv);
  fv = FSnow();
  seconds = atoi(fv->field_data);
  free(fv);
  fprintf(what,"%d:%02d:%02d\n", 
    seconds / 3600,
    seconds / 60 % 60,
    seconds % 60);
  fflush(what);
#endif

/* command line arguments */

  while (argc--) {
    URLdecode(*argv++);
  }

/* FORM METHOD=POST arguments */

  if (getenv("CONTENT_LENGTH")!=NULL
      && (ct=getenv("CONTENT_TYPE"))!=NULL) {
    cl = atoi(getenv("CONTENT_LENGTH"));
    buf = (char *)malloc(cl+1);
    if (buf==NULL) exit(ERR_PGM_PANIC);
    if (fread(buf,1,cl,stdin) != cl) exit(ERR_PGM_PANIC);
    buf[cl] = '\0';
    if (strcmp(ct,"application/x-www-form-urlencoded")==0) {
#ifdef DEBUG_WHAT
      showBuf(buf,what);
#endif
      URLdecode(buf);
    } else {
      MultipartDecode(ct,buf,cl);
    }
  }

/* PATH_INFO arguments */

  if ((pi=getenv("PATH_INFO"))!=NULL && pi[0]) {
    if (*pi == '/') pi++;
#ifdef DEBUG_WHAT
    showBuf(pi,what);
#endif
    URLdecode(pi);
  }

/* QUERY_STRING arguments */

  if ((qs=getenv("QUERY_STRING"))!=NULL) {
#ifdef DEBUG_WHAT
    showBuf(qs,what);
#endif
    URLdecode(qs);
  }

/* COOKIE arguments */

  if ((co=getenv("HTTP_COOKIE"))!=NULL) {
#ifdef DEBUG_WHAT
    showBuf(co,what);
#endif
    cookieDecode(co);
  }

/* environment arguments */

  finalCGIvars();

#ifdef DEBUG_WHAT
  showCGIvars(what);
#endif

  fflush(what);
  FSopen();
  err = FSquery();
  FSclose();
  free(buf);

#ifdef DEBUG_WHAT
  fprintf(what,"err=%d\n",err);
  fclose(what);
#endif
  return err;
}
