/* 
 *  fs.h Firestorm definition file
 */

#ifdef WIN32
#include "e:\engine\pba.h"
#else
#include "pba.h"
#endif

#define FS_OK 0
#define FS_ABORT(msg) ((fprintf(stderr,"%s%c", msg, '\n'), 1))
#define FS_COMMIT FS_OK

typedef struct {
  char *FS_CGI_key;
  Field_Value **FS_CGI_var;
  char *FS_CGI_val;
} FS_CGI_arg;

typedef Panel_Info *FS_panel;

typedef unsigned char *FS_ifList;
typedef unsigned char *FS_fList;

char *ProgramName;

void FSopen(void);                    /* call to open the database */

int FSquery(void);                    /* called by main() */

void FSclose(void);                   /* call to close the database */

FS_panel FSsetPanel(int);             /* to open a panel */

FS_ifList FSifList(FS_panel, int, ...);
                                      /* to create an index and field
                                         list. Partial keys MUST be
                                         NULL terminated */
int FSsubLastRec(FS_panel, FS_ifList);
                                      /* to get the last record in
                                         a subset */
int FSsubPrevRec(FS_panel);           /* to get previous subset record */

Field_Value *FSfield(FS_panel, int);         /* to get a field value of the
                                         latest record gotten */

int FSfieldSize(FS_panel, int);       /* the size of a field value */

int FSequalRec(FS_panel, FS_ifList);  /* to get a particular record */

int FSnextRec(FS_panel);              /* to get the next record after
                                         the last one gotten, and using
                                         the latest index used */

int FSfirstRec(FS_panel, int);        /* to get the first record */

int FSlastRec(FS_panel, int);         /* to get the last record */

int FSprevRec(FS_panel);              /* to get the previous record after
                                         the last one gotten, and using
                                         the latest index used */

FS_fList FSfList(FS_panel, ...);      /* to create a field list. MUST
                                         include every real field */

int FScreateRec(FS_panel, FS_fList);  /* to create a new record */

int FSupdateField(FS_panel, FS_ifList, int, char, Field_Value*);
                                      /* to update a single field in
                                         the latest record gotten */
Field_Value *FSnow();                        /* returns the current time 
                                         as seconds since midnight */

Field_Value *FStoday();                      /* returns the current date
                                         as YYYY/MM/DD */

int FSsubFirstRec(FS_panel, FS_ifList);
                                      /* to get the first record in
                                         a subset */
int FSsubNextRec(FS_panel);           /* to get next subset record */

Field_Value *NewField(char,int,int,char*);

char *FSformatA(char*, char*);        /* formatted firestorm string */

char *FSformatU(char*, char*);        /* formatted firestorm string */

char *FSformatG(char*, char*);        /* formatted firestorm number */

char *FSformatH(char*, char*);        /* formatted firestorm number */

char *FSformatN(char*, char*);        /* formatted firestorm number */

char *FSformatD(char*, char*);        /* formatted firestorm date */

int FSrecCount(FS_panel);             /* record count in panel or subset */

char *FSformatT(char*, char*);        /* format firestorm time */
