#define DEBUG_FORTH 0

#if DEBUG_FORTH
#define DEBUG 1
#define SHOWPRM 1
#define DEBUGPRM 1
#define DEBUGIP 1
#define DEBUGFIL 1
/*#define PAUSE 1*/
#else
#undef  DEBUG       /* Show Forth Calls/Returns etc. */
#undef  SHOWPRM     /* Show Missing Primitive Number */
#undef  DEBUGPRM    /* Print Primitive Calls */
#undef  DEBUGIP     /* Print Instruction Pointer Values */
#undef  DEBUGFIL    /* Show File Related Calls (open/close/read...) */
#undef  PAUSE
#endif

#include "machine.h"
#include "forth.h"
#include "dot.h"
#include "ftable.h"

#if defined __MSDOS__
#include <errno.h>
#include <io.h>
#include <dir.h>
#include <share.h>
#include <fcntl.h>
#include <sys/stat.h>

#elif defined macintosh
#include <sys/errno.h>
#include <stdio.h>
#include <stdlib.h>

#elif defined VMS
#include <sys/errno.h>
#include <file.h>
#include <unixio.h>
#include <stat.h>
#define OPEN_PARAMS , 0, "ctx=stm"
#define CREAT_PARAMS    , "ctx=stm"

#elif defined __FreeBSD__
#include <stdio.h>
#include <fcntl.h>
#include <sys/errno.h>
#include <sys/types.h>
#include <sys/param.h>  /* needed for statfs */
#include <sys/mount.h>  /* needed for statfs */
#include <sys/stat.h>

#elif defined __svr4__
#include <stdio.h>
#include <fcntl.h>
#include <sys/errno.h>
#include <sys/types.h>
#include <sys/param.h>  /* needed for statfs */
#include <sys/mount.h>  /* needed for statfs */
#include <sys/stat.h>
#include <sys/statvfs.h>

#elif defined WIN32  /* WIN32 (particularly, WinNT) */
#include <errno.h>
#include <stdio.h>
#include <fcntl.h>
#include <io.h>
#include <WTYPES.H>
#include <WINBASE.H>
#include <sys/types.h>
#include <sys/locking.h>
#include <sys/stat.h>

#else   /* UNIX and any systems not specifically designated above */
#include <sys/errno.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>

/*#include <sys/statfs.h> doesn't work for Linux; use sys/vfs.h instead */
#include <sys/vfs.h>
#include <sys/stat.h>
#endif

extern int errno;

#ifndef O_BINARY
#define O_BINARY 0
#endif

#ifndef SH_DENYNONE
#define SH_DENYNONE 0
#endif

#ifndef OPEN_PARAMS
#define OPEN_PARAMS
#endif

#ifndef CREAT_PARAMS
#define CREAT_PARAMS
#endif

#define BASESIZE 5

GLOBAL_WRITE WUBYTE *basetable[BASESIZE];   /* Base Address Pointers    */
            /* DSEG = 0 => basetable[0] */
            /* XSEG = 1 => basetable[1] */

#ifndef _dot_h_
EXTERN_WRITE WSWORD FAR AX_DOT_R;   /* AX Argument Value for Engine */
EXTERN_WRITE WSWORD FAR BX_DOT_R;   /* BX Argument Value for Engine */
EXTERN_WRITE WSWORD FAR CX_DOT_R;   /* CX Argument Value for Engine */
EXTERN_WRITE WSWORD FAR DX_DOT_R;   /* DX Argument Value for Engine */
EXTERN_WRITE WSWORD FAR SI_DOT_R;   /* SI Argument Value for Engine */
EXTERN_WRITE WSWORD FAR DI_DOT_R;   /* DI Argument Value for Engine */
EXTERN_WRITE WSWORD FAR ES_DOT_R;   /* ES Argument Value for Engine */
EXTERN_WRITE WSWORD FAR DSEG;       /* Data Segment for Forth, Set to 0 */
EXTERN_WRITE WUWORD FAR Y_DOT_OFF;  /* Variable Direct Accessed by Interpreter */
EXTERN_WRITE WUWORD FAR Y_DOT_OFF0; /* Variable Direct Accessed by Interpreter */
EXTERN_WRITE WUWORD FAR II_DOT_SRA; /* Variable Direct Accessed by Interpreter */
EXTERN_WRITE WUWORD FAR II_DOT_SRB; /* Variable Direct Accessed by Interpreter */
EXTERN_WRITE WUBYTE FAR II_DOT_SRK; /* Variable Direct Accessed by Interpreter */
EXTERN_WRITE WUBYTE FAR II_DOT_SRN; /* Variable Direct Accessed by Interpreter */
EXTERN_WRITE WUWORD FAR KSL;        /* Variable Direct Accessed by Interpreter */

EXTERN_WRITE WUBYTE FAR FORTH;  /* Forth Objects */
EXTERN_WRITE WUBYTE FAR SERVER; /* Server Entry Point - 1 */
#endif

LOCAL_WRITE WUBYTE *code;       /* Pointer to Forth Objects */
LOCAL_WRITE WSWORD sstack[1024];    /* Parameter Stack */
LOCAL_WRITE WSWORD rstack[1024];    /* Return Stack */

#if __svr4__
LOCAL_WRITE struct flock flockp;    /* used by fcntl to (un)lock files */
LOCAL_WRITE struct statvfs statfsp; /* used by statfs to return fs data */
#elif ! defined __MSDOS__ & ! defined macintosh & ! defined WIN32
LOCAL_WRITE struct flock flockp;    /* used by fcntl to (un)lock files */
LOCAL_WRITE struct statfs statfsp;  /* used by statfs to return fs data */
#endif

LOCAL_WRITE WUBYTE b, b1, b2;       /* Byte Working Registers */
LOCAL_WRITE WSWORD w, w1;       /* Working Registers */
LOCAL_WRITE WUWORD uw, uw1; /* Unsigned Working Registers */
LOCAL_WRITE WSDWORD dw, dw1;    /* Long Working Registers */
LOCAL_WRITE WUDWORD udw, udw1;  /* Unsigned Long Working Registers */
LOCAL_WRITE WUBYTE *bp, *bp1;   /* Byte Pointer Working Registers */

#if defined SHOWPRM || defined DEBUGPRM
LOCAL_WRITE WSWORD primnum; /* Primitive Number for Debug Purposes */
#endif

#if defined DEBUG || defined DEBUGPRM
LOCAL_WRITE WSWORD *dsp;        /* Dump Stack Pointer */
LOCAL_WRITE WUWORD level;   /* Call nesting level for printout */
LOCAL_WRITE WUWORD curlev;  /* Call nesting level counter for printout */
#endif

#if DEBUG
#include "symbols.c"

int cmpAddr(void *a, void *b)
{
  return ((struct symbol *) a)->addr - ((struct symbol *) b)->addr;
}

char *SymbolLookup(WUWORD addr)
{
  struct symbol *found;
  struct symbol key;

  key.addr = addr + symbol[0].addr;
  found = (struct symbol *) bsearch(&key, symbol, 
          sizeof(symbol)/sizeof(symbol[0]), 
          sizeof(symbol[0]), cmpAddr);
  if (found == NULL) {
    static char buff[64];
    int i;

    for (i=0; i < sizeof(symbol)/sizeof(symbol[0]); i++) {
      if (symbol[i].addr > key.addr) {
        sprintf(buff, "between 0x%x=%s and 0x%x=%s", 
          symbol[i-1].addr-symbol[0].addr, symbol[i-1].name, 
          symbol[i].addr-symbol[0].addr, symbol[i].name);
        return buff;
      }
    }
    return "";
  }
  return found->name;
}
#endif


/* *************************** ENGINE() ******************************** */

WSWORD engine()
{
    register WSWORD *sp;        /* Paramater Stack Pointer */
    register WSWORD *rp;        /* Return Stack Pointer */
    register WSWORD *ip;        /* Interpreter Instruction Pointer */

#ifdef DEBUG
    printf("\nStarting up Interpreter\n");
    level = 0;
#endif

    sp = sstack - 1;
    rp = rstack - 1;
    ip = (WSWORD *)(&SERVER + 1);
    code = &FORTH;          /* Pointer to Forth Objects */
    basetable[0] = code;        /* Address pointer for DSEG */
    basetable[1] = code;        /* Address pointer for XSEG */
    DSEG = 0;

next:
#ifdef DEBUGIP
    printf(" - IP = 0x%X\n",(WUBYTE*)ip-code);
#endif
    uw = *ip++;
    if ( uw < 256 ) {
#ifdef DEBUGIP
    printf(" - load small integer %d\n", uw);
#endif
        *++sp = uw;
        goto next;
    }
exec:

#ifdef DEBUG
        for (curlev = 0; curlev < level; curlev++) printf("  ");
        printf("Bytecode number %d (%s)\n", 
                *(code+uw),
                forth_bytecode[*(code+uw)]);
#endif
    switch( *(code + uw++) ) {

    case 0:         /* DOCON: */
        *++sp = *(WSWORD *)(code + uw);
        goto next;

    case 1:         /* DO_DASH_MORE: */
        *(WSWORD *)(code + uw + 1) = *sp--;
        goto next;

    case 2:         /* DO0_DASH_MORE: */
        *(WSWORD *)(code + uw + 2) = 0;
        goto next;

    case 3:         /* DO_PLUS_MORE: */
        *(WSWORD *)(code + uw + 3) += *sp--;
        goto next;

    case 4:         /* DOINC: */
        *(WSWORD *)(code + uw + 4) += 1;
        goto next;

    case 5:         /* DOBCON: */
        *++sp = *(code + uw);
        goto next;

    case 6:         /* DOB_DASH_MORE: */
        *(code + uw + 1) = *sp--;
        goto next;

    case 7:         /* DOB0_DASH_MORE: */
        *(code + uw + 2) = 0;
        goto next;

    case 8:         /* DOCOL: */
    case 9:         /* DOCOL1: */
#ifdef DEBUG
        printf("\n");
        for (curlev = 0; curlev < level; curlev++) printf("  ");
        printf("Calling: 0x%X (%s)\n",uw-1,SymbolLookup(uw-1));
        for (curlev = 0; curlev < level; curlev++) printf("  ");
        printf("Dump of S-Stack(%d): ",(sp-sstack+1));
        level++;
        dsp = sp;
        while (dsp >= sstack)
            printf(" %d",*dsp--);
        printf("\n");
#endif
        *++rp = ((WUBYTE *)ip) - code;
        ip = (WSWORD *)(code + uw);
        goto next;

    case 10:            /* DO_SEMI_S: */
#ifdef DEBUG
        level--;
        printf("\n");
        for (curlev = 0; curlev < level; curlev++) printf("  ");
        printf("Returning\n");
        for (curlev = 0; curlev < level; curlev++) printf("  ");
        printf("Dump of S-Stack(%d): ",(sp-sstack+1));
        dsp = sp;
        while (dsp >= sstack)
            printf(" %d",*dsp--);
        printf("\n");
#endif
        ip = (WSWORD *)(code + (WUWORD)*rp--);
        goto next;

    case 11:            /* DOVAR: */
        *++sp = uw;
        goto next;

    case 12:            /* DODOES: */
#ifdef DEBUG
        printf("\n");
        for (curlev = 0; curlev < level; curlev++) printf("  ");
        printf("DoDoes-ing: 0x%X\n",uw-1);
        for (curlev = 0; curlev < level; curlev++) printf("  ");
        printf("Dump of S-Stack(%d): ",(sp-sstack+1));
        level++;
        dsp = sp;
        while (dsp >= sstack)
            printf(" %d",*dsp--);
        printf("\n");
#endif
        *++rp = (WSWORD)((WUBYTE *)ip - code);
        ip = (WSWORD *)(code + uw);
        uw += 2;
        *++sp = uw;
        goto next;
    case 13:
#if defined SHOWPRM || defined DEBUGPRM
        primnum = *(WSWORD *)(code + uw);
#ifdef DEBUGPRM
        printf("\n");
        for (curlev = 0; curlev < level; curlev++) printf("  ");
        printf("Primitive Number: %3d (%s)\n",primnum,forth_primitive[primnum]);
        for (curlev = 0; curlev < level; curlev++) printf("  ");
        printf("Dump of S-Stack(%d): ",(sp-sstack+1));
        dsp = sp;
        while (dsp >= sstack)
            printf(" %d",*dsp--);
        printf("\n");
#endif
        switch (primnum) {
#else   /* if not debugging primitives */
        switch ( *(WSWORD *)(code + uw) ) {
#endif

#ifdef FP_EXECUTE
        case FP_EXECUTE:
            w = *sp--;
            goto exec;
#endif

        case FP_LIT:
            *++sp = *ip++;
            goto next;

        case FP_BRANCH1:
            (WUBYTE *)ip += *((WUBYTE *)ip)++;
            goto next;

        case FP_0BRANCH1:
            if(*sp-- == 0) {
                (WUBYTE *)ip += *((WUBYTE *)ip)++;
                goto next;
            }
            ((WUBYTE *)ip)++;
            goto next;

        case FP_NZBRCH1:
            if(*sp-- != 0) {
                (WUBYTE *)ip += *((WUBYTE *)ip)++;
                goto next;
            }
            ((WUBYTE *)ip)++;
            goto next;

        case FP_DH_D0BR1:
            if(*sp == 0) {
                sp--;
                (WUBYTE *)ip += *((WUBYTE *)ip)++;
                goto next;
            }
            ((WUBYTE *)ip)++;
            goto next;

        case FP_D0BR1:
            if(*sp == 0) {
                (WUBYTE *)ip += *((WUBYTE *)ip)++;
                goto next;
            }
            ((WUBYTE *)ip)++;
            goto next;

        case FP_BRANCH:
            (WUBYTE *)ip += *ip;
            goto next;

        case FP_0BRANCH:
            if(*sp-- == 0) {
                (WUBYTE *)ip += *ip;
                goto next;
            }
            ip++;
            goto next;

        case FP_LP_LOOP_RP:
            (*rp)++;
            if(*(rp-1) <= *rp) {
                rp -= 2;
                ip++;
                goto next;
            }
            (WUBYTE *)ip += *ip;
            goto next;

        case FP_NZBRCH:
            if(*sp-- != 0) {
                (WUBYTE *)ip += *ip;
                goto next;
            }
            ip++;
            goto next;

        case FP_0BR_AN_DROP:
            if(*sp-- == 0) {
                (WUBYTE *)ip += *ip;
                goto next;
            }
            sp--;
            ip++;
            goto next;

        case FP_LP_PL_LOOP_RP:
            w = *sp--;
            w1 = *rp - *(rp-1);
            if(w1 == 0) {
                rp -= 2;
                ip++;
                goto next;
            }
            (*rp) += w;
            w += w1;
            if(w1 >= 0) {
                if(w <= 0) {
                    rp -= 2;
                    ip++;
                    goto next;
                }
            } else {
                if(w >= 0) {
                    rp -= 2;
                    ip++;
                    goto next;
                }
            }
            (WUBYTE *)ip += *ip;
            goto next;

        case FP_DH_D0BR:
            if(*sp == 0) {
                sp--;
                (WUBYTE *)ip += *ip;
                goto next;
            }
            ip++;
            goto next;

#ifdef FP_D0BR
        case FP_D0BR:
            if(*sp == 0) {
                (WUBYTE *)ip += *ip;
                goto next;
            }
            ip++;
            goto next;
#endif

        case FP_DH_DNZBR:
            if(*sp != 0) {
                (WUBYTE *)ip += *ip;
                goto next;
            }
            sp--;
            ip++;
            goto next;

        case FP_DNZBR:
            if(*sp != 0) {
                (WUBYTE *)ip += *ip;
                goto next;
            }
            ip++;
            goto next;

        case FP_D0BR_AN_DROP:
            if(*sp == 0) {
                (WUBYTE *)ip += *ip;
                goto next;
            }
            sp--;
            ip++;
            goto next;

        case FP_0DROP_AN_BR:
            if(*sp-- == 0) {
                sp--;
                (WUBYTE *)ip += *ip;
                goto next;
            }
            ip++;
            goto next;

        case FP_0DROPX:
            if(*sp-- == 0) {
                sp--;
#ifdef DEBUG
        level--;
        printf("\n");
        for (curlev = 0; curlev < level; curlev++) printf("  ");
        printf("Exiting\n");
        for (curlev = 0; curlev < level; curlev++) printf("  ");
        printf("Dump of S-Stack(%d): ",(sp-sstack+1));
        dsp = sp;
        while (dsp >= sstack)
            printf(" %d",*dsp--);
        printf("\n");
#endif
                ip = (WSWORD *)(code + (WUWORD)*rp--);
            }
            goto next;

        case FP_0EXIT:
            if (*sp-- == 0) {
#ifdef DEBUG
        level--;
        printf("\n");
        for (curlev = 0; curlev < level; curlev++) printf("  ");
        printf("Exiting\n");
        for (curlev = 0; curlev < level; curlev++) printf("  ");
        printf("Dump of S-Stack(%d): ",(sp-sstack+1));
        dsp = sp;
        while (dsp >= sstack)
            printf(" %d",*dsp--);
        printf("\n");
#endif
                ip = (WSWORD *)(code + (WUWORD)*rp--);
            }
            goto next;

        case FP_NZEXIT:
            if (*sp-- != 0) {
#ifdef DEBUG
        level--;
        printf("\n");
        for (curlev = 0; curlev < level; curlev++) printf("  ");
        printf("Exiting\n");
        for (curlev = 0; curlev < level; curlev++) printf("  ");
        printf("Dump of S-Stack(%d): ",(sp-sstack+1));
        dsp = sp;
        while (dsp >= sstack)
            printf(" %d",*dsp--);
        printf("\n");
#endif
                ip = (WSWORD *)(code + (WUWORD)*rp--);
            }
            goto next;

        case FP_NZDROPX:
            if (*sp-- != 0) {
                sp--;
#ifdef DEBUG
        level--;
        printf("\n");
        for (curlev = 0; curlev < level; curlev++) printf("  ");
        printf("Exiting\n");
        for (curlev = 0; curlev < level; curlev++) printf("  ");
        printf("Dump of S-Stack(%d): ",(sp-sstack+1));
        dsp = sp;
        while (dsp >= sstack)
            printf(" %d",*dsp--);
        printf("\n");
#endif
                ip = (WSWORD *)(code + (WUWORD)*rp--);
            }
            goto next;

        case FP_LP_LOOP1_RP:
            (*rp)++;
            if(*(rp-1) <= *rp) {
                rp -= 2;
                ((WUBYTE *)ip)++;
                goto next;
            }
            (WUBYTE *)ip -= *((WUBYTE *)ip)++;
            goto next;

        case FP_LP_DO_RP:
            *++rp = *(sp-1);
            *++rp = *sp--;
            sp--;
            goto next;

        case FP_LB_BDO_RB:
            w = *sp--;
            *++rp = w + *sp;
            *++rp = *sp--;
            goto next;

        case FP_LB_0DO_RB:
            *++rp = *sp--;
            *++rp = 0;
            goto next;

        case FP_DIGIT:
            w = *(sp-1) % 256 - '0';
            if (w>=0 && (w<=9 || (w-=7)>=10)) {
                if (w < *sp-- % 256) {
                    *sp = w;
                    *++sp = 1;
                    goto next;
                }
                *sp = 0;
                goto next;
            }
            *--sp = 0;
            goto next;

        case FP_U_ST:
            udw = (WUDWORD)(WUWORD)(*sp) * (WUDWORD)(WUWORD)*(sp-1);
            *(sp-1) = udw & 0x0FFFF;
            *sp = udw >> 16;
            goto next;

        case FP_U_SL:
            uw = (WUWORD)(*sp--);
            if (uw > (WUWORD)*sp) {
                udw = (((WUDWORD)(WUWORD)(*sp)) << 16) + (WUWORD)*(sp-1);
                *(sp-1) = udw % uw;
                *sp = udw / uw;
                goto next;
            }
            *sp = 0x0FFFF;
            *(sp-1) = 0x0FFFF;
            goto next;

        case FP_E_ST:
            uw = (WUWORD)(*sp--);
            udw = (((WUDWORD)(WUWORD)(*sp)) << 16) + (WUWORD)*(sp-1);
            udw *= uw;
            *(sp-1) = udw & 0x0FFFF;
            *sp = udw >> 16;
            goto next;

        case FP_E_SL_MOD:
            uw = (WUWORD)(*sp);
            udw = (((WUDWORD)(WUWORD)*(sp-1)) << 16) + (WUWORD)*(sp-2);
            *(sp-2) = udw % uw;
            udw = udw / uw;
            *(sp-1) = udw & 0x0FFFF;
            *sp = udw >> 16;
            goto next;

        case FP_AND:
            w = *sp--;
            *sp &= w;
            goto next;

        case FP_OR:
            w = *sp--;
            *sp |= w;
            goto next;

#ifdef FP_XOR
        case FP_XOR:
            w = *sp--;
            *sp ^= w;
            goto next;
#endif

        case FP_0_LT_GT_AND:
            if (*sp-- != 0 && *sp != 0) {
                *sp = 1;
                goto next;
            }
            *sp = 0;
            goto next;

        case FP_0_EQ_AND:
            if (*sp-- == 0 && *sp != 0) {
                *sp = 1;
                goto next;
            }
            *sp = 0;
            goto next;

        case FP_C_AT_DH_AND_DT_OP:
            uw = *sp + *((WUBYTE *)ip)++;
            *sp = (WSWORD)(*(code + uw) & *((WUBYTE *)ip)++);
            goto next;

        case FP_B_DH_AND_DT_OP:
            *sp &= *((WUBYTE *)ip)++;
            goto next;

#ifdef FP_FIELD_DH_TYPE
        case FP_FIELD_DH_TYPE:
            *sp = *(code + (WUWORD)*sp + 1) & 0x1c;
            goto next;
#endif

#ifdef FP_EVAL_DH_SUB
        case FP_EVAL_DH_SUB:
            *++rp = (WUBYTE *)ip - code;
            ip = (WSWORD *)(code + (WUWORD)*(rp - 1));
            goto next;
#endif

#ifdef FP_SP_AT
        case FP_SP_AT:
            w = (WUBYTE *)sp - (WUBYTE *)sstack;
            *++sp = w;
            goto next;
#endif

#ifdef FP_SP_SV
        case FP_SP_SV:
            sp = sstack - 1;
            goto next;
#endif

#ifdef FP_SP_SV_SV
        case FP_SP_SV_SV:
            w = *sp--;
            (WUBYTE *)sp = (WUBYTE *)sstack + w;
            goto next;
#endif

#ifdef FP_RP_AT
        case FP_RP_AT:
            *++sp = (WUBYTE *)rp - (WUBYTE *)rstack;
            goto next;
#endif

#ifdef FP_RV_SV
        case FP_RP_SV:
            rp = rstack - 1;
            goto next;
#endif

        case FP_LEAVE:
            *(rp-1) = *rp;
            goto next;

        case FP_GT_R:
            *++rp = *sp--;
            goto next;

        case FP_R_GT:
            *++sp = *rp--;
            goto next;

        case FP_I:
        case FP_R:
            *++sp = *rp;
            goto next;

        case FP_DUP_GT_R:
            *++rp = *sp;
            goto next;

        case FP_R_GT_DROP:
            rp--;
            goto next;

        case FP_0_EQ:
            if (*sp == 0) {
                *sp = 1;
                goto next;
            }
            *sp = 0;
            goto next;

        case FP_0_LT_GT:
            if (*sp != 0) {
                *sp = 1;
                goto next;
            }
            *sp = 0;
            goto next;

        case FP_0_LT:
            if (*sp < 0) {
                *sp = 1;
                goto next;
            }
            *sp = 0;
            goto next;

        case FP_PL:
            w = *sp--;
            *sp += w;
            goto next;

        case FP_B_PL_DT_OP:
            *sp += *((WUBYTE *)ip)++;
            goto next;

        case FP_DO_PL_SC:
            w = *sp--;
            *sp += w;
#ifdef DEBUG
        level--;
        printf("\n");
        for (curlev = 0; curlev < level; curlev++) printf("  ");
        printf("Returning\n");
        for (curlev = 0; curlev < level; curlev++) printf("  ");
        printf("Dump of S-Stack(%d): ",(sp-sstack+1));
        dsp = sp;
        while (dsp >= sstack)
            printf(" %d",*dsp--);
        printf("\n");
#endif
            ip = (WSWORD *)(code + (WUWORD)*rp--);
            goto next;

        case FP_MINUS:
            *sp = -*sp;
            goto next;

        case FP_DH:
            w = *sp--;
            *sp -= w;
            goto next;

        case FP_SWAP_DH:
            w = *sp--;
            *sp = w - *sp;
            goto next;

        case FP_LT:
            if (*sp > *(sp-1)) {
                sp--;
                *sp = 1;
                goto next;
            }
            sp--;
            *sp = 0;
            goto next;

        case FP_GT:
            if (*sp < *(sp-1)) {
                sp--;
                *sp = 1;
                goto next;
            }
            sp--;
            *sp = 0;
            goto next;

#ifdef FP_LT_DT_OP
        case FP_LT_DT_OP:
            if (*sp < *((WUBYTE *)ip)++) {
                *sp = 1;
                goto next;
            }
            *sp = 0;
            goto next;
#endif
            
#ifdef FP_GT_DT_OP
        case FP_GT_DT_OP:
            if (*sp > *((WUBYTE *)ip)++) {
                *sp = 1;
                goto next;
            }
            *sp = 0;
            goto next;
#endif

#ifdef FP_ROT
        case FP_ROT:
            w = *(sp-2);
            *(sp-2) = *(sp-1);
            *(sp-1) = *sp;
            *sp = w;
            goto next;
#endif

#ifdef FP_OVER
        case FP_OVER:
            w = *(sp-1);
            *++sp = w;
            goto next;
#endif

#ifdef FP_OVER_DH
        case FP_OVER_DH:
            *sp = *sp - *(sp-1);
            goto next;
#endif

#ifdef FP_OVER_PL
        case FP_OVER_PL:
            *sp = *sp + *(sp-1);
            goto next;
#endif

#ifdef FP_DROP
        case FP_DROP:
            sp--;
            goto next;
#endif

#ifdef FP_SWAP
        case FP_SWAP:
            w = *(sp-1);
            *(sp-1) = *sp;
            *sp = w;
            goto next;
#endif

#ifdef FP_DUP
        case FP_DUP:
            w = *sp;
            *++sp = w;
            goto next;
#endif

#ifdef FP_2DUP
        case FP_2DUP:
            w = *(sp-1);
            *++sp = w;
            w = *(sp-1);
            *++sp = w;
            goto next;
#endif

#ifdef FP_4DUP
        case FP_4DUP:
            w = *(sp-3);
            *++sp = w;
            w = *(sp-3);
            *++sp = w;
            w = *(sp-3);
            *++sp = w;
            w = *(sp-3);
            *++sp = w;
            goto next;
#endif

#ifdef FP_PL_SV
        case FP_PL_SV:
            uw = *sp--;
/* CODE READ-ONLY */
if (uw < 0x4360) return 3500;
            *(WSWORD *)(code + uw) += *sp--;
            goto next;
#endif

#ifdef FP_TOGGLE
        case FP_TOGGLE:
            w = *sp--;
            *(code + (WUWORD)*sp--) ^= w;
            goto next;
#endif

#ifdef FP_BITS_DH_ON
        case FP_BITS_DH_ON:
            w = *sp--;
            *(code + (WUWORD)*sp--) |= w;
            goto next;
#endif

#ifdef FP_BITS_DH_OFF
        case FP_BITS_DH_OFF:
            w = *sp--;
            *(code + (WUWORD)*sp--) &= w ^ 0xff;
            goto next;
#endif

#ifdef FP_2DUPOR
        case FP_2DUPOR:
            w = *sp | *(sp-1);
            *++sp = w;
            goto next;
#endif

#ifdef FP_D_PL
        case FP_D_PL:
            dw1 = (WSDWORD)(*sp--) << 16;
            dw1 += (WUWORD)*sp--;
            dw = (WSDWORD)*sp << 16;
            dw += (WUWORD)*(sp-1);
            dw += dw1;
            *(sp-1) = dw & 0x0FFFF;
            *sp = dw >> 16;
            goto next;
#endif

#ifdef FP_1D_PL
        case FP_1D_PL:
            dw = (WSDWORD)*sp << 16;
            dw += (WUWORD)*(sp-1);
            dw += 1;
            *(sp-1) = dw & 0x0FFFF;
            *sp = dw >> 16;
            goto next;
#endif

#ifdef FP_D_DH
        case FP_D_DH:
            dw1 = (WSDWORD)(*sp--) << 16;
            dw1 += (WUWORD)*sp--;
            dw = (WSDWORD)*sp << 16;
            dw += (WUWORD)*(sp-1);
            dw -= dw1;
            *(sp-1) = dw & 0x0FFFF;
            *sp = dw >> 16;
            goto next;
#endif

#ifdef FP_DMINUS
        case FP_DMINUS:
            dw = -((WSDWORD)*sp << 16);
            dw -= (WUWORD)*(sp-1);
            *(sp-1) = dw & 0x0FFFF;
            *sp = dw >> 16;
            goto next;
#endif

#ifdef FP_D_EQ
        case FP_D_EQ:
            if (((*sp) == *(sp-2)) && (*(sp-1) == *(sp-3))) {
                sp -= 3;
                *sp = 1;
                goto next;
            }
                sp -= 3;
                *sp = 0;
                goto next;
#endif

#ifdef FP_D_GT
        case FP_D_GT:
            dw = (WSDWORD)(*sp--) << 16;
            dw += (WUWORD)*sp--;
            dw1 = (WSDWORD)(*sp--) << 16;
            dw1 += (WUWORD)*(sp);
            if (dw1 > dw) {
                *sp = 1;
                goto next;
            }
            *sp = 0;
            goto next;
#endif

#ifdef FP_D_LT
        case FP_D_LT:
            dw = (WSDWORD)(*sp--) << 16;
            dw += (WUWORD)*sp--;
            dw1 = (WSDWORD)(*sp--) << 16;
            dw1 += (WUWORD)*(sp);
            if (dw1 < dw) {
                *sp = 1;
                goto next;
            }
            *sp = 0;
            goto next;
#endif

#ifdef FP_DINC
        case FP_DINC:
            uw = *sp--;
            dw = *(WUWORD *)(code + uw);
            dw += ((WSDWORD)*(WSWORD *)(code + uw + 2)) << 16;
            dw++;
            *(WSWORD *)(code + uw) = dw & 0x0FFFF;
            *(WSWORD *)(code + uw + 2) = dw >> 16;
            goto next;
#endif

#ifdef FP_AT
        case FP_AT:
            *sp = *(WSWORD *)(code + (WUWORD)(*sp));
            goto next;
#endif

#ifdef FP_C_AT
        case FP_C_AT:
            *sp = *(code + (WUWORD)(*sp));
            goto next;
#endif

#ifdef FP_2_AT
        case FP_2_AT:
            uw = *sp;
            *sp = *(WSWORD *)(code + uw);
            *++sp = *(WSWORD *)(code + uw + 2);
            goto next;
#endif

#ifdef FP_SV
        case FP_SV:
            uw = *sp--;
/* CODE READ-ONLY */
if (uw < 0x4360) return 3501;
            *(WSWORD *)(code + uw) = *sp--;
            goto next;
#endif
            
#ifdef FP_SWAP_SV
        case FP_SWAP_SV:
            w = *sp--;
/* CODE READ-ONLY */
if ((WUWORD)*sp < 0x4360) return 3502;
            *(WSWORD *)(code + (WUWORD)*sp--) = w;
            goto next;
#endif

#ifdef FP_C_SV
        case FP_C_SV:
            uw = *sp--;
/* CODE READ-ONLY */
if (uw < 0x4360) return 3503;
            *(code + uw) = *sp--;
            goto next;
#endif
            
#ifdef FP_SWAPC_SV
        case FP_SWAPC_SV:
            w = *sp--;
/* CODE READ-ONLY */
if ((WUWORD)*sp < 0x4360) return 3504;
            *(code + (WUWORD)*sp--) = w;
            goto next;
#endif

#ifdef FP_2_SV
        case FP_2_SV:
            uw = *sp--;
/* CODE READ-ONLY */
if (uw < 0x4360) return 3505;
            *(WSWORD *)(code + uw + 2) = *sp--;
            *(WSWORD *)(code + uw) = *sp--;
            goto next;
#endif
            
#ifdef FP_LT_OVER_EQ_IFDROP_GT
        case FP_LT_OVER_EQ_IFDROP_GT:
            w = *sp--;
            if (*sp == w) {
                sp--;
                ip++;
                goto next;
            }
            (WUBYTE *)ip += *ip;
            goto next;
#endif

#ifdef FP_OF_DH_S_DT_OP
        case FP_OF_DH_S_DT_OP:
            w = *((WUBYTE *)ip)++;
            if (w == ((*sp) & 0x0FF)) {
                sp--;
                ((WUBYTE *)ip)++;
                goto next;
            }
            (WUBYTE *)ip += *((WUBYTE *)ip)++;
            goto next;
#endif

#ifdef FP_DH_DUP
        case FP_DH_DUP:
            if (*sp != 0) {
                w = *sp;
                *++sp = w;
            }
            goto next;
#endif

#ifdef FP_2SWAP
        case FP_2SWAP:
            w = *(sp-2);
            *(sp-2) = *sp;
            *sp = w;
            w = *(sp-3);
            *(sp-3) = *(sp-1);
            *(sp-1) = w;
            goto next;
#endif

#ifdef FP_4DROP
        case FP_4DROP:
            sp -= 4;
            goto next;
#endif

#ifdef FP_3DROP
        case FP_3DROP:
            sp -= 3;
            goto next;
#endif

#ifdef FP_2DROP
        case FP_2DROP:
            sp -= 2;
            goto next;
#endif

#ifdef FP_SWAPDROP
        case FP_SWAPDROP:
            w = *sp--;
            *sp = w;
            goto next;
#endif

#ifdef FP_SWAPDUP
        case FP_SWAPDUP:
            w = *(sp-1);
            *(sp-1) = *sp;
            *sp = w;
            *++sp = w;
            goto next;
#endif

#ifdef FP_SWAPOVER
        case FP_SWAPOVER:
            w = *sp;
            *sp = *(sp-1);
            *(sp-1) = w;
            *++sp = w;
            goto next;
#endif

#ifdef FP_LT_GT
        case FP_LT_GT:
            if ((*sp) != *(sp-1)) {
                sp--;
                *sp = 1;
                goto next;
            }
                sp--;
                *sp = 0;
                goto next;
#endif

#ifdef FP_EQ
        case FP_EQ:
            if ((*sp) == *(sp-1)) {
                sp--;
                *sp = 1;
                goto next;
            }
                sp--;
                *sp = 0;
                goto next;
#endif

#ifdef FP_1_PL
        case FP_1_PL:
            *sp += 1;
            goto next;
#endif

#ifdef FP_2_PL
        case FP_2_PL:
            *sp += 2;
            goto next;
#endif

#ifdef FP_3_PL
        case FP_3_PL:
            *sp += 3;
            goto next;
#endif

#ifdef FP_4_PL
        case FP_4_PL:
            *sp += 4;
            goto next;
#endif

#ifdef FP_5_PL
        case FP_5_PL:
            *sp += 5;
            goto next;
#endif

#ifdef FP_6_PL
        case FP_6_PL:
            *sp += 6;
            goto next;
#endif

#ifdef FP_1_DH
        case FP_1_DH:
            *sp -= 1;
            goto next;
#endif

#ifdef FP_2_DH
        case FP_2_DH:
            *sp -= 2;
            goto next;
#endif

#ifdef FP_3_DH
        case FP_3_DH:
            *sp -= 3;
            goto next;
#endif

#ifdef FP_PUSH11
        case FP_PUSH11:
            *++sp = 1;
            *++sp = 1;
            goto next;
#endif

#ifdef FP_PUSH00
        case FP_PUSH00:
            *++sp = 0;
            *++sp = 0;
            goto next;
#endif

#ifdef FP_PUSH10
        case FP_PUSH10:
            *++sp = 1;
            *++sp = 0;
            goto next;
#endif

#ifdef FP_PUSH01
        case FP_PUSH01:
            *++sp = 0;
            *++sp = 1;
            goto next;
#endif

#ifdef FP_U_LT
        case FP_U_LT:
            if ((WUWORD)(*sp) > (WUWORD)*(sp-1)) {
                sp--;
                *sp = 1;
                goto next;
            }
            sp--;
            *sp = 0;
            goto next;
#endif

#ifdef FP_COUNT
        case FP_COUNT:
            uw = *sp;
            (*sp)++;
            *++sp = *(code + uw);
            goto next;
#endif

#ifdef FP_COUNT_PL
        case FP_COUNT_PL:
            uw = *sp;
            *sp = (*(code + uw)) + uw + 1;
            goto next;
#endif

#ifdef FP_DL_CATENATE
        case FP_DL_CATENATE:
            uw = *sp--;
            w1 = ++(*(code + uw));
            *(code + uw + w1) = *sp--;
            goto next;
#endif

#ifdef FP_2COUNT
        case FP_2COUNT:
            uw = *sp;
            *sp += 2;
            *++sp = *(WSWORD *)(code + uw);
            goto next;
#endif

#ifdef FP_DH_2DUP
        case FP_DH_2DUP:
            w = *sp | *(sp-1);
            if (w != 0) {
                *++sp = w;
                goto next;
            }
            *--sp = 0;
            goto next;
#endif

#ifdef FP_OVERC_SV_1_PL
        case FP_OVERC_SV_1_PL:
            uw = (*(sp-1))++;
/* CODE READ-ONLY */
if (uw < 0x4360) return 3506;
            *(code + uw) = *sp--;
            goto next;
#endif

#ifdef FP_SWAPOVERC_SV_1_PL
        case FP_SWAPOVERC_SV_1_PL:
            uw = *sp--;
/* CODE READ-ONLY */
if (uw < 0x4360) return 3507;
            *(code + uw) = *sp;
            *sp = uw + 1;
            goto next;
#endif

#ifdef FP_EQ_OR_EQ
        case FP_EQ_OR_EQ:
            if (((*sp) == *(sp-2)) || (*(sp-1) == *(sp-2))) {
                sp -= 2;
                *sp = 1;
                goto next;
            }
            sp -= 2;
            *sp = 0;
            goto next;
#endif

#ifdef FP_GT_AND_LT
        case FP_GT_AND_LT:
            if (((*sp) > *(sp-2)) && (*(sp-1) < *(sp-2))) {
                sp -= 2;
                *sp = 1;
                goto next;
            }
            sp -= 2;
            *sp = 0;
            goto next;
#endif

#ifdef FP_256_SL
        case FP_256_SL:
            *sp = (*sp) >> 8;
            goto next;
#endif

#ifdef FP_256_ST
        case FP_256_ST:
            *sp = (*sp) << 8;
            goto next;
#endif

#ifdef FP_256_ST_PL
        case FP_256_ST_PL:
            b = *sp--;
            *sp = (WUBYTE)(*sp) + (b * 256);
            goto next;
#endif

#ifdef FP_XXLAT
        case FP_XXLAT:
            uw = *sp--;
            b = *sp;
            do {
                if (*(code + uw) == b) {
                    *sp = *(code + uw + 1);
                    goto next;
                }
                uw += 2;
            } while (*(code + uw) != 0);
            *sp = *(code + uw + 1);
            goto next;
#endif

#ifdef FP_MEMBER
        case FP_MEMBER:
            b = *sp--;
            uw = *sp;
            uw1 = *(sp-1);
            while(uw-- > 0) {
                if (*(code + uw1++) == b) {
                    uw = *sp - uw;
                    *--sp = uw;
                    goto next;
                }
            }
            *--sp = 0;
            goto next;
#endif

#ifdef FP_TRAILC
        case FP_TRAILC:
            b = *sp;
            uw = *(sp-1);
            uw1 = *(sp-2) + uw - 1;
            while (uw > 0) {
                if (*(code + uw1--) != b) {
                    *sp = *(sp-1) - uw;
                    goto next;
                }
                uw--;
            }
            *sp = *(sp-1);
            goto next;
#endif

#ifdef FP_2DROP0
        case FP_2DROP0:
            *--sp = 0;
            goto next;
#endif

#ifdef FP_DROP0
        case FP_DROP0:
            *sp = 0;
            goto next;
#endif

#ifdef FP_3PICK
        case FP_3PICK:
            w = *(sp-2);
            *++sp = w;
            goto next;
#endif

#ifdef FP_4PICK
        case FP_4PICK:
            w = *(sp-3);
            *++sp = w;
            goto next;
#endif

#ifdef FP_5PICK
        case FP_5PICK:
            w = *(sp-4);
            *++sp = w;
            goto next;
#endif

#ifdef FP_IF_DH_SD_DH_ELSE_DH_D
        case FP_IF_DH_SD_DH_ELSE_DH_D:
            w = *sp--;
            w1 = *sp--;
            if (w) *sp = w1;
            goto next;
#endif

#ifdef FP_SCMOVE
        case FP_SCMOVE:
            uw = *sp--;
            uw1 = *sp--;
            if ((WUWORD)*sp < BASESIZE)
                bp = basetable[*sp--] + uw1;
            else {
#ifdef DEBUG
                printf("\nBad Base Table Index = %u !\n",*sp);
#endif
                return 2562;
            }
            uw1 = *sp--;
            if ((WUWORD)*sp < BASESIZE)
                bp1 = basetable[*sp--] + uw1;
            else {
#ifdef DEBUG
                printf("\nBad Base Table Index = %u !\n",*sp);
#endif
                return 2563;
            }
            while (uw-- > 0)
                *bp++ = *bp1++;
            goto next;
#endif

#ifdef FP_FILL
        case FP_FILL:
            b = *sp--;
            uw1 = *sp--;
            uw = *sp--;
            while (uw1-- > 0)
                *(code + uw++) = b;
            goto next;
#endif

#ifdef FP_CMOVE
        case FP_CMOVE:
            uw = *sp--;
            bp = code + (WUWORD)*sp--;
            bp1 = code + (WUWORD)*sp--;
            while (uw-- > 0)
                *bp++ = *bp1++;
            goto next;
#endif

#ifdef FP_SWAPCMOVE
        case FP_SWAPCMOVE:
            bp = code + (WUWORD)*sp--;
            uw = *sp--;
            bp1 = code + (WUWORD)*sp--;
            while (uw-- > 0)
                *bp++ = *bp1++;
            goto next;
#endif

#ifdef FP_MAKE_DL
        case FP_MAKE_DL:
            bp = code + (WUWORD)*sp--;
            uw = *sp--;
            *bp++ = uw;
            bp1 = code + (WUWORD)*sp--;
            while (uw-- > 0)
                *bp++ = *bp1++;
            goto next;
#endif

#ifdef FP_DL_MOVE
        case FP_DL_MOVE:
            bp = code + (WUWORD)*sp--;
            bp1 = code + (WUWORD)*sp--;
            uw = *bp1 + 1;
            while (uw-- > 0)
                *bp++ = *bp1++;
            goto next;
#endif

#ifdef FP_BMOVE
        case FP_BMOVE:
            uw = *sp--;
            bp = code + (WUWORD)*sp-- + uw - 1;
            bp1 = code + (WUWORD)*sp-- + uw - 1;
            while (uw-- > 0)
                *bp-- = *bp1--;
            goto next;
#endif

#ifdef FP_LC_AT
        case FP_LC_AT:
            uw1 = *sp--;
            if ((WUWORD)*sp < BASESIZE)
                bp = basetable[*sp] + uw1;
            else {
#ifdef DEBUG
                printf("\nBad Base Table Index = %u !\n",*sp);
#endif
                return 2564;
            }
            *sp = *bp;
            goto next;
#endif

#ifdef FP_L_AT
        case FP_L_AT:
            uw1 = *sp--;
            if ((WUWORD)*sp < BASESIZE)
                bp = basetable[*sp] + uw1;
            else {
#ifdef DEBUG
                printf("\nBad Base Table Index = %u !\n",*sp);
#endif
                return 2565;
            }
            *sp = *(WSWORD *)bp;
            goto next;
#endif

#ifdef FP_L_SV
        case FP_L_SV:
            uw1 = *sp--;
            if ((WUWORD)*sp < BASESIZE)
                bp = basetable[*sp--] + uw1;
            else {
#ifdef DEBUG
                printf("\nBad Base Table Index = %u !\n",*sp);
#endif
                return 2565;
            }
            *(WSWORD *)bp = *sp--;
            goto next;
#endif

#ifdef FP_PL_SV_AT
        case FP_PL_SV_AT:
            uw = *sp--;
/* CODE READ-ONLY */
if (uw < 0x4360) return 3508;
            *sp = (*(WSWORD *)(code + uw) += *sp);
            goto next;
#endif

#ifdef FP_ROTROT
        case FP_ROTROT:
            w = *sp;
            *sp = *(sp-1);
            *(sp-1) = *(sp-2);
            *(sp-2) = w;
            goto next;
#endif

#ifdef FP_IC_AT
        case FP_IC_AT:
            uw = *rp;
            *++sp = *(code + uw);
            goto next;
#endif

#ifdef FP_IC_SV
        case FP_IC_SV:
            uw = *rp;
/* CODE READ-ONLY */
if (uw < 0x4360) return 3509;
            *(code + uw) = *sp--;
            goto next;
#endif

#ifdef FP_2_ST
        case FP_2_ST:
            *sp = (*sp) << 1;
            goto next;
#endif

#ifdef FP_2_SL
        case FP_2_SL:
            *sp = (*sp) >> 1;
            goto next;
#endif

#ifdef FP_3_ST
        case FP_3_ST:
            *sp = (*sp << 1) + *sp;
            goto next;
#endif

#ifdef FP_PL_PL
        case FP_PL_PL:
            *(sp-2) += *sp;
            *(sp-3) += *(sp-1);
            sp -= 2;
            goto next;
#endif

#ifdef FP_DUP_DH_PL_PL
        case FP_DUP_DH_PL_PL:
            *(sp-2) += *sp;
            *(sp-1) -= *sp;
            sp--;
            goto next;
#endif

#ifdef FP_1_DH_1_PL_PL
        case FP_1_DH_1_PL_PL:
            (*(sp-1))++;
            (*sp)--;
            goto next;
#endif

#ifdef FP_BDOSX_DH_WRITE
        case FP_BDOSX_DH_WRITE:
            w = *sp--;
            uw = *sp--;
            uw1 = *sp--;
            if ((WUWORD)*sp < BASESIZE)
                bp = basetable[*sp] + uw1;
            else {
#ifdef DEBUG
                printf("\nBad Base Table Index = %u !\n",*sp);
#endif
                return 2566;
            }
#ifdef DEBUGFIL
            printf("\nWriting File: %d - Bytes: %d\n",w,uw);
#endif
            if ((w = write(w, bp, uw)) != -1) {
#ifdef DEBUGFIL
            printf("Write Count: %d\n",w);
#ifdef PAUSE
            getchar();
#endif
#endif
                *sp = w;
                *++sp = 0;
                goto next;
            }
            *sp = -1;
            *++sp = -1;
            goto next;
#endif

#ifdef FP_BDOSX_DH_READ
        case FP_BDOSX_DH_READ:
            w = *sp--;
            uw = *sp--;
            uw1 = *sp--;
            if ((WUWORD)*sp < BASESIZE)
                bp = basetable[*sp] + uw1;
            else {
#ifdef DEBUG
                printf("\nBad Base Table Index = %u !\n",*sp);
#endif
                return 2567;
            }
#ifdef DEBUGFIL
            printf("\nReading File: %d - Bytes: %d\n",w,uw);
#endif
            if ((w = read(w, bp, uw)) != -1) {
#ifdef DEBUGFIL
            printf("Read Count: %d\n",w);
#ifdef PAUSE
            getchar();
#endif
#endif
                *sp = w;
                *++sp = 0;
                goto next;
            }
            *sp = -1;
            *++sp = -1;
            goto next;
#endif

#ifdef FP_BDOSX_DH_DELETE
        case FP_BDOSX_DH_DELETE:
            bp = code + (WUWORD)*sp;
#ifdef DEBUGFIL
            printf("\nDeleting File Name: %s\n",bp);
#ifdef PAUSE
            getchar();
#endif
#endif
            *sp = remove(bp);   /*  *sp = unlink(bp);  */
            goto next;
#endif

#ifdef FP_BDOSX_DH_CLOSE
        case FP_BDOSX_DH_CLOSE:
            uw = *sp;
#ifdef DEBUGFIL
            printf("\nClosing File: %d\n",uw);
#endif
            *sp = close(uw);
            goto next;
#endif

#ifdef FP_BDOSX_DH_OPEN
        case FP_BDOSX_DH_OPEN:
            b = *sp--; /* attribute for open */
            bp = code + (WUWORD)*sp;
#ifdef DEBUGFIL
            printf("\nOpening File Name: %s\n",bp);
#endif
            if((b & 0x40) == 0) {
                /*
                ** open file in compatibility mode
                */
                if((b & 0x03) == 0)
                    w = open(bp, O_RDONLY | 
                             O_BINARY  OPEN_PARAMS);
                else
                    w = open(bp, O_RDWR | 
                             O_BINARY  OPEN_PARAMS);
            } else {
                /*
                ** open file in deny_none mode
                */
                if((b & 0x03) == 0)
                    w = open(bp, O_RDONLY | 
                             O_BINARY | 
                             SH_DENYNONE  OPEN_PARAMS);
                else
                    w = open(bp, O_RDWR | 
                             O_BINARY | 
                             SH_DENYNONE  OPEN_PARAMS);
            }
            if (w != -1) {
#ifdef DEBUGFIL
                printf("Opened File: %d - Name: %s\n",w,bp);
#ifdef PAUSE
                getchar();
#endif
#endif
                *sp = w;
                *++sp = 0;
                goto next;
            }
            if (errno == ENOENT) w = 2;
            if (errno == EACCES) w = 5;
            *sp = w;
            *++sp = w;
            goto next;
#endif

#ifdef FP_BDOSX_DH_CREATEF
        case FP_BDOSX_DH_CREATEF:
            b = *sp--; /* attribute for create */
            bp = code + (WUWORD)*sp;
#ifdef DEBUGFIL
            printf("\nCreating File Name: %s\n",bp);
#endif
            if((b & 0x40) == 0) {
                /*
                ** create file in compatibility mode
                */
                if((b & 0x01) != 0)
                    w = open(bp, O_RDONLY | 
                             O_BINARY | 
                             O_CREAT | 
                             O_TRUNC, 
                             S_IREAD  CREAT_PARAMS);
                else
                    w = open(bp, O_RDWR | 
                             O_BINARY | 
                             O_CREAT | 
                             O_TRUNC, 
                             S_IREAD | 
                             S_IWRITE  CREAT_PARAMS);
            } else {
                /*
                ** create file in deny_none mode
                */
                if((b & 0x01) != 0)
                    w = open(bp, O_RDONLY | 
                             O_BINARY |
                             O_CREAT | 
                             O_TRUNC |
                             SH_DENYNONE,
                             S_IREAD  CREAT_PARAMS);
                else
                    w = open(bp, O_RDWR | 
                             O_BINARY | 
                             O_CREAT | 
                             O_TRUNC |
                             SH_DENYNONE,
                             S_IREAD | 
                             S_IWRITE  CREAT_PARAMS);
            }
            if (w != -1) {
#ifdef DEBUGFIL
                printf("Created File: %d - Name: %s\n",w,bp);
#ifdef PAUSE
                getchar();
#endif
#endif
                *sp = w;
                *++sp = 0;
                goto next;
            }
            *sp = -1;
            *++sp = -1;
            goto next;
#endif

#ifdef FP_FILE_DH_POSITION_DH_PRIM
        case FP_FILE_DH_POSITION_DH_PRIM:
            w = *sp--;
            udw = ((WUDWORD)(WUWORD)(*sp--)) << 16;
            udw += (WUWORD)*sp;
#ifdef DEBUGFIL
            printf("\nPositioning File: %d - to: %ld\n",w,udw);
#ifdef PAUSE
            getchar();
#endif
#endif
            if (lseek(w, udw, 0) != -1) {
                *sp = 0;
                goto next;
            }
            *sp = -1;
            goto next;
#endif

#ifdef FP_FILE_DH_SIZE_DH_PRIM
        case FP_FILE_DH_SIZE_DH_PRIM:
            w = *sp;
            if (((udw = lseek(w, 0, 1)) != -1) &&
                ((udw1 = lseek(w, 0, 2)) != -1) &&
                (lseek(w, udw, 0) != -1)) {
#ifdef DEBUGFIL
            printf("\nFile: %d - length is: %ld\n",w,udw1);
#ifdef PAUSE
            getchar();
#endif
#endif
                *sp = udw1 & 0x0FFFF;
                *++sp = udw1 >> 16;
                *++sp = 0;
                goto next;
            }
            if (w == 0) {
              *sp = 0;
              *++sp = 0;
              *++sp = 0;
            } else {
              *sp = -1;
              *++sp = -1;
              *++sp = -1;
            }
            goto next;

#endif

#ifdef FP_FIND_DH_FIRST_DH_PRIM
        case FP_FIND_DH_FIRST_DH_PRIM:
            sp--; /* attribute for search */
            bp = code + (WUWORD)*sp;
#ifdef DEBUGFIL
            printf("\nSearch for File Name: %s\n",bp);
#ifdef PAUSE
            getchar();
#endif
#endif
            if ((w = open(bp, O_RDONLY | 
                      O_BINARY | 
                      SH_DENYNONE  OPEN_PARAMS)) != -1) {
                close(w);
                *sp = 0;
                goto next;
            }
            *sp = -1;
            goto next;
#endif

#ifdef FP_LOCK_DH_RANGE
        case FP_LOCK_DH_RANGE:
            w = *sp--;
            uw = *sp--;
            udw = ((WUDWORD)(WUWORD)(*sp--)) << 16;
            udw += (WUWORD)*sp;
#ifdef DEBUGFIL
            printf("\nLocking File: %d at: %ld for: %u bytes\n",w,udw,uw);
#ifdef PAUSE
            getchar();
#endif
#endif
#if defined __MSDOS__
            asm PUSH AX
            asm PUSH BX
            asm PUSH CX
            asm PUSH DX
            asm PUSH SI
            asm PUSH DI
            _BX = w;    /* File Handle */
            _DI = uw;   /* Low Word of Length */
            _SI = 0;    /* High Word of Length */
            _DX = udw & 0x0FFFF;    /* Low Word of Position */
            _CX = udw >> 16;    /* Low Word of Position */
            _AX = 0x5C00;   /* Dos function for lock */
            asm INT 21H
            asm JC lockerr
            w = 0;
            goto lockend;
lockerr:        w = _AX;
lockend:        asm POP DI
            asm POP SI
            asm POP DX
            asm POP CX
            asm POP BX
            asm POP AX
            *sp = w;
            goto next;
#elif defined macintosh | defined VMS   /* no locking, return good! */
            *sp = 0;
            goto next;
#elif defined WIN32
            if (lseek(w, udw, SEEK_SET) < 0L) {
                *sp = -1;
            } else {
                *sp = _locking(w, LK_NBLCK, uw);
            }
            goto next;
#else   /* UNIX and any systems not specifically designated above */
            flockp.l_type = F_WRLCK;
            flockp.l_whence = 0;
            flockp.l_start = udw;
            flockp.l_len = uw;
            if (fcntl(w, F_SETLK, &flockp) != -1) {
                *sp = 0;
                goto next;
            }
            *sp = -1;
            goto next;
#endif
#endif

#ifdef FP_UNLOCK_DH_RANGE
        case FP_UNLOCK_DH_RANGE:
            w = *sp--;
            uw = *sp--;
            udw = ((WUDWORD)(WUWORD)(*sp--)) << 16;
            udw += (WUWORD)*sp;
#ifdef DEBUGFIL
            printf("\nUnlocking File: %d at: %ld for: %u bytes\n",w,udw,uw);
#ifdef PAUSE
            getchar();
#endif
#endif
#if defined __MSDOS__
            asm PUSH AX
            asm PUSH BX
            asm PUSH CX
            asm PUSH DX
            asm PUSH SI
            asm PUSH DI
            _BX = w;    /* File Handle */
            _DI = uw;   /* Low Word of Length */
            _SI = 0;    /* High Word of Length */
            _DX = udw & 0x0FFFF;    /* Low Word of Position */
            _CX = udw >> 16;    /* Low Word of Position */
            _AX = 0x05C01;  /* Dos function for unlock */
            asm INT 21H
            asm JC unlockerr
            w = 0;
            goto unlockend;
unlockerr:      w = _AX;
unlockend:      asm POP DI
            asm POP SI
            asm POP DX
            asm POP CX
            asm POP BX
            asm POP AX
            *sp = w;
            goto next;
#elif defined macintosh | defined VMS   /* no locking, return good! */
            *sp = 0;
            goto next;
#elif defined WIN32
            if (lseek(w, udw, SEEK_SET) < 0L) {
                *sp = -1;
            } else {
                *sp = _locking(w, LK_UNLCK, uw);
            }
            goto next;
#else   /* UNIX and any systems not specifically designated above */
            flockp.l_type = F_UNLCK;
            flockp.l_whence = 0;
            flockp.l_start = udw;
            flockp.l_len = uw;
            if (fcntl(w, F_SETLK, &flockp) != -1) {
                *sp = 0;
                goto next;
            }
            *sp = -1;
            goto next;
#endif
#endif

#ifdef FP_BDOSX_DH_NETQ
        case FP_BDOSX_DH_NETQ:
#ifdef __MSDOS__
            asm PUSH AX
            asm PUSH BX
            asm PUSH CX
            asm PUSH DX
            asm PUSH SI
            asm PUSH DI
            _BX = *sp;
            _AX = 0x4409;
            asm INT 21H
            w = _DX & 0x1000;
            asm POP DI
            asm POP SI
            asm POP DX
            asm POP CX
            asm POP BX
            asm POP AX
            *sp = w;
            goto next;
#else   /* UNIX and any systems not specifically designated above */
            *sp = 0x01000;
            goto next;
#endif
#endif

#ifdef FP_ST
        case FP_ST:
            w = *sp--;
            *sp *= w;
            goto next;
#endif

#ifdef FP_SL_MOD
        case FP_SL_MOD:
            w = *sp;
            dw = *(sp-1);
            *(sp-1) = dw % w;
            *sp = dw / w;
            goto next;
#endif

#define CLIP_WORD(x) ((x)>65534?65534:(x))

#ifdef FP_BDOS_DH_SPACE
        case FP_BDOS_DH_SPACE:
#if defined __MSDOS__
            asm PUSH AX
            asm PUSH BX
            asm PUSH CX
            asm PUSH DX
            asm PUSH SI
            asm PUSH DI
            _DX = *sp;
            _AX = 0x3600;
            asm INT 21H
            w = _BX;
            w1 = _CX;
            uw = _DX;
            uw1 = _AX;
            asm POP DI
            asm POP SI
            asm POP DX
            asm POP CX
            asm POP BX
            asm POP AX
            *sp = w;
            *++sp = w1;
            *++sp = uw;
            *++sp = uw1;
            goto next;
#elif defined macintosh | defined VMS   /* no space call...? , terminate! */
            printf("\nBDOS_DH_SPACE not supported!\n");
            exit(1);
#elif __svr4__
            statvfs(".", &statfsp);
            *sp = CLIP_WORD(statfsp.f_bfree);
            *++sp = CLIP_WORD(statfsp.f_bsize);
            *++sp = CLIP_WORD(statfsp.f_blocks);
            *++sp = 1;
            #ifdef DEBUGFIL
              printf("\nFree Space = %uK\n",statfsp.f_bfree/2);
            #endif
            goto next;
#elif defined WIN32
            {  
                unsigned long sectorsPerCluster, bytesPerSector,
                              freeClusters, totalClusters;

                if (GetDiskFreeSpace(NULL, 
                                        &sectorsPerCluster,
                                        &bytesPerSector,
                                        &freeClusters,
                                        &totalClusters)) {
                    *sp = CLIP_WORD(freeClusters);
                    *++sp = CLIP_WORD(bytesPerSector*sectorsPerCluster);
                    *++sp = CLIP_WORD(totalClusters);
                    *++sp = 1;
                } else {
                    *sp = 0;
                    *++sp = 512;
                    *++sp = 1024;
                    *++sp = 0;
                }
            }
            goto next;
#else   /* UNIX and any systems not specifically designated above */
            statfs(".", &statfsp 
                           /* leave out for Linux:====================
                              , sizeof(struct statfs), 0
                              =======================================*/
                           );
            *sp = CLIP_WORD(statfsp.f_bfree);
            *++sp = CLIP_WORD(statfsp.f_bsize);
            *++sp = CLIP_WORD(statfsp.f_blocks);
            *++sp = 1;
            #ifdef DEBUGFIL
              printf("\nFree Space = %uK\n",statfsp.f_bfree/2);
            #endif
            goto next;
#endif
#endif

#ifdef FP_DEF_DH_DRV_DH_PRIM
        case FP_DEF_DH_DRV_DH_PRIM:
#ifdef __MSDOS__
            *++sp = getdisk();
#else   /* UNIX and any systems not specifically designated above */
            *++sp = 0;
#endif
            goto next;
#endif

        case FP_XIT_DH_RET:
            return AX_DOT_R;

#ifdef FP_SCOMPARE
        case FP_SCOMPARE:
            uw = *sp--;
            uw1 = *sp--;
            if ((WUWORD)*sp < BASESIZE)
                bp = basetable[*sp--] + uw1 - 1;
            else {
#ifdef DEBUG
                printf("\nBad Base Table Index = %u !\n",*sp);
#endif
                return 2568;
            }
            uw1 = *sp--;
            if ((WUWORD)*sp < BASESIZE)
                bp1 = basetable[*sp] + uw1 - 1;
            else {
#ifdef DEBUG
                printf("\nBad Base Table Index = %u !\n",*sp);
#endif
                return 2569;
            }
            while ((uw > 0) && (*++bp == *++bp1))
                uw--;
            if (uw == 0)
                *sp = 0;
            else if (*bp < *bp1)
                *sp = 1;
            else
                *sp = -1;
            goto next;
#endif

#ifdef FP_PL_C_SV
        case FP_PL_C_SV:
            uw = *sp--;
/* CODE READ-ONLY */
if (uw < 0x4360) return 3510;
            *(code + uw) += *sp--;
            goto next;
#endif

#ifdef FP_PL_C_AT
        case FP_PL_C_AT:
            uw = *sp--;
            *sp = *(code + uw + (WUWORD)*sp);
            goto next;
#endif

#ifdef FP_3C_AT
        case FP_3C_AT:
            uw = *sp;
            *sp = *(WSWORD *)(code + uw);
            *++sp = *(code + uw + 2);
            goto next;
#endif

#ifdef FP_3C_SV
        case FP_3C_SV:
            uw = *sp--;
/* CODE READ-ONLY */
if (uw < 0x4360) return 3511;
            *(code + uw + 2) = *sp--;
            *(WSWORD *)(code + uw) = *sp--;
            goto next;
#endif

#ifdef FP_1_PL_C_AT
        case FP_1_PL_C_AT:
            *sp = *(code + (WUWORD)*sp + 1);
            goto next;
#endif

#ifdef FP_2_PL_C_AT
        case FP_2_PL_C_AT:
            *sp = *(code + (WUWORD)*sp + 2);
            goto next;
#endif

#ifdef FP_3_PL_C_AT
        case FP_3_PL_C_AT:
            *sp = *(code + (WUWORD)*sp + 3);
            goto next;
#endif

#ifdef FP_4_PL_C_AT
        case FP_4_PL_C_AT:
            *sp = *(code + (WUWORD)*sp + 4);
            goto next;
#endif

#ifdef FP_2C_AT
        case FP_2C_AT:
            uw = *sp;
            *sp = *(code + uw);
            *++sp = *(code + uw + 1);
            goto next;
#endif

#ifdef FP_2C_SV
        case FP_2C_SV:
            uw = *sp--;
/* CODE READ-ONLY */
if (uw < 0x4360) return 3512;
            *(code + uw + 1) = *sp--;
            *(code + uw) = *sp--;
            goto next;
#endif

#ifdef FP_2_PL_AT
        case FP_2_PL_AT:
            *sp = *(WSWORD *)(code + (WUWORD)*sp + 2);
            goto next;
#endif

#ifdef FP_4_PL_AT
        case FP_4_PL_AT:
            *sp = *(WSWORD *)(code + (WUWORD)*sp + 4);
            goto next;
#endif

#ifdef FP_DUP_AT
        case FP_DUP_AT:
            uw = *(WSWORD *)(code + (WUWORD)*sp);
            *++sp = uw;
            goto next;
#endif

#ifdef FP_DUPC_AT
        case FP_DUPC_AT:
            uw = *(code + (WUWORD)*sp);
            *++sp = uw;
            goto next;
#endif

#ifdef FP_YC_AT
        case FP_YC_AT:
            *++sp = *(code + Y_DOT_OFF + Y_DOT_OFF0);
            goto next;
#endif

#ifdef FP_Y1_PL_C_AT
        case FP_Y1_PL_C_AT:
            *++sp = *(code + Y_DOT_OFF + Y_DOT_OFF0 + 1);
            goto next;
#endif

#ifdef FP_YC_SV
        case FP_YC_SV:
/* CODE READ-ONLY */
if (Y_DOT_OFF + Y_DOT_OFF0 < 0x4360) return 3513;
            *(code + Y_DOT_OFF + Y_DOT_OFF0) = *sp--;
            goto next;
#endif

#ifdef FP_BCOUNT
        case FP_BCOUNT:
            b = *(code + ((*sp)++) + Y_DOT_OFF0);
            *++sp = b;
            goto next;
#endif

#ifdef FP_BCOUNT_PL_1_PL
        case FP_BCOUNT_PL_1_PL:
            b = *(code + (WUWORD)*sp + Y_DOT_OFF0);
            uw = *sp + 2 + b;
            *sp = uw;
            goto next;
#endif

#ifdef FP_BCOUNT2
        case FP_BCOUNT2:
            uw = *sp;
            b = *(code + (uw++) + Y_DOT_OFF0);
            b1 = *(code + (uw++) + Y_DOT_OFF0);
            *sp = uw;
            *++sp = b;
            *++sp = b1;
            goto next;
#endif

#ifdef FP_B_AT
        case FP_B_AT:
            *sp = *(WSWORD *)(code + (WUWORD)*sp + Y_DOT_OFF0);
            goto next;
#endif

#ifdef FP_BC_AT
        case FP_BC_AT:
            *sp = *(code + (WUWORD)*sp + Y_DOT_OFF0);
            goto next;
#endif

#ifdef FP_B_SV
        case FP_B_SV:
            uw = *sp--;
/* CODE READ-ONLY */
if (uw + Y_DOT_OFF0 < 0x4360) return 3514;
            *(WSWORD *)(code + uw + Y_DOT_OFF0) = *sp--;
            goto next;
#endif

#ifdef FP_BC_SV
        case FP_BC_SV:
            uw = *sp--;
/* CODE READ-ONLY */
if (uw + Y_DOT_OFF0 < 0x4360) return 3515;
            *(code + uw + Y_DOT_OFF0) = *sp--;
            goto next;
#endif

#ifdef FP_B3C_AT
        case FP_B3C_AT:
            uw = *sp;
            *sp = *(WSWORD *)(code + uw + Y_DOT_OFF0);
            *++sp = *(code + uw + 2 + Y_DOT_OFF0);
            goto next;
#endif

#ifdef FP_B3C_SV
        case FP_B3C_SV:
            uw = *sp--;
/* CODE READ-ONLY */
if (uw + Y_DOT_OFF0 < 0x4360) return 3516;
            *(code + uw + 2 + Y_DOT_OFF0) = *sp--;
            *(WSWORD *)(code + uw + Y_DOT_OFF0) = *sp--;
            goto next;
#endif

#ifdef FP_II_DH_SR3CX
        case FP_II_DH_SR3CX:
            uw = II_DOT_SRB;
            b2 = 0;
            bp = code + 9 + Y_DOT_OFF0;
            while (*(WSWORD *)bp != 0) {
                b = *bp;
                if (uw >= *(bp+1)) {
                    bp1 = bp + 2;
                    uw = *(bp+1);
                    while (b > 0) {
                        b1 = *(code + uw + (WUWORD)*sp);
                        if (b1 != *bp1)
                            break;
                        bp1++;
                        II_DOT_SRA = ++uw;
                        if (uw >= KSL) {
                            b = 0;
                            break;
                        }
                        b--;
                    }
                    if (b == 0) {
                        II_DOT_SRB = uw;
                        II_DOT_SRK = b2;
                        bp1 = bp + *bp + 2;
                        *sp = *(WSWORD *)bp1;
                        *++sp = *(bp1+2);
                        *++sp = 1;
                        *++sp = (bp-code) - Y_DOT_OFF0;
                        goto next;
                    }
                    if (b1 < *bp1) {
                        II_DOT_SRB = uw;
                        II_DOT_SRK = b2;
                        bp1 = bp + *bp + 2;
                        *sp = *(WSWORD *)bp1;
                        *++sp = *(bp1+2);
                        *++sp = -1;
                        *++sp = (bp-code) - Y_DOT_OFF0;
                        goto next;
                    }
                }
                bp += *bp + 5;
                b2++;
            }
            II_DOT_SRB = uw;
            II_DOT_SRK = b2;
            *sp = 0;
            *++sp = 0;
            goto next;
#endif

#ifdef FP_II_DH_SR2C
        case FP_II_DH_SR2C:
            uw = 9;
            b1 = 0;
            b = *(code + uw + Y_DOT_OFF0 + 1);
            while ((uw1 = *(WSWORD *)(code + uw + Y_DOT_OFF0)) != 0) {
                b1++;
                if ((uw1 >> 8) < (WUWORD)b) {
                    *++sp = uw1;
                    goto next;
                }
                uw += (uw1 & 0x0FF) + 5;
            }
            II_DOT_SRN = b1;
            *++sp = 0;
            goto next;
#endif

#ifdef FP_II_DH_BACKC
        case FP_II_DH_BACKC:
            uw = 9;
            while ((uw1 = *(WSWORD *)(code + uw + Y_DOT_OFF0)) != 0) {
                uw1 &= 0x0FF;
                uw1 += uw + 5;
                if (uw1 >= (WUWORD)*sp) {
                    *sp = uw;
                    goto next;
                }
                uw = uw1;
            }
            *sp = 0;
            goto next;
#endif

#ifdef FP_II_DH_CMP
        case FP_II_DH_CMP:
            uw = *sp;
            bp = code + (WUWORD)*(sp-1);
            bp1 = code + (WUWORD)*(sp-2);
            while ((uw > 0) && (*bp++ == *bp1++))
                uw--;
            if (uw == 0)
                *(sp-2) = 0;
            else if (*(bp-1) < *(bp1-1))
                *(sp-2) = 1;
            else
                *(sp-2) = -1;
            if (uw > 0) uw--;
            uw = *sp - uw - 1;
            *--sp = uw;
            goto next;
#endif

#ifdef FP_DL_GT_SORT
        case FP_DL_GT_SORT:
            bp = code + (WUWORD)*sp--;
            uw = *sp--;
            bp1 = code + (WUWORD)*sp--;
            while (uw-- > 0) {
                *bp1 = bp[*bp1];
                bp1++;
            }
            goto next;
#endif

#ifdef FP_SRCH_DH_FAR_DH_LIST
        case FP_SRCH_DH_FAR_DH_LIST:
            uw1 = *sp--;
            if ((WUWORD)*sp < BASESIZE)
                bp = basetable[*sp] + uw1;
            else {
#ifdef DEBUG
                printf("\nBad Base Table Index = %u !\n",*sp);
#endif
                return 2570;
            }
            b = *(sp-1);
            while (*bp != 0) {
                if (*(bp+1) == b) {
                    *(sp-1) = *sp;
                    *sp = bp - basetable[*sp];
                    *++sp = 1;
                    goto next;
                }
            bp += *bp + 1;
            }
                *--sp = 0;
                goto next;
#endif

#ifdef FP_P_EQ_0_QM
        case FP_P_EQ_0_QM:
            uw = *sp;
            if (*(WSDWORD *)(code+uw+1) | *(WSDWORD *)(code+uw+4)) {
                *sp = 0;
                goto next;
            }
            *sp = 1;
            goto next;
#endif

#ifdef FP_P_DH_SIGN_AT
        case FP_P_DH_SIGN_AT:
            *sp = *(code + (WUWORD)*sp) & 0x0080;
            goto next;
#endif

#ifdef FP_P_DH_SIGN_SV
        case FP_P_DH_SIGN_SV:
            uw = *sp--;
/* CODE READ-ONLY */
if (uw < 0x4360) return 3517;
            if (*sp-- == 0) {
                *(code + uw) &= 0x007F;
                goto next;
            }
            *(code + uw) |= 0x0080;
            goto next;
#endif

#ifdef FP_P_DH_EXP_AT
        case FP_P_DH_EXP_AT:
            w = *(code + (WUWORD)*sp) & 0x007F;
            if (w == 0) {
                *sp = 0;
                goto next;
            }
            *sp = w - 0x0040;
            goto next;
#endif

#ifdef FP_P_DH_EXP_PL_SV_C
        case FP_P_DH_EXP_PL_SV_C:
            uw = *sp--;
            w = *(code + uw);
            if (w == 0)
                w = 0x0040;
/* CODE READ-ONLY */
if (uw < 0x4360) return 3518;
            *(code + uw) = w + *sp--;
            goto next;
#endif

#ifdef FP_P_DH_DIG_AT
        case FP_P_DH_DIG_AT:
            uw = *sp--;
            w = *(code + (uw >> 1) + (WUWORD)*sp + 1);
            if ((uw & 1) == 0)
                w = w >> 4;
            *sp = w & 0x000F;
            goto next;
#endif

#ifdef FP_P_DH_DIG_SV
        case FP_P_DH_DIG_SV:
            uw = *sp--;
            uw1 = *sp--;
            if (uw < 14) {
                bp = code + (uw >> 1) + uw1 + 1;
                if ((uw & 1) == 0)
                    *bp = (*bp & 0x0F) | (*sp << 4);
                else
                    *bp = (*bp & 0xF0) | *sp;
            }
            sp--;
            goto next;
#endif

        default:
#if defined SHOWPRM || defined DEBUGPRM
            printf("\nMissing Primitive Number %d\n",primnum);
#endif
            return 2561;
        }
    default:
#ifdef DEBUG
        w = (WUBYTE *)ip - code;
        printf("\nInvalid Byte Code Encountered at: 0x%X!\n",w);
#endif
        return 2560;
    }
}
