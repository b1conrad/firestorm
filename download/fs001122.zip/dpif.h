
#ifndef _DPIF_H
#define _DPIF_H
#include "machine.h"

extern WSWORD FAR dpe_Init(WUBYTE FAR *ndxfil, WUBYTE FAR *txxfil, WUBYTE FAR *sortmap);
extern WSWORD FAR dpe_InitIndex(WUBYTE FAR *ndxfil);
extern WSWORD FAR dpe_CreateIndex(WUBYTE FAR *ndxfil);
extern WSWORD FAR dpe_GenIndex(WUBYTE FAR *pbarray, WUWORD index, WUDWORD FAR *ndxbase);
extern WSWORD FAR dpe_RecCnt(WUBYTE FAR *pbarray, WUDWORD FAR *reccnt);
extern WSWORD FAR dpe_GenNum(WUBYTE FAR *pbarray, WUDWORD FAR *gennum);
extern WSWORD FAR dpe_FirstRec(WUBYTE FAR *pbarray, WUWORD index, WUDWORD FAR *reccnt);
extern WSWORD FAR dpe_LastRec(WUBYTE FAR *pbarray, WUWORD index, WUDWORD FAR *reccnt);
extern WSWORD FAR dpe_EqualRec(WUBYTE FAR *pbarray, WUBYTE FAR *iflist, WUDWORD FAR *reccnt);
extern WSWORD FAR dpe_NextRec(WUBYTE FAR *pbarray, WUBYTE FAR *iflist, WUDWORD FAR *reccnt);
extern WSWORD FAR dpe_PrevRec(WUBYTE FAR *pbarray, WUBYTE FAR *iflist, WUDWORD FAR *reccnt);
extern WSWORD FAR dpe_SubFirstRec(WUBYTE FAR *pbarray, WUBYTE FAR *iflist, WUDWORD FAR *reccnt);
extern WSWORD FAR dpe_SubLastRec(WUBYTE FAR *pbarray, WUBYTE FAR *iflist, WUDWORD FAR *reccnt);
extern WSWORD FAR dpe_SubNextRec(WUBYTE FAR *pbarray, WUBYTE FAR *iflist, WUBYTE FAR *constr, WUDWORD FAR *reccnt);
extern WSWORD FAR dpe_SubPrevRec(WUBYTE FAR *pbarray, WUBYTE FAR *iflist, WUBYTE FAR *constr, WUDWORD FAR *reccnt);
extern WSWORD FAR dpe_GetField(WUBYTE FAR *pbarray, WUBYTE FAR *fldnfo, WUWORD FAR *type, WUWORD size, WUBYTE FAR *data);
extern WSWORD FAR dpe_GetBlob(WUBYTE FAR *pbarray, WUBYTE FAR *fldnfo, WUWORD FAR *type, WUWORD size, WUBYTE FAR *data);
extern WSWORD FAR dpe_LockOff(void);
extern WSWORD FAR dpe_LockOn(void);
extern WSWORD FAR dpe_FlushBuff(void);
extern WSWORD FAR dpe_LockIndex(void);
extern WSWORD FAR dpe_CloseFiles(void);
extern WSWORD FAR dpe_CreateRec(WUBYTE FAR *pbarray, WUWORD handle, WUBYTE FAR *flist, WUWORD size, WUBYTE FAR *data);
extern WSWORD FAR dpe_UpdateRec(WUBYTE FAR *pbarray, WUBYTE FAR *flist, WUBYTE FAR *oflist);
extern WSWORD FAR dpe_DeleteRec(WUBYTE FAR *pbarray, WUBYTE FAR *iflist);
extern WSWORD FAR dpe_GetIncFld(WUBYTE FAR *pbarray, WUWORD handle, WUWORD size, WUBYTE FAR *data);
extern WSWORD FAR dpe_SetIncFld(WUBYTE FAR *pbarray, WUWORD handle, WUBYTE FAR *flist);

#endif
