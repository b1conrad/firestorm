#define FP_LIT                 0    /* LIT */
#define FP_BRANCH1             1    /* BRANCH1 */
#define FP_0BRANCH1            2    /* 0BRANCH1 */
#define FP_NZBRCH1             3    /* NZBRCH1 */
#define FP_DH_D0BR1            4    /* -D0BR1 */
#define FP_D0BR1               5    /* D0BR1 */
#define FP_BRANCH              6    /* BRANCH */
#define FP_0BRANCH             7    /* 0BRANCH */
#define FP_LP_LOOP_RP              8    /* (LOOP) */
#define FP_NZBRCH              9    /* NZBRCH */
#define FP_0BR_AN_DROP            10    /* 0BR&DROP */
#define FP_LP_PL_LOOP_RP          11    /* (+LOOP) */
#define FP_DH_D0BR            12    /* -D0BR */
#define FP_D0BR               13    /* D0BR */
#define FP_DH_DNZBR           14    /* -DNZBR */
#define FP_DNZBR              15    /* DNZBR */
#define FP_D0BR_AN_DROP           16    /* D0BR&DROP */
#define FP_0DROP_AN_BR            17    /* 0DROP&BR */
#define FP_0DROPX             18    /* 0DROPX */
#define FP_0EXIT              19    /* 0EXIT */
#define FP_NZEXIT             20    /* NZEXIT */
#define FP_NZDROPX            21    /* NZDROPX */
#define FP_LP_LOOP1_RP            22    /* (LOOP1) */
#define FP_LP_DO_RP           23    /* (DO) */
#define FP_LB_BDO_RB              24    /* [BDO] */
#define FP_LB_0DO_RB              25    /* [0DO] */
#define FP_DIGIT              26    /* DIGIT */
#define FP_U_ST               27    /* U* */
#define FP_U_SL               28    /* U/ */
#define FP_E_ST               29    /* E* */
#define FP_E_SL_MOD           30    /* E/MOD */
#define FP_AND                31    /* AND */
#define FP_OR                 32    /* OR */
#define FP_0_LT_GT_AND            33    /* 0<>AND */
#define FP_0_EQ_AND           34    /* 0=AND */
#define FP_C_AT_DH_AND_DT_OP          35    /* C@-AND.OP */
#define FP_B_DH_AND_DT_OP         36    /* B-AND.OP */
#define FP_EVAL_DH_SUB            37    /* EVAL-SUB */
#define FP_LEAVE              38    /* LEAVE */
#define FP_GT_R               39    /* >R */
#define FP_R_GT               40    /* R> */
#define FP_I                  41    /* I */
#define FP_R                  42    /* R */
#define FP_DUP_GT_R           43    /* DUP>R */
#define FP_R_GT_DROP              44    /* R>DROP */
#define FP_0_EQ               45    /* 0= */
#define FP_0_LT_GT            46    /* 0<> */
#define FP_0_LT               47    /* 0< */
#define FP_PL                 48    /* + */
#define FP_B_PL_DT_OP             49    /* B+.OP */
#define FP_DO_PL_SC           50    /* DO+; */
#define FP_MINUS              51    /* MINUS */
#define FP_DH                 52    /* - */
#define FP_SWAP_DH            53    /* SWAP- */
#define FP_LT                 54    /* < */
#define FP_GT                 55    /* > */
#define FP_LT_DT_OP           56    /* <.OP */
#define FP_GT_DT_OP           57    /* >.OP */
#define FP_ROT                58    /* ROT */
#define FP_OVER               59    /* OVER */
#define FP_OVER_DH            60    /* OVER- */
#define FP_OVER_PL            61    /* OVER+ */
#define FP_DROP               62    /* DROP */
#define FP_SWAP               63    /* SWAP */
#define FP_DUP                64    /* DUP */
#define FP_2DUP               65    /* 2DUP */
#define FP_4DUP               66    /* 4DUP */
#define FP_PL_SV              67    /* +! */
#define FP_TOGGLE             68    /* TOGGLE */
#define FP_BITS_DH_ON             69    /* BITS-ON */
#define FP_BITS_DH_OFF            70    /* BITS-OFF */
#define FP_2DUPOR             71    /* 2DUPOR */
#define FP_D_PL               72    /* D+ */
#define FP_1D_PL              73    /* 1D+ */
#define FP_D_DH               74    /* D- */
#define FP_DMINUS             75    /* DMINUS */
#define FP_D_EQ               76    /* D= */
#define FP_D_GT               77    /* D> */
#define FP_D_LT               78    /* D< */
#define FP_AT                 79    /* @ */
#define FP_C_AT               80    /* C@ */
#define FP_2_AT               81    /* 2@ */
#define FP_SV                 82    /* ! */
#define FP_SWAP_SV            83    /* SWAP! */
#define FP_C_SV               84    /* C! */
#define FP_SWAPC_SV           85    /* SWAPC! */
#define FP_2_SV               86    /* 2! */
#define FP_LT_OVER_EQ_IFDROP_GT       87    /* <OVER=IFDROP> */
#define FP_OF_DH_S_DT_OP          88    /* OF-S.OP */
#define FP_DH_DUP             89    /* -DUP */
#define FP_2SWAP              90    /* 2SWAP */
#define FP_4DROP              91    /* 4DROP */
#define FP_3DROP              92    /* 3DROP */
#define FP_2DROP              93    /* 2DROP */
#define FP_SWAPDROP           94    /* SWAPDROP */
#define FP_SWAPDUP            95    /* SWAPDUP */
#define FP_SWAPOVER           96    /* SWAPOVER */
#define FP_LT_GT              97    /* <> */
#define FP_EQ                 98    /* = */
#define FP_1_PL               99    /* 1+ */
#define FP_2_PL              100    /* 2+ */
#define FP_3_PL              101    /* 3+ */
#define FP_4_PL              102    /* 4+ */
#define FP_6_PL              103    /* 6+ */
#define FP_1_DH              104    /* 1- */
#define FP_3_DH              105    /* 3- */
#define FP_PUSH11            106    /* PUSH11 */
#define FP_PUSH00            107    /* PUSH00 */
#define FP_PUSH10            108    /* PUSH10 */
#define FP_PUSH01            109    /* PUSH01 */
#define FP_U_LT              110    /* U< */
#define FP_COUNT             111    /* COUNT */
#define FP_COUNT_PL          112    /* COUNT+ */
#define FP_DL_CATENATE           113    /* $CATENATE */
#define FP_2COUNT            114    /* 2COUNT */
#define FP_DH_2DUP           115    /* -2DUP */
#define FP_OVERC_SV_1_PL         116    /* OVERC!1+ */
#define FP_SWAPOVERC_SV_1_PL         117    /* SWAPOVERC!1+ */
#define FP_EQ_OR_EQ          118    /* =OR= */
#define FP_GT_AND_LT             119    /* >AND< */
#define FP_256_SL            120    /* 256/ */
#define FP_256_ST_PL             121    /* 256*+ */
#define FP_XXLAT             122    /* XXLAT */
#define FP_MEMBER            123    /* MEMBER */
#define FP_SRCH_DH_FAR_DH_LIST       124    /* SRCH-FAR-LIST */
#define FP_TRAILC            125    /* TRAILC */
#define FP_2DROP0            126    /* 2DROP0 */
#define FP_DROP0             127    /* DROP0 */
#define FP_3PICK             128    /* 3PICK */
#define FP_4PICK             129    /* 4PICK */
#define FP_5PICK             130    /* 5PICK */
#define FP_IF_DH_SD_DH_ELSE_DH_D     131    /* IF-SD-ELSE-D */
#define FP_SCMOVE            132    /* SCMOVE */
#define FP_FILL              133    /* FILL */
#define FP_CMOVE             134    /* CMOVE */
#define FP_SWAPCMOVE             135    /* SWAPCMOVE */
#define FP_MAKE_DL           136    /* MAKE$ */
#define FP_DL_MOVE           137    /* $MOVE */
#define FP_BMOVE             138    /* BMOVE */
#define FP_LC_AT             139    /* LC@ */
#define FP_L_AT              140    /* L@ */
#define FP_L_SV              141    /* L! */
#define FP_PL_SV_AT          142    /* +!@ */
#define FP_ROTROT            143    /* ROTROT */
#define FP_IC_AT             144    /* IC@ */
#define FP_IC_SV             145    /* IC! */
#define FP_2_ST              146    /* 2* */
#define FP_3_ST              147    /* 3* */
#define FP_PL_PL             148    /* ++ */
#define FP_DUP_DH_PL_PL          149    /* DUP-++ */
#define FP_1_DH_1_PL_PL          150    /* 1-1++ */
#define FP_BDOSX_DH_WRITE        151    /* BDOSX-WRITE */
#define FP_BDOSX_DH_READ         152    /* BDOSX-READ */
#define FP_BDOSX_DH_DELETE       153    /* BDOSX-DELETE */
#define FP_BDOSX_DH_CLOSE        154    /* BDOSX-CLOSE */
#define FP_BDOSX_DH_OPEN         155    /* BDOSX-OPEN */
#define FP_BDOSX_DH_CREATEF      156    /* BDOSX-CREATEF */
#define FP_FILE_DH_POSITION_DH_PRIM  157    /* FILE-POSITION-PRIM */
#define FP_FILE_DH_SIZE_DH_PRIM      158    /* FILE-SIZE-PRIM */
#define FP_FIND_DH_FIRST_DH_PRIM     159    /* FIND-FIRST-PRIM */
#define FP_LOCK_DH_RANGE         160    /* LOCK-RANGE */
#define FP_UNLOCK_DH_RANGE       161    /* UNLOCK-RANGE */
#define FP_BDOSX_DH_NETQ         162    /* BDOSX-NETQ */
#define FP_ST                163    /* * */
#define FP_SL_MOD            164    /* /MOD */
#define FP_BDOS_DH_SPACE         165    /* BDOS-SPACE */
#define FP_DEF_DH_DRV_DH_PRIM        166    /* DEF-DRV-PRIM */
#define FP_XIT_DH_RET            167    /* XIT-RET */
#define FP_SCOMPARE          168    /* SCOMPARE */
#define FP_PL_C_SV           169    /* +C! */
#define FP_PL_C_AT           170    /* +C@ */
#define FP_3C_AT             171    /* 3C@ */
#define FP_3C_SV             172    /* 3C! */
#define FP_1_PL_C_AT             173    /* 1+C@ */
#define FP_2_PL_C_AT             174    /* 2+C@ */
#define FP_3_PL_C_AT             175    /* 3+C@ */
#define FP_4_PL_C_AT             176    /* 4+C@ */
#define FP_2C_AT             177    /* 2C@ */
#define FP_2C_SV             178    /* 2C! */
#define FP_2_PL_AT           179    /* 2+@ */
#define FP_4_PL_AT           180    /* 4+@ */
#define FP_DUP_AT            181    /* DUP@ */
#define FP_DUPC_AT           182    /* DUPC@ */
#define FP_YC_AT             183    /* YC@ */
#define FP_Y1_PL_C_AT            184    /* Y1+C@ */
#define FP_YC_SV             185    /* YC! */
#define FP_BCOUNT            186    /* BCOUNT */
#define FP_BCOUNT_PL_1_PL        187    /* BCOUNT+1+ */
#define FP_BCOUNT2           188    /* BCOUNT2 */
#define FP_B_AT              189    /* B@ */
#define FP_BC_AT             190    /* BC@ */
#define FP_B_SV              191    /* B! */
#define FP_BC_SV             192    /* BC! */
#define FP_B3C_AT            193    /* B3C@ */
#define FP_B3C_SV            194    /* B3C! */
#define FP_II_DH_SR3CX           195    /* II-SR3CX */
#define FP_II_DH_SR2C            196    /* II-SR2C */
#define FP_II_DH_BACKC           197    /* II-BACKC */
#define FP_II_DH_CMP             198    /* II-CMP */
#define FP_DL_GT_SORT            199    /* $>SORT */
#define FP_P_EQ_0_QM             200    /* P=0? */
#define FP_P_DH_SIGN_AT          201    /* P-SIGN@ */
#define FP_P_DH_SIGN_SV          202    /* P-SIGN! */
#define FP_P_DH_EXP_AT           203    /* P-EXP@ */
#define FP_P_DH_EXP_PL_SV_C      204    /* P-EXP+!C */
#define FP_P_DH_DIG_AT           205    /* P-DIG@ */
#define FP_P_DH_DIG_SV           206    /* P-DIG! */
