/* map.h */

extern unsigned char dosToLatin[256];
extern unsigned char latinToDos[256];
