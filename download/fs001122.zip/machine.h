/*--------------------------------------------------------*\
| File: machine.h
| This setup is for Linux.
\*--------------------------------------------------------*/
#ifndef _machine_h_
#define _machine_h_ 1

#define FAR
#define EXTERN_WRITE extern
#define LOCAL_WRITE static
#define GLOBAL_WRITE 
typedef short int WSWORD;
typedef unsigned short int WUWORD;
typedef signed long int WSDWORD;
typedef unsigned long int WUDWORD;
typedef unsigned char WUBYTE;
#endif
